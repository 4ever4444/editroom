// Editing room, one screen per video at /v/<name>, always on its newest version.
// Shared parts: tabs, modes ("look" = finished video in the Remotion Player, "cut" = the cut over the whole raw),
// comments (C), drawing on the frame, decisions, answers, report, saving, sending (which starts Claude),
// and following Claude's work until the next version appears.
// A mode module supplies the player: {outTime(), total(), seek(t), play(), stop(), isPlaying(), srcTime?()}
// plus payload(), renderTrack(), summary(), activate(), onKey?().
export const $ = (s) => document.querySelector(s);
export const fmt = (t) => `${Math.floor(t / 60)}:${(t % 60).toFixed(1).padStart(4, '0')}`;
export const now = () => new Date().toISOString();

const videoName = decodeURIComponent(location.pathname.split('/')[2]);
const V = encodeURIComponent(videoName);
let API, LOCAL_KEY;

export const ctx = {data: null, stage: null, modes: {}};

// the fixes the modes save by themselves (saver.js): whoever acts on them waits until they are on the server (24.11)
export const savers = [];
const NOT_SAVED = 'התיקון האחרון לא נשמר';
async function flushFixes() {
  const ok = (await Promise.all(savers.map((s) => s.flush()))).every(Boolean);
  if (!ok) status(NOT_SAVED, true);
  return ok;
}
export async function savedOr(what) {   // before an action that uses the fixes: false, with the reason, when they are not saved
  if (await flushFixes()) return true;
  alert(`${NOT_SAVED}, ולכן ${what} לא התחיל. בודקים שהחדר פועל ומנסים שוב.`);
  return false;
}

// "🎬 סרטון סופי" (stage 12.1-12.2), in the graphics tab and the cut tab: Ron's cut and fixes, rendered without Claude
export async function finalVideo() {
  if (!confirm('לרנדר את הסרטון הסופי עם החיתוך והתיקונים שלך? זה לוקח כמה דקות, בלי קלוד. אם משהו רץ, הרינדור ייכנס לתור.\n\nהערות שעוד לא שלחת לקלוד נשארות כאן ולא נכנסות לסרטון.')) return;
  if (!(await savedOr('הרינדור'))) return;
  const r = await fetch(`/api/final?video=${V}`, {method: 'POST'});
  if (!r.ok) alert((await r.json()).error);
  sent();
}

function sent() {   // something was put in the queue, or taken out: this page and its job bar at once
  window.dispatchEvent(new Event('queuesent'));
  return poll();
}
let pickLeft = () => {};   // set once the left tabs exist
const P = () => ctx.stage.player;
export const isActive = (mode) => ctx.stage === mode;

// ---- tabs and modes
function setupTabs(nav, onPick) {
  const pick = (name) => {
    nav.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
    nav.parentElement.querySelectorAll('.pane').forEach((p) => p.classList.toggle('on', p.dataset.pane === name));
    onPick?.(name);
  };
  nav.querySelectorAll('button').forEach((b) => (b.onclick = () => pick(b.dataset.tab)));
  return pick;
}

function setMode(name) {
  const next = ctx.modes[name];
  if (!next || next === ctx.stage) return;
  const t = ctx.stage ? P().outTime() : 0;
  ctx.stage?.player.stop();
  ctx.stage = next;
  document.body.classList.toggle('mode-cut', name === 'cut');
  document.body.classList.toggle('mode-look', name === 'look');
  $('#track').querySelectorAll(':scope > :not(.playhead)').forEach((e) => e.remove());
  $('#track').style.width = $('#track').style.height = '';   // the look mode's layered, zoomable timeline (12.1)
  $('#track').parentElement.classList.remove('zoomed');
  next.activate(t);
}

// ---- comments
export function renderComments(focusId) {
  const box = $('#comments');
  box.textContent = '';
  $('#nComments').textContent = ctx.data.comments.length || '';
  [...ctx.data.comments].sort((a, b) => a.t - b.t).forEach((c) => {
    const card = document.createElement('div');
    card.className = 'comment' + (c.id === focusId ? ' focus' : '');
    card.innerHTML = '<header><button class="chip"></button><span><button class="pen" title="צייר על הפריים">✎ ציור</button><button class="del" title="מחק">×</button></span></header><textarea placeholder="מה לשנות כאן?"></textarea>';
    card.querySelector('.chip').textContent = fmt(c.t);
    card.querySelector('.chip').onclick = () => { P().stop(); P().seek(c.t); };
    const pen = card.querySelector('.pen');
    if (c.drawing?.length) pen.textContent = '✎ ציור ✓';
    pen.onclick = () => inkStart(c);
    card.querySelector('.del').onclick = () => {
      if ((c.text || c.drawing?.length) && !confirm('למחוק את ההערה?')) return;
      ctx.data.comments = ctx.data.comments.filter((x) => x !== c);
      renderComments();
      ctx.stage.renderTrack();
      save({allowEmpty: true});
    };
    const ta = card.querySelector('textarea');
    ta.value = c.text;
    ta.oninput = () => { c.text = ta.value; save(); };
    ta.onblur = () => ctx.stage.renderTrack();
    box.append(card);
    if (c.id === focusId) { card.scrollIntoView({block: 'nearest'}); ta.focus(); }
  });
}

export function addComment(text = '') {
  if (document.body.classList.contains('locked')) return;
  P().stop();
  pickLeft('comments');
  const c = {id: Date.now().toString(36), t: +P().outTime().toFixed(3), mode: ctx.stage === ctx.modes.cut ? 'cut' : 'look',
    text, created: now()};
  if (P().srcTime) c.src = +P().srcTime().toFixed(3);
  ctx.data.comments.push(c);
  renderComments(c.id);
  ctx.stage.renderTrack();
  save();
}

export function commentMarkers(track, total) {
  ctx.data.comments.forEach((c) => {
    const m = document.createElement('div');
    m.className = 'marker';
    m.style.left = `${(c.t / total) * 100}%`;
    m.title = c.text;
    track.append(m);
  });
}

// ---- drawing on the frame: strokes in 0..1 coordinates, stored on the comment
const ink = $('#ink'), g2 = ink.getContext('2d');
let inkComment = null, inkStroke = null, inkShown = null;
export const inking = () => !!inkComment;

function inkSize() {
  const r = ink.getBoundingClientRect();
  ink.width = r.width * devicePixelRatio;
  ink.height = r.height * devicePixelRatio;
}

function inkPaint(strokes) {
  g2.clearRect(0, 0, ink.width, ink.height);
  g2.lineCap = g2.lineJoin = 'round';
  g2.lineWidth = 6 * devicePixelRatio;
  g2.strokeStyle = '#ff6b2c';
  g2.shadowColor = '#ff8a55';
  g2.shadowBlur = 12 * devicePixelRatio;
  for (const st of strokes || []) {
    g2.beginPath();
    st.forEach(([x, y], k) => (k ? g2.lineTo : g2.moveTo).call(g2, x * ink.width, y * ink.height));
    g2.stroke();
  }
}

function inkStart(c) {
  P().stop();
  P().seek(c.t);
  inkComment = c;
  c.drawing = c.drawing || [];
  inkSize();
  inkPaint(c.drawing);
  ink.classList.add('editing');
  $('#inkbar').hidden = false;
}

function inkEnd() {
  ink.classList.remove('editing');
  $('#inkbar').hidden = true;
  inkComment = null;
  inkShown = null;
  renderComments();
  save();
}

export function inkShowAt(t) {   // while paused on a comment's moment, show its drawing
  if (inkComment) return;
  const c = P().isPlaying() ? null : ctx.data.comments.find((x) => x.drawing?.length && Math.abs(x.t - t) < 0.06);
  if (c === inkShown) return;
  inkShown = c;
  if (c) inkSize();
  inkPaint(c?.drawing);
}

ink.addEventListener('pointerdown', (e) => {
  if (!inkComment) return;
  ink.setPointerCapture(e.pointerId);
  const r = ink.getBoundingClientRect();
  inkStroke = [[(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]];
  inkComment.drawing.push(inkStroke);
});
ink.addEventListener('pointermove', (e) => {
  if (!inkStroke) return;
  const r = ink.getBoundingClientRect();
  inkStroke.push([+((e.clientX - r.left) / r.width).toFixed(4), +((e.clientY - r.top) / r.height).toFixed(4)]);
  inkPaint(inkComment.drawing);
});
ink.addEventListener('pointerup', () => (inkStroke = null));
$('#inkClear').onclick = () => { inkComment.drawing = []; inkPaint([]); };
$('#inkDone').onclick = inkEnd;
window.addEventListener('resize', () => { inkShown = undefined; });

// ---- decisions, answers, report
function renderDecisions() {
  const d0 = ctx.data;
  const box = $('#decisionList');
  box.textContent = '';
  const open = d0.decisions.filter((d) => !d.choice).length;
  $('#nDecisions').textContent = open || '';
  if (!d0.decisions.length) box.innerHTML = '<p class="hint">אין החלטות פתוחות.</p>';
  d0.decisions.forEach((d) => {
    const card = document.createElement('div');
    card.className = 'decision';
    card.innerHTML = '<h3></h3><div class="options"></div><textarea placeholder="הערה (לא חובה)"></textarea>';
    card.querySelector('h3').textContent = d.question;
    d.options.forEach((o) => {
      const b = document.createElement('button');
      b.className = 'option' + (d.choice === o.id ? ' chosen' : '');
      b.innerHTML = (o.image ? '<img alt="">' : '') + '<b></b><span></span>' +
        (d.recommended === o.id ? '<em>ההמלצה שלי</em>' : '') + (o.t !== undefined ? '<u>▶ לרגע הזה</u>' : '');
      if (o.image) b.querySelector('img').src = o.image.startsWith('/') ? o.image : d0.files + o.image;   // /logo/...: a client's logo (stage 8)
      b.querySelector('b').textContent = o.label;
      b.querySelector('span').textContent = o.desc || '';
      b.onclick = (e) => {
        if (e.target.tagName === 'U') { P().stop(); return P().seek(o.t); }
        d.choice = o.id;
        renderDecisions();
        save();
      };
      if (o.clip || o.audio) {   // a hook clip or a song: hear it before choosing (outside the button: playing ≠ choosing)
        const wrap = Object.assign(document.createElement('div'), {className: 'option-wrap'});
        const v = Object.assign(document.createElement(o.clip ? 'video' : 'audio'),
          {src: o.clip ? d0.files + o.clip : o.audio, controls: true, preload: 'none'});
        v.setAttribute('playsinline', '');
        wrap.append(b, v);
        card.querySelector('.options').append(wrap);
      } else {
        card.querySelector('.options').append(b);
      }
    });
    const ta = card.querySelector('textarea');
    ta.value = d.note || '';
    ta.oninput = () => { d.note = ta.value; save(); };
    box.append(card);
  });
}

function renderAnswers() {
  const box = $('#previousList');
  box.textContent = '';
  const prev = ctx.data.previous || [];
  $('#nAnswers').textContent = prev.length || '';
  prev.forEach((c) => {
    const li = document.createElement('li');
    li.innerHTML = '<button class="chip"></button> <span></span><span class="answer"></span>';
    li.querySelector('.chip').textContent = fmt(c.t);
    li.querySelector('.chip').onclick = () => { P().stop(); P().seek(c.t); };
    li.children[1].textContent = c.text || '(הערה ריקה)';
    li.querySelector('.answer').textContent = '← ' + (c.answer || 'עוד אין תשובה');
    box.append(li);
  });
  if (!prev.length) box.innerHTML = '<p class="hint">כאן יופיע מה עשיתי עם כל הערה שלך, אחרי שתשלח.</p>';
}

function renderReport() {   // Claude's review/report.json: {summary, sections: [{title, items: [...]}]}
  const box = $('#report');
  box.textContent = '';
  const r = ctx.data.report;
  const qc = ctx.data.qc;   // verify.py's checks on the finished video (stage 5.3): green / red per check + a contact sheet
  if (qc) {
    box.append(Object.assign(document.createElement('h3'), {textContent: qc.ok ? 'בדיקות הסרטון הסופי: הכול תקין ✓' : 'בדיקות הסרטון הסופי: יש מה לבדוק'}));
    const table = document.createElement('table');
    table.className = 'qc';
    for (const q of qc.rows) {
      const tr = document.createElement('tr');
      tr.className = q.ok === true ? 'ok' : q.ok === false ? 'bad' : 'look';
      for (const text of [q.ok === true ? '✓' : q.ok === false ? '✗' : '👁', q.name, q.value, q.note]) {
        tr.append(Object.assign(document.createElement('td'), {textContent: text}));
      }
      table.append(tr);
    }
    box.append(table);
    if (qc.sheet) {
      box.append(Object.assign(document.createElement('p'), {className: 'hint', textContent: '12 רגעים מהסרטון, לבדיקה בעין:'}),
        Object.assign(document.createElement('img'), {className: 'qcsheet', src: ctx.data.files + qc.sheet, alt: '12 רגעים מהסרטון'}));
    }
  }
  if (!r) return qc ? undefined : (box.innerHTML = '<p class="hint">אין דוח לגרסה הזו.</p>');
  if (r.summary) box.append(Object.assign(document.createElement('p'), {className: 'summary', textContent: r.summary}));
  (r.sections || []).forEach((s) => {
    box.append(Object.assign(document.createElement('h3'), {textContent: s.title}));
    const ul = document.createElement('ul');
    (s.items || []).forEach((it) => ul.append(Object.assign(document.createElement('li'), {textContent: it})));
    box.append(ul);
  });
}

// ---- saving: browser at once, server debounced; the server keeps a backup before every write
let saveTimer, saving, lastFlags = {};

function payload() {
  const d = ctx.data;
  return {comments: d.comments, savedAt: d.savedAt,
    ...Object.values(ctx.modes).reduce((a, m) => ({...a, ...m.payload()}), {}),
    decisions: d.decisions.map(({id, choice, note}) => ({id, choice, note}))};
}

export function save(flags = {}) {
  ctx.data.savedAt = now();
  lastFlags = {...lastFlags, ...flags};
  try { localStorage.setItem(LOCAL_KEY, JSON.stringify(payload())); } catch {}
  status('שומר…');
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flush, 700);
}

function flush() {
  clearTimeout(saveTimer);
  saveTimer = null;
  return (saving = write());
}

async function write() {
  const body = {...payload(), ...lastFlags};
  lastFlags = {};
  try {
    const r = await fetch(API, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
    if (!r.ok) throw new Error((await r.json()).error);
    if (await flushFixes()) status('נשמר ✓');   // "saved" only when the fixes are saved too
    return true;
  } catch (e) {
    status('לא נשמר בשרת (נשמר בדפדפן): ' + e.message, true);
    return false;
  }
}

function status(text, bad = false) {
  $('#status').textContent = text;
  $('#status').classList.toggle('bad', bad);
}

const count = (k, one, many) => (k === 1 ? one : `${k} ${many}`);

async function send() {
  const d = ctx.data;
  const parts = [count(d.comments.length, 'הערה אחת', 'הערות'),
    ...Object.values(ctx.modes).flatMap((m) => m.summary(count))].filter((x) => x && !x.startsWith('0 '));
  const open = d.decisions.filter((x) => !x.choice).length;
  if (!confirm(`לשלוח לקלוד?\n${parts.join(' · ') || 'בלי שינויים'}${open ? `\n(${open} החלטות בלי בחירה: קלוד ישאיר את ההמלצה)` : ''}`)) return;
  if (!(await savedOr('השליחה'))) return;
  clearTimeout(saveTimer);   // what waits to be saved is in what is sent
  saveTimer = null;
  await saving;
  d.savedAt = now();
  try { localStorage.setItem(LOCAL_KEY, JSON.stringify(payload())); } catch {}
  try {   // saved, marked as sent and in the queue, all or nothing (the server)
    const r = await fetch(`/api/submit?video=${V}&n=${d.round}`, {method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({...payload(), ...lastFlags})});
    const res = await r.json();
    lastFlags = {};
    if (!r.ok) alert(res.error);
    else status('');
  } catch {
    alert('השמירה בשרת נכשלה. הכול שמור בדפדפן; נסה שוב בעוד רגע.');
  }
  sent();
}

// ---- following Claude's work: progress bar, lock while working, reload when a new version is out
let wasFinal = false;
const LOCKS = ['first', 'round', 'final'];   // what keeps the video from changing while it waits (jobqueue.LOCKS)
const took = (from) => Math.floor((Date.now() - new Date(from)) / 60000);
const locked = () => document.body.classList.contains('locked');

function lock(on) {   // not only by the look: nothing inside takes a key or a click
  document.body.classList.toggle('locked', on);
  document.querySelectorAll('.pane, .tools, #addComment, #track').forEach((e) => (e.inert = on));
}

async function queueAct(path) {
  const r = await fetch(`/api/queue/${path}`, {method: 'POST'});
  if (!r.ok) alert((await r.json()).error);
  sent();
}

async function poll() {
  let st;
  try { st = await (await fetch(`/api/status?video=${V}`)).json(); } catch { return; }
  if (st.latest > ctx.data.round) return location.reload();
  const quiet = ['lessons', 'post'].includes(st.job?.kind);   // learning from Ron's fixes (12.2) and a post's text never touch the video
  const job = quiet ? null : st.job, q = quiet && st.queued?.kind === 'post' ? null : st.queued;
  const working = st.starting || (job?.state === 'running' && !q);
  const final = job?.kind === 'final';   // "סרטון סופי" (12.1): no new version, the same one with the new video
  if (wasFinal && !working) return location.reload();
  wasFinal = working && final;
  // what waits says more than what failed before it
  const failed = !working && !q && (!!st.note || (job?.state === 'failed' && (job.fromRound ?? 0) >= ctx.data.round));
  const stuck = !!st.submitted && !working && !q && !failed;   // marked as sent, but in no queue: let Ron send again
  const waits = !working && !!q && LOCKS.includes(q.kind);
  lock(working || waits || !ctx.data.round);
  $('#workbar').hidden = !(working || waits || failed || stuck);
  $('#workbar').classList.toggle('failed', failed || stuck);
  $('#workbar').classList.toggle('waits', waits);
  const pill = $('#jobPill');
  pill.className = 'pill ' + (working ? 'working' : failed || stuck ? 'failed' : waits ? '' : 'review');
  pill.textContent = working ? (final ? 'מרנדר' : 'קלוד עובד') : waits ? (q.paused ? 'מושהה' : `בתור · מקום ${q.place}`)
    : failed ? 'נעצר' : stuck ? 'לא נשלח' : 'מחכה לך';
  $('#approve').hidden = !ctx.data.props || working || !!q || st.approved;
  $('#send').disabled = working || waits;
  const notes = !st.note && (stuck || (job?.entryKind || job?.kind) === 'round');   // a round: sent with what is on the page now
  $('#send').textContent = (failed || stuck) && notes ? 'לשלוח שוב' : 'סיימתי · שליחה לקלוד';
  const btn = $('#workBtn');
  btn.hidden = !(waits || (failed && !notes) || (failed && !ctx.data.round));
  btn.textContent = !waits ? 'לשלוח שוב' : ctx.data.round ? 'להסיר מהתור ולהמשיך לערוך' : 'להסיר מהתור';
  btn.onclick = () => queueAct(waits ? `remove?id=${q.id}` : `again?video=${V}`);
  if (working) {
    $('#workStep').textContent = st.starting ? 'מתחיל…' : st.progress?.step || 'קלוד עובד…';
    const min = job?.started && !st.starting ? took(job.started) : 0;
    $('#workMeta').textContent = `${st.progress?.n ? `שלב ${st.progress.n} · ` : ''}${min ? `${min} דק׳ מאז ההתחלה · ` : ''}${final ? 'הסרטון הסופי יופיע כאן לבד' : 'הגרסה החדשה תופיע כאן לבד'}`;
  } else if (waits) {
    $('#workStep').textContent = q.paused ? `התור מושהה. ${q.kind === 'final' ? 'התיקונים' : 'ההערות'} שמורים.`
      : q.kind === 'final' ? `הסרטון הסופי ממתין בתור, מקום ${q.place}` : q.kind === 'first' ? `העריכה ממתינה בתור, מקום ${q.place}`
      : `ההערות נשלחו ומחכות בתור, מקום ${q.place}`;
    $('#workMeta').textContent = q.ahead && !q.paused ? `לפניך ${q.ahead}${q.since && took(q.since) ? ` · הראשונה רצה ${count(took(q.since), 'דקה', 'דקות')}` : ''}` : '';
  } else if (stuck) {
    $('#workStep').textContent = 'השליחה לא הושלמה, וקלוד לא התחיל לעבוד.';
    $('#workMeta').textContent = 'ההערות שמורות. לוחצים "לשלוח שוב".';
  } else if (failed) {
    $('#workStep').textContent = st.note ? `לא התחיל: ${st.note}` : `העבודה נעצרה: ${job.error}`;
    $('#workMeta').textContent = 'אפשר ללחוץ "לשלוח שוב". מה שכבר נעשה נשמר.';
  }
}

// ---- final approval: the work files go (engine/cleanup.py), raw + final video + cover stay
async function approve() {
  if (!confirm('לאשר את הסרטון הזה כסופי?\n\nנשארים: הגלם, הסרטון הסופי והקאבר.\nנמחקים: קבצי העבודה שבדרך. אי אפשר לבטל, אבל אפשר לערוך מחדש מהגלם.')) return;
  const r = await fetch(`/api/approve?video=${V}`, {method: 'POST'});
  const res = await r.json();
  if (!r.ok) return alert(res.error);
  alert(`הסרטון אושר ✓ התפנו ${Math.round(res.freed_mb)}MB.`);
  location.href = '/';
}

// ---- start: newest version, keep newer browser work, build the modes, follow Claude
export async function start(loadModes) {
  const data = (ctx.data = await (await fetch(`/api/round?video=${V}`)).json().catch(() => null));
  $('#videoName').textContent = videoName;
  document.title = `חדר עריכה · ${videoName}`;
  if (!data || data.error) {   // nothing published yet: Claude is (or should be) on the first edit
    ctx.data = {round: 0, comments: [], decisions: [], previous: []};
    document.body.classList.add('no-cut', 'no-look');
    lock(true);
    $('#send').hidden = true;
    setInterval(poll, 2500);
    return poll();
  }
  API = `/api/round?video=${V}&n=${data.round}`;
  LOCAL_KEY = `room:${videoName}:${data.round}`;
  let local = null;
  try { local = JSON.parse(localStorage.getItem(LOCAL_KEY)); } catch {}
  const newer = local && local.savedAt > (data.savedAt || '');
  if (newer) {
    const picked = Object.fromEntries((local.decisions || []).map((d) => [d.id, d]));
    data.decisions.forEach((d) => Object.assign(d, {choice: picked[d.id]?.choice, note: picked[d.id]?.note}));
    delete local.decisions;
    delete local.submitted;   // whether it was sent is the server's to say (stage b1)
    Object.assign(data, local);
  }
  $('#roundName').textContent = `· גרסה ${data.round}`;
  if (data.props) {
    $('#dlVideo').href = `/download/${V}/final.mp4`;
    $('#dlCover').href = `/download/${V}/cover.jpg`;
    $('#dlExport').href = `/export?video=${V}`;
    $('#dlVideo').hidden = $('#dlCover').hidden = $('#dlExport').hidden = false;
    $('#mkShort').hidden = $('#mkBusiness').hidden = $('#mkAds').hidden = $('#moreMenu').hidden = !!ctx.data.cutdownOf;
    document.onmousedown = (e) => { if (!e.target.closest('#moreMenu')) $('#moreMenu').open = false; };   // once, however often this runs
    $('#mkAds').onclick = async () => {   // stage 11.5: the reel as an ad in 3 versions, side by side on /ads
      const st = await (await fetch(`/api/ads?video=${V}`)).json();
      if (!st.versions.length) {
        if (!confirm('ליצור מהריל מודעה ב-3 גרסאות? כל גרסה עם פתיחה, כותרת וקריאה לפעולה אחרות, וכל השאר זהה. קלוד יערוך אותן אחת אחרי השנייה.')) return;
        const r = await fetch(`/api/ads?video=${V}&n=3`, {method: 'POST'});
        if (!r.ok) return alert((await r.json()).error);
      }
      location.href = `/ads?video=${V}`;
    };   // stage 5.4: 30, 15 and 6 seconds from this reel, each a new video
    $('#mkBusiness').onclick = async () => {   // stage 11.4: the same reel, calm and professional, for LinkedIn
      if (!confirm('ליצור גרסה עסקית של הריל ללינקדאין? היא תופיע בדף הבית כסרטון חדש, וקלוד יערוך אותה בסגנון רגוע ומקצועי.')) return;
      const r = await fetch(`/api/business?video=${V}`, {method: 'POST'});
      const res = await r.json();
      alert(r.ok ? `נוצר: ${res.made}. ההתקדמות בדף הבית.` : res.error);
    };
    $('#mkShort').onclick = async () => {
      if (!confirm('ליצור 3 גרסאות קצרות מהריל הזה: 30, 15 ו-6 שניות? כל אחת תופיע בדף הבית כסרטון חדש, וקלוד יערוך אותן אחת אחרי השנייה.')) return;
      const r = await fetch(`/api/cutdowns?video=${V}&lengths=30,15,6`, {method: 'POST'});
      const res = await r.json();
      alert(r.ok ? (res.made.length ? `נוצרו: ${res.made.join(', ')}. ההתקדמות בדף הבית.` : 'הגרסאות האלה כבר קיימות.') : res.error);
    };
  }
  ctx.modes = await loadModes(data);
  document.body.classList.toggle('no-look', !ctx.modes.look);
  document.body.classList.toggle('no-cut', !ctx.modes.cut);
  if (newer) save();   // the browser had newer work than the server: push it
  renderDecisions();
  renderComments();
  renderAnswers();
  renderReport();
  status('');

  const pickRight = setupTabs($('#rightTabs'), (tab) => setMode(tab === 'cut' ? 'cut' : 'look'));
  pickRight(ctx.modes.look ? 'subs' : 'cut');
  pickLeft = setupTabs($('#leftTabs'));
  pickLeft(data.previous?.length && !data.comments.length ? 'answers' : 'comments');

  $('#play').onclick = () => (P().isPlaying() ? P().stop() : P().play());
  $('#addComment').onclick = () => addComment();
  $('#send').onclick = send;
  $('#approve').onclick = approve;
  document.addEventListener('keydown', (e) => {
    if (e.target.closest?.('textarea, input, [contenteditable="plaintext-only"], [contenteditable="true"]')) return;
    if (locked() && e.code !== 'Space') return;   // sent, or being worked on: playing is all there is
    if (e.code === 'KeyC') { e.preventDefault(); addComment(); }
    else if (e.code === 'Space') { e.preventDefault(); P().isPlaying() ? P().stop() : P().play(); }
    else ctx.stage.onKey?.(e);
  });
  window.addEventListener('beforeunload', () => { if (saveTimer) flush(); });
  poll();
  setInterval(poll, 2500);
}
