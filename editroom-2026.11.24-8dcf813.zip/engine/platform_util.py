"""What differs between Windows and Mac, in one place (stage 13.2, docs/install-spec.md 3.3)."""
import ctypes
import os
import re
import subprocess
import sys
import time

WINDOWS = os.name == "nt"
NPX = "npx.cmd" if WINDOWS else "npx"


def open_path(p):
    """Show a folder (or open a file) in Explorer / Finder."""
    if WINDOWS:
        os.startfile(p)
    else:
        subprocess.Popen(["open", str(p)])


def signer(p):
    """Who signed a downloaded program (Windows: Authenticode; a Mac: codesign), or None when it is not validly
    signed. Before the room opens an installer it downloaded (Google Drive, 23.11)."""
    try:
        if WINDOWS:
            r = subprocess.run(["powershell", "-NoProfile", "-Command",
                                f"$s = Get-AuthenticodeSignature -LiteralPath '{p}'; if ($s.Status -eq 'Valid') {{ $s.SignerCertificate.Subject }}"],
                               capture_output=True, text=True, timeout=60, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            return r.stdout.strip() or None
        r = subprocess.run(["codesign", "-dv", "--verbose=2", str(p)], capture_output=True, text=True, timeout=60)
        auth = [line.split("=", 1)[1] for line in r.stderr.splitlines() if line.startswith("Authority=")]
        return auth[0] if r.returncode == 0 and auth else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def pid_alive(pid):
    """Is this process still running? (On Windows os.kill would end it.)"""
    if not pid:
        return False
    if not WINDOWS:
        try:
            os.kill(int(pid), 0)
            return True
        except (ProcessLookupError, PermissionError, ValueError):
            return False
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(0x1000, False, int(pid))   # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return False
    code = ctypes.c_ulong()
    k32.GetExitCodeProcess(h, ctypes.byref(code))
    k32.CloseHandle(h)
    return code.value == 259   # STILL_ACTIVE


def pid_start(pid):
    """When this process was created, as a mark that a later process reusing its number will not have; None = unknown."""
    if not pid or not pid_alive(pid):
        return None
    if not WINDOWS:
        try:
            r = subprocess.run(["ps", "-o", "lstart=", "-p", str(int(pid))], capture_output=True, text=True, timeout=10)
        except (OSError, ValueError, subprocess.TimeoutExpired):
            return None
        return r.stdout.strip() or None
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(0x1000, False, int(pid))
    if not h:
        return None
    t = [ctypes.c_ulonglong() for _ in range(4)]   # created, exited, kernel, user
    ok = k32.GetProcessTimes(h, *(ctypes.byref(x) for x in t))
    k32.CloseHandle(h)
    return str(t[0].value) if ok and t[0].value else None


def boot_time():
    """When the computer was started, in seconds since 1970 (what ran before that is gone), or 0 when unknown."""
    if WINDOWS:
        tick = ctypes.windll.kernel32.GetTickCount64
        tick.restype = ctypes.c_ulonglong
        return time.time() - tick() / 1000
    try:
        r = subprocess.run(["sysctl", "-n", "kern.boottime"], capture_output=True, text=True, timeout=10)
        return float(re.search(r"sec = (\d+)", r.stdout).group(1))
    except (OSError, AttributeError, subprocess.TimeoutExpired):
        return 0.0


def lock_file(p):
    """Hold p for as long as this process lives (two rooms on one data folder): the open file, or None when another
    process has it. The caller keeps what it gets; the system lets go of it when the process ends, however it ends."""
    f = open(p, "a+b")
    try:
        if WINDOWS:
            import msvcrt
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return f
    except OSError:
        f.close()
        return None


def alert(title, text):
    """A message box when there is no window to write to (the desktop icon)."""
    if WINDOWS:
        ctypes.windll.user32.MessageBoxW(None, text, title, 0x10)
    else:
        subprocess.run(["osascript", "-e", f"display alert {quote_as(title)} message {quote_as(text)}"])


def quote_as(s):
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


if __name__ == "__main__":   # self-check
    assert pid_alive(os.getpid()) and not pid_alive(0)
    assert pid_start(os.getpid()) and pid_start(os.getpid()) == pid_start(os.getpid()) and pid_start(0) is None
    assert 0 < boot_time() < time.time()
    assert quote_as('a "b"') == '"a \\"b\\""'
    print("platform_util self-check OK", sys.platform)
