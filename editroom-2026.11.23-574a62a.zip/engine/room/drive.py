"""Google Drive intake (stage 6): videos Ron puts in fixed Drive folders show up in the room, one click brings them in.

Through Google Drive for desktop (Google's own free app), which shows Drive as a folder on this computer: no keys,
no developer account, and the room never sends anything out. Files are only read from Drive (copied in), never
moved or deleted there. The setup is a short guided list of steps on the room's top bar (Ron, 18.11).
"""
import json
import os
import shutil
import string
import threading
from pathlib import Path

import rounds

APP_DIRS = [Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Google" / "Drive File Stream",
            Path("/Applications/Google Drive.app")]   # Windows, Mac
MY_DRIVE = ("My Drive", "האחסון שלי")   # the app names it in the computer's language
FOLDER = "חדר עריכה"
SUBS = {"רילסים": "reel", "סטוריז": "story", "פודקאסטים": "podcast", "יוטיוב ארוך": "youtube", "כנסים וקורסים": "talk"}   # Drive sub-folder -> type
LONG_CAMS = {"podcast": (2, 4), "youtube": (1, 1), "talk": (1, 1)}   # cameras, fewest to most (a panel: up to 4)
NEED = {(2, 4): "בין שתיים לארבע", (1, 1): "אחת"}   # long material: a folder of cameras and mics (a long video may also be one file)
VIDEO = (".mp4", ".mov")
DOWNLOAD = "https://www.google.com/drive/download/"
copying = {}   # video name -> share done (0..1) while it comes in from Drive
failed = {}    # video name -> why its copy stopped (shown once on the page)


settings, save = rounds.settings, rounds.save_settings   # in settings.json, beside the connectors Ron added


def my_drive():
    """The "My Drive" folder the app shows on this computer, or None (not installed, or not signed in)."""
    roots = [Path(f"{d}:\\") for d in string.ascii_uppercase if Path(f"{d}:\\").exists()] if os.name == "nt" else []
    # on a Mac: ~/Library/CloudStorage/GoogleDrive-<the account's email>/ (set by macOS, F8); the email is never logged
    roots += sorted((Path.home() / "Library" / "CloudStorage").glob("GoogleDrive-*")) + [Path.home()]
    return next((r / n for r in roots for n in MY_DRIVE if (r / n).is_dir()), None)


def status():
    """Where the guided setup stands: each step done or not, in order."""
    root, folder = my_drive(), settings().get("drive", {}).get("folder")
    installed = root is not None or any(d.is_dir() for d in APP_DIRS)
    ready = bool(folder) and Path(folder).is_dir()
    return {"installed": installed, "signedIn": root is not None, "root": str(root) if root else None,
            "folder": folder if ready else None, "ready": ready, "download": DOWNLOAD,
            "subs": list(SUBS) if ready else []}


def setup():
    """Step 3: the room's folder in My Drive, with one sub-folder per kind of material. Keeps what is there."""
    root = my_drive()
    if root is None:
        raise FileNotFoundError("Google Drive")
    folder = root / FOLDER
    for sub in SUBS:
        (folder / sub).mkdir(parents=True, exist_ok=True)
    save({**settings(), "drive": {"folder": str(folder), "imported": settings().get("drive", {}).get("imported", [])}})
    return str(folder)


def disconnect():
    data = settings()
    data.pop("drive", None)
    save(data)


def inbox():
    """What waits in the Drive folders and was not brought in yet: a file per reel or story, a folder per episode."""
    st = settings().get("drive", {})
    if not st.get("folder") or not Path(st["folder"]).is_dir():
        return []
    done, base, out = set(st.get("imported", [])), Path(st["folder"]), []
    for sub, kind in SUBS.items():
        d = base / sub
        d.mkdir(exist_ok=True)   # a folder added after Ron's setup ("יוטיוב ארוך", 11.2) appears by itself
        for p in sorted(d.iterdir()):
            rel = str(p.relative_to(base))
            if rel in done or p.name.startswith("."):
                continue
            if kind in LONG_CAMS and p.is_dir():
                files = [f for f in p.rglob("*") if f.is_file()]
                cams = [f for f in files if f.suffix.lower() in VIDEO and "slides" not in f.relative_to(p).parts[:-1]]
                lo, hi = LONG_CAMS[kind]
                if files:
                    out.append({"id": rel, "kind": kind, "name": p.name, "mb": round(sum(f.stat().st_size for f in files) / 2**20),
                                "note": "" if lo <= len(cams) <= hi else f"בתיקייה {len(cams)} מצלמות. צריך {NEED[(lo, hi)]}"})
            elif kind != "podcast" and p.is_file() and p.suffix.lower() in VIDEO:
                out.append({"id": rel, "kind": kind, "name": p.stem, "mb": round(p.stat().st_size / 2**20), "note": ""})
    return out


def item(item_id):
    st = settings().get("drive", {})
    base = Path(st["folder"]).resolve()
    p = (base / item_id).resolve()
    if base not in p.parents or p.parent.name not in SUBS or not p.exists():
        raise FileNotFoundError(item_id)
    return p, SUBS[p.parent.name]


def bring_in(item_id, name, brief, done=lambda vdir: None):
    """Copy a Drive item into videos/<name>/raw (in the background: an episode is tens of GB) and remember it was
    brought in. The Drive copy stays where it is. done(vdir) runs when the copy is whole."""
    src, kind = item(item_id)
    vdir = rounds.VIDEOS / name
    if vdir.exists():
        raise FileExistsError(name)
    for sub in ("raw", "transcript", "takes", "final", "review") + (("analysis",) if kind in LONG_CAMS else ()):
        (vdir / sub).mkdir(parents=True)
    rounds.write_atomic(vdir / "review" / "brief.json", {**brief, "from_drive": item_id, "at": rounds.now()})
    files = [f for f in src.rglob("*") if f.is_file()] if src.is_dir() else [src]
    total = sum(f.stat().st_size for f in files) or 1
    copying[name] = 0.0

    def work():
        moved = 0
        try:
            for f in files:   # a .part file first, so the room never sees half a raw
                rel = f.relative_to(src) if src.is_dir() else Path(f.name)
                out = vdir / "raw" / rel
                out.parent.mkdir(parents=True, exist_ok=True)
                part = out.with_name(out.name + ".part")
                with open(f, "rb") as a, open(part, "wb") as b:
                    while chunk := a.read(8 << 20):
                        b.write(chunk)
                        moved += len(chunk)
                        copying[name] = moved / total
                part.rename(out)
            data = settings()
            data["drive"]["imported"] = sorted({*data["drive"].get("imported", []), item_id})
            save(data)
            done(vdir)
        except OSError as e:   # Drive went offline, the disk filled up: our half copy goes, Drive keeps the original
            shutil.rmtree(vdir, ignore_errors=True)
            failed[name] = str(e)
        finally:
            copying.pop(name, None)
    threading.Thread(target=work, daemon=True).start()
    return vdir


if __name__ == "__main__":
    print(json.dumps(status(), ensure_ascii=False, indent=1))
