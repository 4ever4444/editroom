// Editing room, stage "cut": play the proposed cut from the light proxy of the whole source, edit it like a
// document. Two <video>s take turns at every cut, the idle one parked on the next segment's first frame.
// data.words / data.segments are SOURCE times; "output" time is the position inside the cut.
// Stage 12.2: Ron's cut and spelling are his own fixes (review/manual.json "cut"), cut without Claude on "סרטון סופי".
import {$, commentMarkers, finalVideo, fmt, inking, inkShowAt, isActive, now, save} from './common.js';

const FOLD_MIN = 12;          // this many cut words in a row fold into one line
const MIN_SEG = 0.2;          // seconds; shorter segments are dropped

export async function cutStage(data) {
  let self;   // this mode's object; everything shared (player keys, timeline) answers only while it is active
  const words = data.words;
  const V = encodeURIComponent(data.video);
  const mine = (await (await fetch(`/api/manual?video=${V}`)).json()).manual?.cut;   // Ron's cut, saved earlier
  if (mine) Object.assign(data, {segments: mine.segments.map((x) => [...x]), fixes: {...(mine.fixes || {})}});
  let keeping = null;
  function keepCut() {   // saved as Ron's own fix at once (12.2); the same as Claude's cut = no fix
    clearTimeout(keeping);
    keeping = setTimeout(() => {
      const same = JSON.stringify(data.segments) === JSON.stringify(data.baseSegments) && !Object.keys(data.fixes).length;
      fetch(`/api/manual/cut?video=${V}`, {method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(same ? null : {segments: data.segments, fixes: data.fixes})})
        .then(async (r) => { if (!r.ok) alert((await r.json()).error); });
    }, 400);
  }
  let offs, total;
  let active = $('#vA'), idle = $('#vB'), seg = 0, playing = false;
  const snap = (t) => Math.round(t * data.fps) / data.fps;
  const mid = (w) => (w.s + w.e) / 2;
  const segs = () => data.segments;

  // ---- timeline maths
  function rebuild() {
    offs = [];
    total = 0;
    for (const [s, e] of segs()) { offs.push(total); total += e - s; }
    seg = Math.min(seg, segs().length - 1);
  }
  function locate(t) {   // output time -> [segment, source time]
    t = Math.min(Math.max(t, 0), total - 0.001);
    let i = segs().length - 1;
    while (i > 0 && offs[i] > t) i--;
    return [i, segs()[i][0] + (t - offs[i])];
  }
  // Segments play in their list order, which need not follow the raw (a later sentence may open as the hook).
  function outAt(src) {   // source time -> output time; a cut-away moment maps to the next kept piece of the raw
    const i = segs().findIndex(([s, e]) => src >= s && src < e);
    if (i >= 0) return offs[i] + src - segs()[i][0];
    const later = segs().map(([s], k) => [s, k]).filter(([s]) => s > src).sort((x, y) => x[0] - y[0])[0];
    return later ? offs[later[1]] : total;
  }
  const outTime = () => Math.max(0, offs[seg] + (active.currentTime - segs()[seg][0]));
  const included = (w) => segs().some(([s, e]) => mid(w) >= s && mid(w) < e);

  // ---- player
  const prime = (i) => { if (i < segs().length) idle.currentTime = segs()[i][0]; };

  function seek(t) {
    const [i, src] = locate(t);
    seg = i;
    active.currentTime = src;
    prime(i + 1);
    active.addEventListener('seeked', paint, {once: true});
  }

  function swap() {
    if (seg + 1 >= segs().length) return stop(true);
    seg++;
    [active, idle] = [idle, active];
    if (Math.abs(active.currentTime - segs()[seg][0]) > 0.04) active.currentTime = segs()[seg][0];
    active.muted = false;
    idle.muted = true;
    if (playing) active.play();
    active.classList.add('on');
    idle.classList.remove('on');
    idle.pause();
    prime(seg + 1);
  }

  function play() {
    if (inking()) return;
    if (outTime() >= total - 0.05) seek(0);
    playing = true;
    active.muted = false;
    active.play();
    $('#play').textContent = '❚❚';
  }

  function stop(atEnd) {
    playing = false;
    active.pause();
    $('#play').textContent = '▶';
    if (atEnd === true) active.currentTime = segs()[seg][1] - 0.001;
  }

  // ponytail: cut switching is checked per animation frame (~16ms), so a cut can show up to one extra
  // proxy frame; requestVideoFrameCallback would make it frame-exact if that ever matters in review.
  function tick() {
    if (isActive(self)) {
      if (playing && active.currentTime >= segs()[seg][1] - 0.02) swap();
      paint();
    }
    requestAnimationFrame(tick);
  }

  // ---- transcript: every word of the raw; words outside the cut are struck through
  let wordEls = [], nowWord = -1, selA = -1, selB = -1, dragSel = false, moved = false;
  const unfolded = new Set();

  function paint() {
    const t = outTime();
    $('#time').textContent = `${fmt(t)} / ${fmt(total)}`;
    $('#playhead').style.left = `${(t / total) * 100}%`;
    const src = active.currentTime;
    const i = words.findIndex((w) => src >= w.s && src < w.e);
    if (i !== nowWord) {
      wordEls[nowWord]?.classList.remove('now');
      wordEls[i]?.classList.add('now');
      if (i >= 0 && playing) wordEls[i]?.scrollIntoView({block: 'nearest', behavior: 'smooth'});
      nowWord = i;
    }
    inkShowAt(t);
  }

  function renderTranscript() {
    const box = $('#transcript');
    box.textContent = '';
    wordEls = [];
    const inc = words.map(included);
    let runEnd = -1;
    for (let i = 0; i < words.length; i++) {
      if (!inc[i] && i >= runEnd) {   // start of a run of cut words
        let j = i;
        while (j < words.length && !inc[j]) j++;
        runEnd = j;
        if (j - i >= FOLD_MIN && !unfolded.has(i)) {
          const fold = Object.assign(document.createElement('button'), {className: 'fold',
            textContent: `▸ ${j - i} מילים שנחתכו`, title: words.slice(i, i + 8).map((w) => w.w).join(' ') + ' …'});
          const start = i;
          fold.onclick = () => { unfolded.add(start); renderTranscript(); };
          box.append(fold, ' ');
          i = j - 1;
          continue;
        }
        if (j - i >= FOLD_MIN) {
          const start = i;
          const refold = Object.assign(document.createElement('button'), {className: 'fold', textContent: '▾ קפל'});
          refold.onclick = () => { unfolded.delete(start); renderTranscript(); };
          box.append(refold, ' ');
        }
      }
      if (i && inc[i] && inc[i - 1] && offs.some((o) => o > 0 && o > outAt(mid(words[i - 1])) && o <= outAt(mid(words[i])))) {
        box.append(Object.assign(document.createElement('span'), {className: 'cutmark', textContent: '✂', title: 'קאט'}));
      }
      const fixed = data.fixes[i];
      const el = Object.assign(document.createElement('span'), {
        className: 'word' + (inc[i] ? '' : ' cut') + (fixed ? ' fixed' : ''),
        textContent: fixed ?? words[i].w,
        title: fixed ? `במקור: ${words[i].w}` : '',
      });
      el.dataset.i = i;
      wordEls[i] = el;
      box.append(el, ' ');
    }
    paintSelection();
  }

  const selRange = () => (selA < 0 ? null : [Math.min(selA, selB), Math.max(selA, selB)]);

  function paintSelection() {
    const r = selRange();
    wordEls.forEach((el, i) => el?.classList.toggle('sel', !!r && i >= r[0] && i <= r[1]));
    const picked = r ? words.slice(r[0], r[1] + 1) : [];
    $('#cutBtn').disabled = !picked.some(included);
    $('#restoreBtn').disabled = !picked.some((w) => !included(w));
  }

  function clearSelection() { selA = selB = -1; paintSelection(); }

  const transcriptBox = $('#transcript');
  transcriptBox.addEventListener('pointerdown', (e) => {
    const el = e.target.closest('.word');
    if (!el || el.isContentEditable) return;
    selA = selB = +el.dataset.i;
    dragSel = true;
    moved = false;
    paintSelection();
  });
  transcriptBox.addEventListener('pointerover', (e) => {
    const el = e.target.closest('.word');
    if (dragSel && el && +el.dataset.i !== selB) { selB = +el.dataset.i; moved = true; paintSelection(); }
  });
  document.addEventListener('pointerup', (e) => {
    if (!dragSel) return;
    dragSel = false;
    const el = e.target.closest?.('.word');
    if (!moved && el) { stop(); seek(outAt(words[+el.dataset.i].s) + 0.01); }
  });
  transcriptBox.addEventListener('dblclick', (e) => {
    const el = e.target.closest('.word');
    if (el) editWord(el);
  });

  function editWord(el) {
    const i = +el.dataset.i;
    const before = el.textContent;
    el.contentEditable = 'plaintext-only';
    el.classList.add('editing');
    el.focus();
    getSelection().selectAllChildren(el);
    const finish = (keep) => {
      el.onblur = el.onkeydown = null;
      const text = el.textContent.trim().replace(/\s+/g, ' ');
      if (keep && text && text !== before) {
        if (text === words[i].w) delete data.fixes[i];
        else data.fixes[i] = text;
        data.ops.push({op: 'fix', at: now(), word: words[i].w, to: text, t: words[i].s});
        return afterCutChange();
      }
      renderTranscript();
    };
    el.onkeydown = (e) => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      if (e.key === 'Escape') finish(false);
    };
    el.onblur = () => finish(true);
  }

  // ---- cut / restore on source time
  function bounds(i, j) {   // source interval covering words i..j, split halfway into any gap to the neighbours
    const a = i > 0 && words[i - 1].e <= words[i].s ? (words[i - 1].e + words[i].s) / 2 : words[i].s;
    const b = j + 1 < words.length && words[j].e <= words[j + 1].s ? (words[j].e + words[j + 1].s) / 2 : words[j].e;
    return [snap(a), snap(b)];
  }

  function setSegments(list) {
    data.segments = list.filter(([s, e]) => e - s >= MIN_SEG).map(([s, e]) => [snap(s), snap(e)]);
    rebuild();
  }

  function cutRange(a, b) {
    const out = [];
    for (const [s, e] of segs()) {
      if (e <= a || s >= b) out.push([s, e]);
      else {
        if (s < a) out.push([s, a]);
        if (e > b) out.push([b, e]);
      }
    }
    if (!out.length) return alert('אי אפשר לחתוך את כל הסרטון.');
    setSegments(out);
  }

  function restoreRange(a, b) {   // keeps the chosen order: a restored piece goes just before the next kept piece of the raw
    let pieces = [[a, b]];
    for (const [s, e] of segs()) {   // only what isn't kept already
      pieces = pieces.flatMap(([x, y]) => (e <= x || s >= y ? [[x, y]] : [[x, Math.min(y, s)], [Math.max(x, e), y]])
        .filter(([p, q]) => q - p > 1e-6));
    }
    const list = segs().map((x) => [...x]);
    for (const [x, y] of pieces) {
      const next = list.map(([s], k) => [s, k]).filter(([s]) => s >= y - 1e-6).sort((p, q) => p[0] - q[0])[0];
      const prev = list.map(([, e], k) => [e, k]).filter(([e]) => e <= x + 1e-6).sort((p, q) => q[0] - p[0])[0];
      list.splice(next ? next[1] : prev ? prev[1] + 1 : list.length, 0, [x, y]);
    }
    const out = [];   // join neighbours in the list that continue each other in the raw
    for (const [s, e] of list) {
      const last = out.at(-1);
      if (last && s >= last[0] && s <= last[1] + 1 / data.fps) last[1] = Math.max(last[1], e);
      else out.push([s, e]);
    }
    setSegments(out);
  }

  function applyToSelection(kind) {
    const r = selRange();
    if (!r) return;
    const [a, b] = bounds(r[0], r[1]);
    const text = words.slice(r[0], r[1] + 1).map((w) => w.w).join(' ');
    stop();
    kind === 'cut' ? cutRange(a, b) : restoreRange(a, b);
    data.ops.push({op: kind, at: now(), text, from: a, to: b});
    clearSelection();
    afterCutChange();
    seek(Math.max(0, outAt(a) - 1));   // play into the change
  }

  // undo inside the cut tab (Ron 21.11: "a button in the cut itself"): every change keeps the state before it
  const state = () => ({segments: data.segments.map((x) => [...x]), fixes: {...data.fixes}});
  const back = [];
  let last = null;   // set at start
  function afterCutChange() {
    back.push(last);
    last = state();
    renderTranscript();
    renderTrack();
    save();
    keepCut();
    $('#cutUndo').disabled = false;
  }
  function undoCut() {
    if (!back.length) return;
    stop();
    const prev = back.pop();
    Object.assign(data, {segments: prev.segments.map((x) => [...x]), fixes: {...prev.fixes}});
    rebuild();
    last = state();
    data.ops.push({op: 'undo', at: now()});
    renderTranscript();
    renderTrack();
    save();
    keepCut();
    seek(Math.min(outTime(), total - 0.1));
    $('#cutUndo').disabled = !back.length;
  }
  $('#cutUndo').onclick = undoCut;

  $('#cutBtn').onclick = () => applyToSelection('cut');
  $('#cutFinal').onclick = finalVideo;
  $('#restoreBtn').onclick = () => applyToSelection('restore');
  $('#resetBtn').onclick = () => {
    if (!confirm('לבטל את כל שינויי החיתוך בסבב הזה ולחזור לחיתוך המקורי?')) return;
    stop();
    setSegments(data.baseSegments.map((x) => [...x]));
    data.ops.push({op: 'reset', at: now()});
    afterCutChange();
    seek(0);
  };

  // ---- timeline: segments in output time; drag an edge to lengthen / shorten
  const track = $('#track');

  function renderTrack() {
    track.querySelectorAll('.seg, .marker').forEach((e) => e.remove());
    segs().forEach(([s, e], i) => {
      const el = document.createElement('div');
      el.className = 'seg';
      el.style.left = `calc(${(offs[i] / total) * 100}% + 1px)`;
      el.style.width = `calc(${((e - s) / total) * 100}% - 2px)`;
      el.innerHTML = '<div class="h l" title="גרור"></div><div class="h r" title="גרור"></div>';
      el.querySelector('.l').dataset.edge = `${i}:0`;
      el.querySelector('.r').dataset.edge = `${i}:1`;
      track.append(el);
    });
    commentMarkers(track, total);
  }

  let edgeDrag = null, segDrag = null;
  track.addEventListener('pointerdown', (e) => {
    if (!isActive(self)) return;
    track.setPointerCapture(e.pointerId);
    stop();
    if (e.target.dataset.edge) {
      const [i, side] = e.target.dataset.edge.split(':').map(Number);
      edgeDrag = {i, side, x0: e.clientX, scale: total / track.clientWidth, orig: segs()[i][side]};
      track.classList.add('dragging');
    } else if (e.target.classList.contains('seg')) {   // a piece: a short press scrubs, a drag moves it (12.2)
      segDrag = {i: [...track.querySelectorAll('.seg')].indexOf(e.target), el: e.target, x0: e.clientX, moved: false};
    } else scrub(e);
  });
  track.addEventListener('pointermove', (e) => {
    if (!isActive(self)) return;
    if (edgeDrag) dragEdge(e);
    else if (segDrag) {
      segDrag.moved ||= Math.abs(e.clientX - segDrag.x0) > 5;
      if (segDrag.moved) segDrag.el.style.transform = `translateX(${e.clientX - segDrag.x0}px)`;
    } else if (e.buttons) scrub(e);
  });
  track.addEventListener('pointerup', (e) => {
    if (segDrag) {
      const {i, moved} = segDrag;
      segDrag = null;
      if (!moved) return scrub(e);
      const r = track.getBoundingClientRect();
      const to = locate(((e.clientX - r.left) / r.width) * total)[0];   // the piece it was dropped on
      const list = segs().map((x) => [...x]);
      const [piece] = list.splice(i, 1);
      list.splice(to, 0, piece);
      setSegments(list);
      data.ops.push({op: 'move', at: now(), segment: i + 1, to: to + 1});
      afterCutChange();
      return seek(offs[to]);
    }
    if (!edgeDrag) return;
    const {i, side, orig} = edgeDrag;
    edgeDrag = null;
    track.classList.remove('dragging');
    const moved_ = segs()[i]?.[side];
    if (moved_ !== undefined && moved_ !== orig) {
      data.ops.push({op: 'trim', at: now(), segment: i + 1, edge: side ? 'end' : 'start', from: orig, to: moved_});
      afterCutChange();
    }
  });

  function scrub(e) {
    const r = track.getBoundingClientRect();
    seek(((e.clientX - r.left) / r.width) * total);
  }

  function dragEdge(e) {
    const {i, side, x0, scale, orig} = edgeDrag;
    const list = segs();
    const [s, en] = list[i];
    const v = orig + (e.clientX - x0) * scale;
    // never into another kept piece of the raw, wherever that piece plays in the video
    const others = list.filter((_, k) => k !== i);
    const ceil = Math.min(data.sourceDuration, ...others.map(([os]) => os).filter((os) => os >= en - 1e-6));
    const floor = Math.max(0, ...others.map(([, oe]) => oe).filter((oe) => oe <= s + 1e-6));
    if (side) list[i][1] = snap(Math.min(Math.max(v, s + MIN_SEG), ceil));
    else list[i][0] = snap(Math.max(Math.min(v, en - MIN_SEG), floor));
    rebuild();
    renderTrack();
    seek(side ? offs[i] + list[i][1] - list[i][0] - 0.02 : offs[i]);   // show the frame at the edge
  }

  // ---- start
  rebuild();
  last = state();
  active.src = idle.src = data.proxy;
  active.addEventListener('loadedmetadata', () => seek(0), {once: true});
  renderTranscript();
  requestAnimationFrame(tick);

  return (self = {
    activate: (t) => { renderTrack(); seek(Math.min(t, total)); },
    player: {outTime, total: () => total, seek, play, stop, isPlaying: () => playing, srcTime: () => active.currentTime},
    payload: () => ({ops: data.ops}),   // the cut and spelling themselves are Ron's own fix (manual.json "cut")
    renderTrack,
    summary: (count) => [count(data.ops.filter((o) => o.op !== 'fix').length, 'שינוי חיתוך אחד', 'שינויי חיתוך'),
      count(Object.keys(data.fixes).length, 'תיקון כתיב אחד', 'תיקוני כתיב')],
    onKey: (e) => {
      if ((e.ctrlKey || e.metaKey) && e.code === 'KeyZ') { e.preventDefault(); undoCut(); }
      if ((e.key === 'Delete' || e.key === 'Backspace') && selRange()) { e.preventDefault(); applyToSelection('cut'); }
      if (e.key === 'Escape') clearSelection();
    },
  });
}
