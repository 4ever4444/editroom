"""What differs between Windows and Mac, in one place (stage 13.2, docs/install-spec.md 3.3)."""
import ctypes
import os
import subprocess
import sys

WINDOWS = os.name == "nt"
NPX = "npx.cmd" if WINDOWS else "npx"


def open_path(p):
    """Show a folder (or open a file) in Explorer / Finder."""
    if WINDOWS:
        os.startfile(p)
    else:
        subprocess.Popen(["open", str(p)])


def pid_alive(pid):
    """Is this process still running? (On Windows os.kill would end it.)"""
    if not pid:
        return False
    if not WINDOWS:
        try:
            os.kill(int(pid), 0)
            return True
        except (ProcessLookupError, PermissionError, ValueError):
            return False
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(0x1000, False, int(pid))   # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return False
    code = ctypes.c_ulong()
    k32.GetExitCodeProcess(h, ctypes.byref(code))
    k32.CloseHandle(h)
    return code.value == 259   # STILL_ACTIVE


def alert(title, text):
    """A message box when there is no window to write to (the desktop icon)."""
    if WINDOWS:
        ctypes.windll.user32.MessageBoxW(None, text, title, 0x10)
    else:
        subprocess.run(["osascript", "-e", f"display alert {quote_as(title)} message {quote_as(text)}"])


def quote_as(s):
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


if __name__ == "__main__":   # self-check
    assert pid_alive(os.getpid()) and not pid_alive(0)
    assert quote_as('a "b"') == '"a \\"b\\""'
    print("platform_util self-check OK", sys.platform)
