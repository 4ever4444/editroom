"""Library blocks in a reel (stage 5.1): a HyperFrames block from fx-library, adapted for this video, rendered as a
see-through layer over the picture, under the subtitles and title.

usage: python engine/hf_layer.py add "videos/<name>" <id> <block name>   (copy the block to videos/<name>/hf/<id>.html,
                                                                   to adapt: Hebrew text, dir="rtl", colours)
       python engine/hf_layer.py render "videos/<name>"            (render every graphics.json "hf" item)
       python engine/hf_layer.py studio [<effect id>]           (the studio's effect instructions, to build one as a block)

graphics.json "hf": [{"id", "name": <block>, "from": <phrase | seconds>, "dur"?: <seconds, default the block's own>,
                      "x": 0, "y": <top, in 1080x1920>, "width": <px, default 1080>}]
Each item renders once per change to takes/hf/<id>.mov (ProRes 4444, alpha: render.py lays it in) and
takes/hf/<id>.webm (VP9 alpha: the room plays it). The block is shrunk to `width` and placed at x/y.
"""
import hashlib
import json
import re
import shutil
import sys
from pathlib import Path

import fxlib
import paths
import tools
import vendor
from media import read_json

HOST = """<!doctype html>
<html lang="he"><head><meta charset="UTF-8" /><meta name="viewport" content="width=1080, height=1920" />
<script src="/vendor/gsap.min.js"></script>
<style>*{{margin:0;padding:0;box-sizing:border-box}}html,body{{width:1080px;height:1920px;overflow:hidden;background:transparent}}
#place{{position:absolute;left:{x}px;top:{y}px;width:{bw}px;height:{bh}px;transform:scale({s});transform-origin:0 0}}</style>
</head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{d}" data-width="1080" data-height="1920">
<div id="place"><div data-composition-id="{cid}" data-composition-src="compositions/_v/{file}" data-start="0"
 data-duration="{d}" data-width="{bw}" data-height="{bh}"></div></div>
</div>
<script>const tl = gsap.timeline({{paused: true}}); window.__timelines["main"] = tl; tl.seek(0);</script>
</body></html>
"""


STUDIO_FX = Path(__file__).parent / "studio" / "effects.json"   # the studio's 18 effects: instructions to build


def block_info(name, html=""):
    """(width, height, seconds) of a block: from the block itself first (its root says data-width/height/duration;
    the same as the library's catalog for all 202 blocks, checked 23.11), so a video renders the same on a
    computer that has no library installed (found in the 13.3 trial: the block was placed as a reel frame and fell
    off screen); then the catalog; a block Claude built from a studio effect is a full reel frame."""
    item = fxlib.catalog().get(name or "", {}).get("registry") or {}
    w, h = fxlib.shape(item) or (1080, 1920)
    d = float(item.get("duration") or 5)
    size = re.search(r'data-width="(\d+)"\s+data-height="(\d+)"', html)
    if size:
        w, h = int(size.group(1)), int(size.group(2))
        if dur := re.search(r'data-duration="([\d.]+)"', html):
            d = float(dur.group(1))
    return w, h, d


def studio_fx(fx_id=None):
    """The studio's effect instructions (engine/studio/effects.json), for a job to build one from."""
    fx = json.loads(STUDIO_FX.read_text(encoding="utf-8"))
    return [f for f in fx if fx_id in (None, f["id"])]


def add(vdir, item_id, name):
    src = fxlib.LIB / "compositions" / f"{name}.html"
    if not src.exists():
        raise SystemExit(f"אין בספרייה רכיב בשם {name}")
    out = Path(vdir) / "hf" / f"{item_id}.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, out)
    print(out)
    return out


def host(item, html):
    w, h, d = block_info(item.get("name"), html)
    width = float(item.get("width", 1080))
    s = width / w
    cid = re.search(r'data-composition-id="([^"]+)"', html).group(1)   # the block's own id, as its timeline knows it
    return HOST.format(x=item.get("x", 0), y=item.get("y", 960 - h * s / 2), bw=w, bh=h, s=f"{s:.5f}",
                       d=item.get("dur", d), cid=cid, file=f"{item['id']}.html")


def render(vdir):
    """Every graphics.json "hf" item -> takes/hf/<id>.mov + .webm, re-rendered only when its block or place changed."""
    vdir = Path(vdir)
    g = read_json(vdir / "graphics.json")
    out_dir = vdir / "takes" / "hf"
    out_dir.mkdir(parents=True, exist_ok=True)
    made = []
    for item in g.get("hf", []):
        html = (vdir / "hf" / f"{item['id']}.html").read_text(encoding="utf-8")
        page = host(item, html)
        key = hashlib.sha1((html + page).encode()).hexdigest()[:16]
        mov, webm, stamp = out_dir / f"{item['id']}.mov", out_dir / f"{item['id']}.webm", out_dir / f"{item['id']}.key"
        if not (mov.exists() and webm.exists() and stamp.exists() and stamp.read_text() == key):
            v = paths.HF_STAGE / "compositions" / "_v"   # ponytail: one shared render stage; renders run one at a time
            v.mkdir(parents=True, exist_ok=True)   # an installed stage starts empty (13.3 trial run)
            (v / f"{item['id']}.html").write_text(vendor.local(html), encoding="utf-8")
            (paths.HF_STAGE / "index.html").write_text(page, encoding="utf-8")
            tools.hf_render(paths.HF_STAGE, mov)
            tools._run(tools.FFMPEG, "-y", "-loglevel", "error", "-i", mov, "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p",
                       "-b:v", "2M", "-an", webm)
            stamp.write_text(key)
        made.append({"id": item["id"], "mov": mov, "webm": webm})
    return made


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if sys.argv[1] == "add":
        add(sys.argv[2], sys.argv[3], sys.argv[4])
    elif sys.argv[1] == "studio":   # python engine/hf_layer.py studio [<effect id>]: the instructions to build it from
        for f in studio_fx(sys.argv[2] if len(sys.argv) > 2 else None):
            print(f"## {f['id']} ({f['category']})\n{f['instructions']}\n")
    else:
        print(json.dumps([{k: str(v) for k, v in m.items()} for m in render(sys.argv[2])], ensure_ascii=False))
