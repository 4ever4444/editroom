"""Every folder the system reads or writes, in one place (stage 13.1, docs/install-spec.md 3.2).

Without EDITROOM_HOME (Ron's computer, the git folder): everything sits where it always did, beside the code.
With EDITROOM_HOME=<root> (an installed computer): the code is <root>/app, the user's own files <root>/data,
which an update never touches, and the tools <root>/runtime. That root must be an English-only path (R6),
because some tools break on a Hebrew one; names inside data/ (videos, clients) may be Hebrew.
"""
import os
import sys
from pathlib import Path

APP = Path(__file__).resolve().parents[1]
# an installed system is <root>/app beside <root>/editroom.json (the installer writes it), so the desktop icon needs
# no setting of its own; EDITROOM_HOME says the same thing explicitly (tests, the installer's own checks)
HOME = os.environ.get("EDITROOM_HOME") or (str(APP.parent) if (APP.parent / "editroom.json").is_file() else None)


def english_only(p):
    """Refuse a root the tools would break on: anything but plain ASCII letters, digits and path signs."""
    if not str(p).isascii():
        raise SystemExit(f"תיקיית המערכת חייבת להיות בשם באנגלית בלבד: {p}")
    return p


if HOME:
    ROOT = english_only(Path(HOME).resolve())
    DATA = ROOT / "data"
    USER_LIB = DATA / "library-user"   # what the user adds: songs, images, inspirations, what Claude learned
    FX_LIB = DATA / "fx-library"       # the 448 HyperFrames blocks, if installed (optional)
    RUNTIME = english_only(ROOT / "runtime")
    HF_STAGE = RUNTIME / "hf-stage"    # where logos, end cards and blocks render, always there with HyperFrames
    MODELS = ROOT / "models"
    LOGS = ROOT / "logs"
else:
    ROOT = DATA = APP
    USER_LIB = APP / "library"
    FX_LIB = HF_STAGE = APP / "fx-library"
    RUNTIME = APP
    MODELS = APP / "models"
    LOGS = APP / "engine" / "room"   # server.log where it always was

LIBRARY = APP / "library"   # the system's own: fonts, sounds, icons (Remotion's public dir)
VIDEOS = DATA / "videos"
CLIENTS = DATA / "clients"
DELIVER = DATA / "deliveries"
TRASH = DATA / "trash"
SETTINGS = DATA / "settings.json"
MUSIC = USER_LIB / "music"
BROLL = USER_LIB / "broll"
INSP = USER_LIB / "inspiration"
LESSONS = USER_LIB / "lessons.json"
GRAPHICS_LOG = USER_LIB / "graphics-log.json"
WISHLIST = USER_LIB / "effects-wishlist.json"

# the python the room runs on: its own venv (Ron's .venv, or the installed version's environment)
_BIN = Path(sys.prefix) / ("Scripts" if os.name == "nt" else "bin")
PYTHON = _BIN / ("python.exe" if os.name == "nt" else "python")
PYTHONW = _BIN / ("pythonw.exe" if os.name == "nt" else "python")


def setup_env():
    """On an installed computer: the system's own tools first on PATH (not whatever else the computer has), and
    temporary files under the root, never under a Hebrew user name (R6). Every program started afterwards inherits
    it. Nothing changes on Ron's computer."""
    if not HOME:
        return
    tmp = RUNTIME / "tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    bins = [RUNTIME / "node", RUNTIME / "ffmpeg"] if os.name == "nt" else [RUNTIME / "node" / "bin", RUNTIME / "ffmpeg"]
    cache = RUNTIME / ".cache"   # HyperFrames keeps its browser, fonts and models in the home folder otherwise
    os.environ.update(EDITROOM_HOME=str(ROOT), TEMP=str(tmp), TMP=str(tmp), TMPDIR=str(tmp),
                      HYPERFRAMES_CACHE_DIR=str(cache / "hyperframes"), HYPERFRAMES_CONFIG_DIR=str(cache / "hyperframes-config"),
                      HYPERFRAMES_MEDIA_HOME=str(cache / "hyperframes-media"),
                      PATH=os.pathsep.join([*map(str, bins), str(_BIN), os.environ.get("PATH", "")]))


def for_claude(p, rel):
    """How a Claude job (run in APP) names a folder: as today, relative, on Ron's computer; else absolute with
    forward slashes, the form Claude Code's permission rules and Git Bash both take."""
    return rel if not HOME else Path(p).as_posix()


# what the job prompts say instead of a fixed path (engine/room/jobs.py fills them)
PROMPT_PATHS = {"{PY}": for_claude(PYTHON.with_suffix(""), ".venv/Scripts/python"), "{VIDEOS}": for_claude(VIDEOS, "videos"),
                "{LIB}": for_claude(USER_LIB, "library"), "{FXLIB}": for_claude(FX_LIB, "fx-library")}


def rule(p, rel):
    """A permission rule's path: ./<rel> on Ron's computer, //<drive>/... (absolute) on an installed one."""
    if not HOME:
        return f"./{rel}"
    s = Path(p).as_posix()
    return "//" + s[0].lower() + s[2:] if len(s) > 1 and s[1] == ":" else "/" + s


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for k, v in sorted(globals().items()):
        if k.isupper() and not k.startswith("_") and isinstance(v, (Path, dict)):
            print(f"{k:13} {v}")
