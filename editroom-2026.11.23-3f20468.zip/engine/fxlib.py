"""The effects library (stage 5.1): every HyperFrames registry item, installed, checked, and given a status per network.

usage: python engine/fxlib.py install     (download what is missing; Ron approved the download, 18.11: code only)
       python engine/fxlib.py check [name ...]   (preview frames + status; all items when no names)
       python engine/fxlib.py list      (one line per item: name, type, size, status per network)

fx-library/ is a HyperFrames project outside library/ (Remotion copies library/ into every bundle) and outside git
(registry code, rebuilt on any machine). fx-library/catalog.json = the registry's own list + our check results.
Telemetry and update checks are off for every call (tools._run's environment).
"""
import json
import shutil
import sys

import paths
import tools
import vendor

LIB = paths.FX_LIB
CLI = tools.HF_CLI
BATCH = 30
# the networks Ron publishes on first (18.11) and the frame shapes each one shows
NETWORKS = {"instagram": {"label": "אינסטגרם", "ratios": [(9, 16), (4, 5), (1, 1)]},
            "tiktok": {"label": "טיקטוק", "ratios": [(9, 16)]},
            "shorts": {"label": "יוטיוב שורטס", "ratios": [(9, 16)]},
            "youtube": {"label": "יוטיוב", "ratios": [(16, 9)]}}
# kinds of item that have no place in a talking-head reel or podcast
NOT_OURS = {"code", "developer", "mock-ui", "chat", "product-demo", "ui-props", "cursor", "map", "maps"}


def hf(*args, timeout=900):
    return tools._run(tools.NODE, CLI, *args, timeout=timeout)


def registry():
    return json.loads(hf("catalog", "--json").lstrip("﻿"))


def catalog():
    p = LIB / "catalog.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def save(cat):
    (LIB / "catalog.json").write_text(json.dumps(cat, ensure_ascii=False, indent=1), encoding="utf-8")


def installed():
    return {i["name"] for i in json.loads((LIB / "hyperframes.json").read_text(encoding="utf-8")).get("registryItems", [])}


def install():
    if not (LIB / "hyperframes.json").exists():
        sys.exit("fx-library is missing: hyperframes init fx-library --example blank --non-interactive --skip-skills")
    cat = catalog()
    for item in registry():
        cat.setdefault(item["name"], {}).update(registry=item)
    save(cat)
    todo = sorted(set(cat) - installed())
    for k in range(0, len(todo), BATCH):
        names = todo[k:k + BATCH]
        try:
            hf("add", *names, "--dir", LIB, "--json", "--no-clipboard")
        except RuntimeError as e:   # one bad item must not stop the rest: try them one by one
            for n in names:
                try:
                    hf("add", n, "--dir", LIB, "--json", "--no-clipboard")
                except RuntimeError:
                    cat[n]["install_error"] = str(e)[-300:]
        print(f"installed {min(k + BATCH, len(todo))}/{len(todo)}", flush=True)
    save(cat)
    print(f"{len(installed())} of {len(cat)} items installed")


def shape(item):
    d = item.get("dimensions") or {}
    w, h = d.get("width"), d.get("height")
    return (w, h) if w and h else None


def statuses(item, rendered):
    """Per network: ready (its frame shape fits as it is), adapt (works, other shape or needs a look in Hebrew),
    not-ours (a kind of item our videos have no use for), broken (it did not render)."""
    if not rendered:
        return {n: "broken" for n in NETWORKS}
    if NOT_OURS & set(item.get("tags", [])):
        return {n: "not-ours" for n in NETWORKS}
    s = shape(item)
    out = {}
    for n, spec in NETWORKS.items():
        fits = s and any(abs(s[0] * b - s[1] * a) < 2 * max(a, b) for a, b in spec["ratios"])
        out[n] = "ready" if fits else "adapt"
    return out


HOST = """<!doctype html>
<html lang="he"><head><meta charset="UTF-8" /><meta name="viewport" content="width={w}, height={h}" />
<script src="/vendor/gsap.min.js"></script>
<style>*{{margin:0;padding:0;box-sizing:border-box}}html,body{{width:{w}px;height:{h}px;overflow:hidden;background:#3a3a44}}</style>
</head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{d}" data-width="{w}" data-height="{h}">
{mount}
</div>
<script>const tl = gsap.timeline({{paused: true}}); window.__timelines["main"] = tl; tl.seek(0);</script>
</body></html>
"""


def check(name):
    """Mount one block alone on a grey stage of its own size, take 3 stills (a quarter in, the middle, near the end)
    into fx-library/previews/<name>/, and set its status per network. A block that does not render is "broken"."""
    cat = catalog()
    c = cat[name]
    item = c["registry"]
    w, h = shape(item) or (1080, 1920)
    d = float(item.get("duration") or 5)
    out = LIB / "previews" / name
    shutil.rmtree(out, ignore_errors=True)
    if item["type"] != "block":   # a component is a snippet for a scene, not a scene: its preview needs a host scene
        c.update(rendered=None, status={n: "adapt" for n in NETWORKS} if not NOT_OURS & set(item.get("tags", []))
                 else {n: "not-ours" for n in NETWORKS})
        save(cat)
        return c
    mount = (f'<div data-composition-id="{name}" data-composition-src="compositions/{name}.html" data-start="0" '
             f'data-duration="{d}" data-width="{w}" data-height="{h}"></div>')
    (LIB / "index.html").write_text(HOST.format(w=w, h=h, d=d, mount=mount), encoding="utf-8")
    vendor.into(LIB)
    at = ",".join(f"{d * f:.2f}" for f in (0.25, 0.5, 0.85))
    try:
        hf("snapshot", LIB, "--at", at, "--no-end", "--output", out, "--timeout", "60000", timeout=300)
        for png in out.glob("*.png"):   # small JPEGs for the page: 448 items x 3 stills at full size is far too heavy
            tools._run(tools.FFMPEG, "-y", "-loglevel", "error", "-i", png, "-vf", "scale=480:-2", "-q:v", "4",
                       png.with_suffix(".jpg"))
            png.unlink()
        (out / "contact-sheet.jpg").unlink(missing_ok=True)
        stills = sorted(p.name for p in out.glob("frame-*.jpg"))
    except RuntimeError as e:
        stills, c["error"] = [], str(e)[-400:]
    c.update(rendered=bool(stills), stills=stills, status=statuses(item, bool(stills)))
    if stills:
        c.pop("error", None)
    save(cat)
    return c


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    cmd = sys.argv[1]
    if cmd == "install":
        install()
    elif cmd == "check":
        names = sys.argv[2:] or sorted(installed())
        for k, n in enumerate(names, 1):
            r = check(n)
            print(f"{k}/{len(names)} {n}: {'ok' if r.get('rendered') else r.get('rendered')} {r.get('status')}", flush=True)
    elif cmd == "list":
        for name, c in sorted(catalog().items()):
            r = c.get("registry", {})
            print(name, r.get("type"), shape(r), c.get("status"))
