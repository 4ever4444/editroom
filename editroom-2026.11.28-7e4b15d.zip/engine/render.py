"""Graphics (Remotion) + cut video -> final/final.mp4, plus two cover versions.

usage: python engine/render.py "videos/<name>"
reads takes/edit.mkv, takes/edit_words.json, takes/takes.json ("text"), graphics.json

Picture effects (graphics.json "effects") are rendered only over the frames where they act: the "Effects"
composition (cut video + effects) is rendered per merged range and laid onto edit.mkv by ffmpeg, under the
same Overlay as always. A video without effects takes exactly the old path.
"""
import os
import re
import shutil
import subprocess
import sys
from fractions import Fraction
from pathlib import Path

import av

import hf_layer
import hfrequest
import endcard
import logo
import manual
import paths
import platform_util
import music
from media import ffmpeg, probe, read_json, write_json
from subtitles import SENTENCE, attach_text, norm, pages

REMOTION = Path(__file__).parent / "remotion"
LIBRARY = paths.LIBRARY
# Instagram UI covers these (x0, y0, x1, y1); nothing may be drawn there
UNSAFE = [(0, 0, 1080, 250), (0, 1580, 1080, 1920), (960, 1100, 1080, 1700)]
COVER_CROP = (240, 1680)   # 3:4 grid crop rows


class Stop(ValueError):
    """graphics.json asks for something the machine can't do as written: the version is not rendered or published."""


def catalog_kinds():
    """The kinds the Remotion code knows, read from the two catalog files (running them needs a browser)."""
    fx = (REMOTION / "src" / "effects" / "index.ts").read_text(encoding="utf-8")
    gfx = (REMOTION / "src" / "graphics" / "index.ts").read_text(encoding="utf-8")
    effects = re.findall(r"^  (\w+): \{", fx.split("export const EFFECTS", 1)[1], re.M)
    graphics = re.findall(r"\w+", re.search(r"export const GRAPHICS[^=]*= \{([^}]*)\}", gfx).group(1))
    return effects, graphics


def check_kinds(g):
    effects, graphics = catalog_kinds()
    for lst, known, other, what in (("motion", graphics, effects, "הגרפיקה"), ("effects", effects, graphics, "האפקט")):
        for m in g.get(lst, []):
            if m["kind"] in known:
                continue
            if m["kind"] in other:
                raise Stop(f"graphics.json: '{m['kind']}' (id: {m['id']}) רשום ב-{lst} אבל הוא "
                           f"{'אפקט' if lst == 'motion' else 'גרפיקה'}. להעביר אותו ל-{'effects' if lst == 'motion' else 'motion'}.")
            raise Stop(f"graphics.json: {what} '{m['kind']}' (id: {m['id']}) לא קיים בקטלוג. קיימים: {', '.join(known)}. "
                       "כדי להוסיף: לבנות ולרשום בקטלוג, או להשתמש בקרוב ביותר ולרשום את הבקשה ב-library/effects-wishlist.json.")


MAX_DUR_S = 15   # a graphic or effect longer than this is a length written in frames, not seconds (6 videos, fixed 21.11)


def check_durations(g):
    """graphics.json "dur" is in seconds. A number of frames there (60 = 2 s) kept graphics on screen to the end."""
    for lst in ("motion", "effects"):
        for m in g.get(lst, []):
            if m.get("kind") != "Look" and float(m.get("dur", 0)) > MAX_DUR_S:   # a look may cover the whole video
                raise Stop(f"graphics.json: {m['id']} באורך {m['dur']} שניות. dur הוא בשניות, לא בפריימים "
                           f"(60 פריימים = 2 שניות). גרפיקה או אפקט עד {MAX_DUR_S} שניות; ארוך יותר = until.")


def remotion(*args):
    subprocess.run([platform_util.NPX, "remotion", *map(str, args), f"--public-dir={LIBRARY}"], cwd=REMOTION, check=True)


def npx_remotion(*args):
    subprocess.run([platform_util.NPX, "remotion", *map(str, args)], cwd=REMOTION, check=True)


def alpha_outside(img_rgba, zones, threshold=40):
    """Zones where the graphic layer has visible pixels."""
    a = img_rgba[..., 3]
    return [z for z in zones if (a[z[1]:z[3], z[0]:z[2]] > threshold).any()]


def check_overlay(path, step=5):
    bad = {}
    with av.open(str(path)) as c:
        for i, f in enumerate(c.decode(video=0)):
            if i % step == 0:
                for z in alpha_outside(f.to_ndarray(format="rgba"), UNSAFE):
                    bad.setdefault(z, i)
    print("safe zones:", "OK" if not bad else f"VIOLATIONS {bad} (zone: first frame)")
    return bad


def frame_count(path):
    with av.open(str(path)) as c:
        return sum(1 for p in c.demux(video=0) if p.pts is not None)


LEAD_S, TAIL_S = 0.15, 0.4   # a graphic starts just before its phrase and lingers just after it


def find_phrase(words, phrase, start=0):
    """Index range of the first occurrence of `phrase` (whole words, punctuation ignored) from `start`."""
    want = [norm(t) for t in phrase.split()]
    have = [norm(w["w"]) for w in words]
    for i in range(start, len(have) - len(want) + 1):
        if have[i:i + len(want)] == want:
            return i, i + len(want) - 1
    raise ValueError(f"phrase not found in the cut: {phrase}")


def resolve_motion(motion, words, fps, frames, lost=None):
    """graphics.json "motion" (anchored to spoken phrases) -> frames. Nested {"at": phrase} become
    frame offsets inside the graphic. "from" may also be seconds, when Ron names an exact moment.
    lost: a list, when Ron cut the video himself (stage 12.2): a graphic whose phrase he cut out is left out and
    named there, instead of stopping the render."""
    out = []
    for m in motion:
        try:
            out.append(resolve_one(m, words, fps, frames))
        except ValueError:
            if lost is None:
                raise
            lost.append(m.get("label", m["id"]))
    return out


def resolve_one(m, words, fps, frames):
    """One graphic of graphics.json -> frames; ValueError when its phrase is not in the cut."""
    if isinstance(m["from"], (int, float)):
        start = float(m["from"])
        i = next((k for k, w in enumerate(words) if w["e"] > start), len(words) - 1)
    else:
        i, j = find_phrase(words, m["from"])
        start = max(0.0, words[i]["s"] - m.get("lead", LEAD_S))
    end = start + m["dur"] if "dur" in m else words[find_phrase(words, m["until"], i)[1]]["e"] + TAIL_S
    first = round(start * fps)

    def at(v):
        if isinstance(v, dict):
            return {k: (round((words[find_phrase(words, x, i)[0]]["s"] - start) * fps) if k == "at" and isinstance(x, str)
                        else at(x)) for k, x in v.items()}
        return [at(x) for x in v] if isinstance(v, list) else v
    return {"id": m["id"], "kind": m["kind"], "label": m.get("label", m["kind"]), "from": first,
            "dur": min(round(end * fps), frames) - first, "props": at(m.get("props", {}))}


def hf_html(video_dir, h):
    f = Path(video_dir) / "hf" / f"{h['id']}.html"
    return f.read_text(encoding="utf-8") if f.exists() else ""


def build_props(video_dir, fps, frames, mine=True):
    """Everything the Overlay composition needs; the room's Preview gets the same object. mine: with Ron's own fixes
    (review/manual.json, stage 12.1) over it; the room gets it without them and lays them on itself (room/manual.js)."""
    edit = read_json(video_dir / "takes" / "edit_words.json")["words"]
    words = attach_text(edit, read_json(video_dir / "takes" / "takes.json")["text"])
    g = read_json(video_dir / "graphics.json")
    check_kinds(g)
    check_durations(g)
    ids = [m["id"] for m in g.get("motion", []) + g.get("effects", [])]
    if dups := sorted({i for i in ids if ids.count(i) > 1}):   # hide / show in the room works by id
        raise Stop(f"graphics.json: the same id is used twice (motion and effects share ids): {dups}")
    if mine_ids := [h["id"] for h in g.get("motion", []) + g.get("effects", []) + g.get("hf", []) if str(h.get("id")).startswith("mine-")]:
        raise Stop(f"graphics.json: ids that start with mine- are Ron's own additions (manual.json), never graphics.json: {mine_ids}")
    first_end = next((w["e"] for w in words if w["w"].endswith((".", "?", "!"))), words[min(len(words), 8) - 1]["e"])   # a cut without a full stop (12.2)
    longer = SENTENCE if g.get("captions") == "sentence" else ()   # stage 11.4: a business version
    mine_fixes = manual.load(video_dir)
    lv = manual.live(video_dir, mine_fixes)   # stage f: where Ron's added items go on this cut, and which can't
    lost = [] if mine_fixes.get("cut") else None   # Ron cut it himself (12.2): a graphic he cut the phrase of is left out
    blocks, block_lost = hf_layer.items(video_dir)   # stage f2: a block for a request only once made and checked (Δ90)
    own = lambda h: h.get("dur", hf_layer.block_info(h.get("name"), hf_html(video_dir, h))[2])
    link = {h["id"]: {"request": h["request"], "ready": True, "own": round(own(h) * fps)} for h in blocks if h.get("request")}
    props = {"fps": fps, "durationInFrames": frames, "pages": pages(words, *longer), "title": g["title"], "titleEnd": first_end,
            "graphics": resolve_motion(g.get("motion", []), words, fps, frames, lost), "hidden": g.get("hidden", []),
            "effects": resolve_motion(g.get("effects", []), words, fps, frames, lost),
            # library blocks (stage 5.1, engine/hf_layer.py): their own length unless graphics.json gives one
            "hf": [{**h, **link.get(h["id"], {})} for h in resolve_motion([{**h, "kind": "hf", "dur": own(h)} for h in blocks],
                                                                         words, fps, frames, lost)],
            "blockLost": block_lost, "library": lv["library"], "requestStates": hfrequest.shown(video_dir, alive=True),
            "logo": logo.resolve(g, fps, frames, first_end),   # the client's logo (stage 8), laid in like a library block
            "endcard": g["logo"] if (g.get("logo") or {}).get("end") else None,   # its end (stage 11.6), for the room's preview
            "lost": lost or [], "clock": lv["clock"], "known": lv["known"], "labels": lv["labels"], "addedBad": lv["bad"]}
    return manual.apply(props, mine_fixes) if mine else props


def effect_ranges(effects, hidden):
    """Frame ranges [a, b) to render the picture layer over: visible effects only, overlapping ones merged."""
    spans = sorted((e["from"], e["from"] + e["dur"]) for e in effects if e["id"] not in hidden and e["dur"] > 0)
    merged = []
    for a, b in spans:
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return merged


def picture_mp4(src, dst, fps):
    """The picture of src as mp4: same frames (no re-encoding), no sound, every frame on its exact time.
    mkv rounds times to the millisecond (frame 2 at 67ms, not 66.67); Remotion then sometimes shows the frame
    before it twice. So each time snaps to the frame grid, in a time base that holds it exactly."""
    fps = Fraction(fps).limit_denominator(1001)
    grid = f"round({{}}*TB*{fps.numerator}/{fps.denominator})"
    ffmpeg("-i", src, "-map", "0:v", "-c", "copy", "-video_track_timescale", fps.numerator,
           "-bsf:v", f"setts=pts={grid.format('PTS')}:dts={grid.format('DTS')}:time_base={fps.denominator}/{fps.numerator}", dst)


def render_effects(video_dir, props):
    """Render the "Effects" composition over each merged range. Returns [(first frame, clip)], [] without effects.
    Remotion copies its whole public dir into every bundle, so the video gets a small public dir of its own
    (never library/), and one bundle serves every range."""
    ranges = effect_ranges(props["effects"], props["hidden"])
    if not ranges:
        return []
    takes = video_dir / "takes"
    public, bundle = takes / ".effects-public", takes / ".effects-bundle"
    for d in (public, bundle):   # a previous render may have been cut off
        shutil.rmtree(d, ignore_errors=True)
    videos = []

    def picture_only(src, name):   # a hard link in the public dir
        video = takes / name
        picture_mp4(src, video, props["fps"])
        videos.append(video)
        try:
            os.link(video, public / name)
        except OSError:
            shutil.copy2(video, public / name)
        return name

    try:
        public.mkdir()
        for sub in ("fonts", "sfx"):
            shutil.copytree(LIBRARY / sub, public / sub)
        fx = {"fps": props["fps"], "durationInFrames": props["durationInFrames"],
              "video": picture_only(takes / "edit.mkv", "edit_video.mp4"), "effects": props["effects"], "hidden": props["hidden"]}
        parts = [p for e in props["effects"] if e["id"] not in props["hidden"] for p in (e["props"].get("a", {}), e["props"].get("b", {}))]
        if any(p.get("source") == "raw" for p in parts):   # a split part showing another moment of the raw
            fx["raw"] = picture_only(takes / "source.mkv", "source_video.mp4")
        for f in {p["file"] for p in parts if p.get("source") == "image"}:   # only the images in use
            (public / "broll").mkdir(exist_ok=True)
            shutil.copy2(paths.BROLL / f, public / "broll" / f)
        npx_remotion("bundle", "src/index.ts", f"--public-dir={public.resolve()}", f"--out-dir={bundle.resolve()}")
        fx_props = video_dir / "final" / "effects_props.json"
        write_json(fx_props, fx)
        clips = []
        for k, (a, b) in enumerate(ranges):
            clip = takes / f"effects_{k}.mov"
            npx_remotion("render", bundle.resolve(), "Effects", clip.resolve(), f"--props={fx_props.resolve()}",
                         f"--frames={a}-{b - 1}", "--codec=prores", "--prores-profile=hq", "--image-format=png",
                         "--muted")
            clips.append((a, clip))
        fx_props.unlink()
        return clips
    finally:
        for d in (public, bundle):
            shutil.rmtree(d, ignore_errors=True)
        for video in videos:
            video.unlink(missing_ok=True)


def overlay(video_dir, fps, frames, place=None, name="overlay"):
    """place: a network's safe area for the title and subtitles (stage 11.4, engine/safe.py); name: the file's name, so a
    network's layer does not take the place of the reel's own."""
    props = build_props(video_dir, fps, frames)
    if place:
        props["place"] = place
    props_path = video_dir / "final" / f"{name}_props.json"
    write_json(props_path, props)
    out = video_dir / "final" / f"{name}.mov"
    remotion("render", "src/index.ts", "Overlay", out.resolve(), f"--props={props_path.resolve()}",
             "--codec=prores", "--prores-profile=4444", "--pixel-format=yuva444p10le", "--image-format=png")
    return out, props


def compose(video_dir, layer, fps, clips=(), bed=None, blocks=(), out=None, voice_db=0):
    """edit.mkv, with each effect clip laid in at its first frame, under the Overlay; voice + all sounds
    (+ the ducked music bed, engine/music.py, when the reel has music). voice_db: Ron's voice level (stage 12.1)."""
    out = out or video_dir / "final" / "final.mp4"
    inputs, graph, base = ["-i", video_dir / "takes" / "edit.mkv", "-i", layer], [], "[0:v]"
    for k, (first, clip) in enumerate(clips):
        inputs += ["-i", clip]
        graph.append(f"[{k + 2}:v]setpts=PTS-STARTPTS+{first}/FRAME_RATE/TB[c{k}];"
                     f"{base}[c{k}]overlay=eof_action=pass:format=auto[b{k}]")
        base = f"[b{k}]"
    for k, (first, mov) in enumerate(blocks):   # see-through library blocks: over the picture, under subtitles/title
        n = len(clips) + 2 + k
        inputs += ["-i", mov]
        graph.append(f"[{n}:v]setpts=PTS-STARTPTS+{first}/FRAME_RATE/TB[h{k}];"
                     f"{base}[h{k}]overlay=eof_action=pass:format=auto[g{k}]")
        base = f"[g{k}]"
    graph.append(f"{base}[1:v]overlay=format=auto:shortest=1,format=yuv420p[v]")
    sounds = "[0:a][1:a]"
    if voice_db:
        graph.append(f"[0:a]volume={voice_db}dB[voice]")
        sounds = "[voice][1:a]"
    if bed:
        sounds += f"[{len(clips) + len(blocks) + 2}:a]"
        inputs += ["-i", bed]
    ffmpeg(*inputs,
           "-filter_complex", ";".join(graph) + ";"
                              f"{sounds}amix=inputs={3 if bed else 2}:duration=first:normalize=0,"
                              + ("aresample=192000,alimiter=limit=0.84:level=false,aresample=48000[a]" if bed   # music: limit oversampled, or
                               else "alimiter=limit=0.84:level=false[a]"),   # true peak rose to -0.5 dB (18.11); peaks under -1.5dB
           "-map", "[v]", "-map", "[a]",
           "-c:v", "libx264", "-crf", "18", "-preset", "slow", "-r", fps,
           "-c:a", "aac", "-b:a", "256k", "-movflags", "+faststart", out)
    return out


def covers(video_dir):
    g = read_json(video_dir / "graphics.json")["cover"]
    src = video_dir / "takes" / "source.mkv"
    ok = True
    for v in (1, 2):
        title = video_dir / "final" / f"cover_title_v{v}.png"
        props = video_dir / "final" / f"cover_props_v{v}.json"
        write_json(props, {"lines": g["lines"], "variant": v})
        remotion("still", "src/index.ts", "Cover", title.resolve(), f"--props={props.resolve()}", "--image-format=png")
        with av.open(str(title)) as c:
            rgba = next(c.decode(video=0)).to_ndarray(format="rgba")
        outside = alpha_outside(rgba, [(0, 0, 1080, COVER_CROP[0]), (0, COVER_CROP[1], 1080, 1920)])
        print(f"cover v{v}: {'inside 3:4 crop' if not outside else 'OUTSIDE 3:4 crop'}")
        ok &= not outside
        ffmpeg("-ss", f"{g['frame']:.3f}", "-i", src, "-i", title, "-filter_complex", "overlay", "-frames:v", "1",
               "-q:v", "2", video_dir / "final" / f"cover_v{v}.jpg")
        title.unlink()
        props.unlink()
    return ok


def layers(video_dir, place=None, name="overlay"):
    """Everything over the cut, each as its own file: the Overlay layer (title, subtitles, graphics and their sounds),
    the effect clips [(first frame, clip)], the library blocks and the logo [(first frame, mov)], and the music bed.
    main() composes them into final.mp4; engine/nle.py lays them on tracks for Premiere and DaVinci."""
    edit = video_dir / "takes" / "edit.mkv"
    info = probe(edit)
    layer, props = overlay(video_dir, float(info["fps"]), frame_count(edit), place, name)
    props["overlayBad"] = check_overlay(layer)   # main() writes it for the checks report (v3 Δ25, build rule 9)
    clips = render_effects(video_dir, props)
    made = {m["id"]: m["mov"] for m in hf_layer.render(video_dir)} if props["hf"] else {}
    blocks = [(h["from"], made[h["id"]]) for h in props["hf"] if h["id"] not in props["hidden"]]
    if props["logo"] and "logo" not in props["hidden"]:   # the logo last: over the blocks, under the subtitles
        blocks.append((props["logo"]["from"], logo.render(video_dir, props["logo"], float(info["fps"]))[0]))
    return info, layer, props, clips, blocks, music.bed(video_dir)


def main(video_dir):
    video_dir = Path(video_dir)
    info, layer, props, clips, blocks, bed = layers(video_dir)
    write_json(video_dir / "final" / "overlay_check.json", {"bad": [[list(z), f] for z, f in props["overlayBad"].items()]})
    print("final:", compose(video_dir, layer, info["fps"], clips, bed, blocks, voice_db=props.get("voiceDb", 0)))
    if endcard.finish(video_dir, video_dir / "final" / "final.mp4", read_json(video_dir / "graphics.json").get("logo"), "reel"):
        print("end: the logo at the end added (stage 11.6)")
    layer.unlink()   # ~190MB intermediate; render rebuilds it
    for _, clip in clips:
        clip.unlink()
    covers(video_dir)


if __name__ == "__main__":
    try:
        main(sys.argv[1])
    except Stop as e:
        sys.exit(f"נעצר: {e}")
