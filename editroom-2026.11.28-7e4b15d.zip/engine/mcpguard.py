"""The connector guard (stage d5c): a Claude Code PreToolUse hook on every mcp__ tool (.claude/settings.json).

It acts only in a room job (jobs.claude_env sets EDITROOM_JOB = the video, EDITROOM_JOB_CLIENT = its client's name);
without it (a normal chat in this folder) it allows everything. In a job it refuses a call whose input, anywhere in
it, names a file on this computer, carries 6 words in a row from the video's transcript, or the client's name: what
goes to a connector leaves the computer, and the user's material never does (CLAUDE.md, principles).
Exit 2 = refused (the reason goes back to Claude); any failure of the guard itself in a job refuses too.
"""
import json
import os
import re
import sys
from pathlib import Path

RUN = 6
WORD = re.compile(r"\w+")


def strings(v):
    """Every string in the tool's input, however deep."""
    if isinstance(v, str):
        yield v
    elif isinstance(v, dict):
        for k, x in v.items():
            yield from strings(k)
            yield from strings(x)
    elif isinstance(v, list):
        for x in v:
            yield from strings(x)


def parts(s):
    """The whole string, each word in it, what follows '=' in --x=path, and each part of a comma list."""
    out = [s, s.split("=", 1)[1]] if s.startswith("-") and "=" in s else [s]   # --x=a path with spaces
    for tok in s.split():
        tok = tok.split("=", 1)[1] if tok.startswith("-") and "=" in tok else tok
        out += [p for p in tok.split(",") if p]
    return out


def runs(text):
    w = [x.casefold() for x in WORD.findall(text)]
    return {tuple(w[i:i + RUN]) for i in range(len(w) - RUN + 1)}


def transcript_runs(video):
    if not video or video.startswith("insp:"):
        return set()
    import paths
    p = paths.VIDEOS / video / "transcript" / "words.json"
    if not p.is_file():
        return set()
    return runs(" ".join(w.get("w", "") for w in json.loads(p.read_text(encoding="utf-8")).get("words", [])))


def why(tool_input, cwd, video, client):
    """The reason in Hebrew this input may not go out, or None."""
    from hfcmd import is_file
    texts = list(strings(tool_input))
    for s in texts:
        if any(is_file(p, cwd) for p in parts(s)):
            return "קובץ מהמחשב לא נשלח לחיבור חיצוני. לקובץ הזה רק כלי מקומי"
    if len(client.strip()) > 1 and any(client.strip().casefold() in s.casefold() for s in texts):
        return "שם הלקוח לא נשלח לחיבור חיצוני"
    said = transcript_runs(video)
    if said and any(runs(s) & said for s in texts):
        return "טקסט מהתמלול של הסרטון לא נשלח לחיבור חיצוני"
    return None


def log(tool, video, reason):
    """One line in the server's log: the tool, the video and the reason, never what the call carried."""
    import datetime
    import paths
    with open(paths.LOGS / "server.log", "a", encoding="utf-8") as f:
        f.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S} WARNING mcpguard: refused {tool} in a job on {video}: {reason}\n")


def main(stdin, env):
    video = env.get("EDITROOM_JOB")
    if not video:
        return 0, ""
    try:
        data = json.loads(stdin)
        reason = why(data.get("tool_input", {}), data.get("cwd") or os.getcwd(), video, env.get("EDITROOM_JOB_CLIENT", ""))
        if reason:
            try:
                log(data.get("tool_name", "?"), video, reason)
            except OSError:
                pass
            return 2, f"✗ {reason}"
        return 0, ""
    except Exception as e:   # fail closed: a guard that could not look refuses
        return 2, f"✗ בדיקת החיבור נכשלה ({type(e).__name__}), ולכן הקריאה לא נשלחה"


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).parent))
    sys.stderr.reconfigure(encoding="utf-8")
    try:
        code, msg = main(sys.stdin.buffer.read().decode("utf-8"), os.environ)
    except Exception as e:   # even reading stdin: refuse in a job, allow outside one
        code, msg = (2, f"✗ בדיקת החיבור נכשלה ({type(e).__name__})") if os.environ.get("EDITROOM_JOB") else (0, "")
    if msg:
        print(msg, file=sys.stderr)
    sys.exit(code)
