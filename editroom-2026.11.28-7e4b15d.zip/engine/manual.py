"""Ron's own fixes in the editing room (stage 12.1): review/manual.json, applied over what Claude made, with no Claude.

They are locked (Ron 21.11): Claude does not change or undo them in later rounds unless Ron asks to change, add or close
one. The room shows them at once (engine/room/manual.js does the same as apply() here, on the same data), and the
render applies them (render.build_props, music.bed, render.compose).

manual.json, every part optional; times in seconds on the cut:
  "items":  {"<graphic / effect / library block id>": {"from", "dur"}}  ("title": {"dur"} = how long the title stays;
            a library block only moves: its length is the block's own)
  "hidden": {"<id>": true | false}   over graphics.json "hidden" (false shows what Claude hid)
  "deleted": ["<id>"]                gone from the video and from the room's lists
  "swap":   {"<graphic id>": "<kind>"}  another graphic from the catalog, same words (text kinds) or same place
  "pages":  {"<page index>": {"was", "text"?, "s"?, "e"?}}  a subtitle's words and times ("was" = its words as
            Claude made them: a page that has neither those words nor Ron's (a new cut) is left alone)
  "volume": {"voice": dB, "music": dB, "sfx": {"<graphic / effect id>": dB}}
  "music":  {"file": "<song>"} | {"off": true}   another song from the library (with a licence), or none
  "cut":    {"segments": [[start, end], ...], "fixes": {"<word index>": "<spelling>"}}  Ron's own cut (stage 12.2):
            pieces of the raw (source.mkv seconds) in the order they play, and his spelling of words (indexes in the
            room's word list). engine/mycut.py applies it on "סרטון סופי".
  "added":  [{"id": "mine-<a-z0-9>", "layer": "graphics" | "effects", "kind", "rawFrame", "durFrames", "props"}]
            Ron's own graphics and effects ("+ אפקט כאן", stage f). Anchored to a frame of the raw (takes/source.mkv), so
            any cut moves them with their moment; a Look has "whole": true instead of the two frames. props: ADD_PROPS.
            A moment that is cut out, a kind this version doesn't know, a broken item: not shown, not rendered, kept.
Every save keeps the one before it in review/manual-history/, and "ביטול" (undo) brings it back.
"""
import json
import math
import os
import re
import threading
from pathlib import Path

LOCK = threading.Lock()   # the room's server saves from many threads: a read-and-write of manual.json at a time (stage f)
LATIN = re.compile(r"^[A-Za-z0-9' \-]+[,.?!:;]?$")   # = subtitles.LATIN
TEXT_KINDS = ("TypedText", "CallToAction", "Checklist")
PICTURE_KINDS = ("CoinStack", "PaperPlane", "Burst")
MIN_FRAMES = {"Flash": 2, "Glitch": 3, "Burst": 7}   # shorter than this they cannot be drawn and stop the whole render (24.11)
VOLUME = {"voice": (-12, 0), "music": (-12, 6), "sfx": (-18, 6)}   # dB ranges the room offers

# ---- "+ אפקט כאן" (stage f, spec docs/addfx-spec*.md): the room's own 5 effects and 6 graphics, added by Ron
EFFECT_KINDS = ("Glitch", "Zoom", "Split", "Look", "Flash")
LABELS = {"TypedText": "טקסט מוקלד", "CallToAction": "כפתור קריאה לפעולה", "Checklist": "רשימת וי", "CoinStack": "מטבעות",
          "PaperPlane": "מטוס נייר", "Burst": "פיצוץ", "Glitch": "גליטש", "Zoom": "זום לנקודה", "Split": "מסך מפוצל",
          "Look": "מראה קולנועי", "Flash": "פלאש"}
ADDED_ID = re.compile(r"^mine-[a-z0-9]{6,20}$")
MAX_ADDED, MAX_TEXT, MAX_ADD_S, NEAR_S = 30, 28, 15, 0.5
# what each kind may carry, and nothing else: ["num", lo, hi] · ["enum", ...] · ["texts", lines, letters] · ["raw"] (another
# moment of the raw, {source: "raw", t: seconds}). Every key is required. The panel's order; Burst last (D6).
# The places and lengths were measured against what Instagram covers (engine/test_addfx_zones.py, 26.11): a burst further
# right, coins lower, or a button of more than 12 letters reached a covered area.
ADD_PROPS = {"TypedText": {"texts": ["texts", 2, MAX_TEXT]}, "CallToAction": {"texts": ["texts", 1, 12]},
             "Checklist": {"texts": ["texts", 2, MAX_TEXT]},
             "CoinStack": {"x": ["num", 120, 840], "baseY": ["num", 700, 1400]}, "PaperPlane": {},
             "Zoom": {"x": ["num", 0, 1], "y": ["num", 0, 1], "scale": ["num", 1.05, 1.5]},
             "Split": {"b": ["raw"]}, "Glitch": {}, "Flash": {},
             "Look": {"grade": ["enum", "warm", "tealOrange", "cool", "bw", "faded"]},
             "Burst": {"x": ["num", 160, 700], "y": ["num", 400, 1290]}}
ADD_DEFAULTS = {"CoinStack": {"x": 200, "baseY": 1000}, "Zoom": {"x": 0.5, "y": 0.35, "scale": 1.25},
                "Look": {"grade": "tealOrange"}, "Burst": {"x": 540, "y": 400}}
ADD_SECONDS = {"Glitch": 0.3, "Zoom": 1.2, "Split": 1.6, "Flash": 0.2}   # the catalog's length; a graphic 2.5 s; text: TEXT_*
LOOK_MIN = {"Zoom": 13, "Split": 18, **{k: 15 for k in TEXT_KINDS + PICTURE_KINDS}}   # shorter does not read (frames)
PER_CHAR, LINE_GAP, TEXT_TAIL, TEXT_LEAST = 2, 8, 30, 75   # = TypedText.PER_CHAR; frames; TEXT_LEAST at 30 fps


def path(vdir):
    return Path(vdir) / "review" / "manual.json"


def load(vdir):
    p = path(vdir)
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def history(vdir):
    return sorted((Path(vdir) / "review" / "manual-history").glob("*.json"))


def redos(vdir):
    """What "שוב" brings back, the last undone first at the end (stage c2): review/manual-redo/."""
    return sorted((Path(vdir) / "review" / "manual-redo").glob("*.json"))


def _next(folder):
    have = sorted(folder.glob("*.json"))
    folder.mkdir(exist_ok=True)
    return folder / f"{int(have[-1].stem) + 1 if have else 1:04d}.json"


def forget_redo(vdir):
    """A new fix, a cut moved by the machine, a job of Claude's: what was undone no longer belongs (stage c2)."""
    for f in redos(vdir):
        f.unlink()


def barrier(vdir, name):
    """Undo stops here (stage c2, decision 8 ג): the history so far moves to manual-history/before-<name>/ and stays on
    the disk. Kept states from before a new cut hold times on the old cut, and Claude writes manual.json without a history
    step. Called after the snapshot of a stop (before.take), so a stop brings the history back."""
    h = Path(vdir) / "review" / "manual-history"
    old = history(vdir)
    if old:
        (h / f"before-{name}").mkdir(exist_ok=True)
        for f in old:
            f.replace(h / f"before-{name}" / f.name)
    forget_redo(vdir)


def save(vdir, m):
    """Check and write; the previous state goes to the history first."""
    m = check(m)
    p = path(vdir)
    forget_redo(vdir)   # first: when it fails, nothing was written
    p.parent.mkdir(exist_ok=True)   # the first fix too can be undone (stage c2): before it there was nothing
    _next(p.parent / "manual-history").write_bytes(p.read_bytes() if p.exists() else b"{}")
    p.parent.mkdir(exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(m, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(p)
    return m


def write(vdir, m):
    """Ron's fixes moved by the machine (a new cut, engine/mycut.py): written as they are, no undo step of their own."""
    p = path(vdir)
    m = check(m)
    forget_redo(vdir)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(m, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(p)


def _swap(vdir, back, forth):
    """The newest state in `back` becomes manual.json; manual.json goes to `forth` first (undo: history -> redo)."""
    kept = back(vdir)
    if not kept:
        return None
    p = path(vdir)
    if p.exists():
        _next(forth).write_bytes(p.read_bytes())
    kept[-1].replace(p)
    os.utime(p)   # the kept file has the time it was kept: "fixes not in the video yet" reads the time
    return load(vdir)


def undo(vdir):
    """Back to the state before the last save. None when there is nothing to undo."""
    return _swap(vdir, history, path(vdir).parent / "manual-redo")


def redo(vdir):
    """"שוב": the last undo, done again. None when there is nothing to bring back."""
    return _swap(vdir, redos, path(vdir).parent / "manual-history")


def mine(vdir):
    """{count, pending} for the room (stage c): how many fixes there are, and whether some may not be in final.mp4 yet
    (manual.json written after it; an undo, even back to what was rendered, counts as not in it)."""
    m, p, fin = load(vdir), path(vdir), Path(vdir) / "final" / "final.mp4"
    vol, cut = m.get("volume") or {}, m.get("cut")
    count = (sum(len(m.get(k) or ()) for k in ("items", "hidden", "deleted", "swap", "pages")) + len(vol.get("sfx") or {})
             + sum(k in vol for k in ("voice", "music")) + ("music" in m) + ((1 + len(cut.get("fixes") or {})) if cut else 0)
             + (len([a for a in m["added"] if a["id"] not in live(vdir, m)["bad"]]) if m.get("added") else 0))   # one each (Δ65)
    pending = p.exists() and (not fin.exists() or p.stat().st_mtime_ns > fin.stat().st_mtime_ns)
    return {"count": count, "pending": pending}


def check(m):
    if not isinstance(m, dict):
        raise ValueError("manual: an object")
    num = lambda x: isinstance(x, (int, float)) and not isinstance(x, bool) and x >= 0
    for i, v in m.get("items", {}).items():
        if not all(num(v.get(k, 0)) for k in ("from", "dur")) or v.get("dur", 1) <= 0:
            raise ValueError(f"manual: bad times for {i}")
    for i, k in m.get("swap", {}).items():
        if k not in TEXT_KINDS + PICTURE_KINDS:
            raise ValueError(f"manual: unknown graphic {k}")
    for i, v in m.get("pages", {}).items():
        if not str(i).isdigit() or "was" not in v or ("text" in v and not str(v["text"]).strip()):
            raise ValueError(f"manual: bad subtitle {i}")
        if "s" in v and "e" in v and not (num(v["s"]) and v["e"] > v["s"]):
            raise ValueError(f"manual: subtitle {i} ends before it starts")
    if "cut" in m:
        segs = m["cut"].get("segments")
        if not (isinstance(segs, list) and segs and all(isinstance(x, list) and len(x) == 2 and num(x[0]) and x[1] > x[0]
                                                         for x in segs)):
            raise ValueError("manual: bad cut")
        by_time = sorted(segs)
        if any(a[1] > b[0] + 1e-6 for a, b in zip(by_time, by_time[1:])):
            raise ValueError("manual: two pieces of the cut share a moment of the raw")
        if not all(str(i).isdigit() and str(t).strip() for i, t in m["cut"].get("fixes", {}).items()):
            raise ValueError("manual: bad spelling fix")
    import longfix   # the long-video parts (stage 12.3)
    longfix.check(m)
    vol = m.get("volume", {})
    for k in ("voice", "music"):
        if k in vol and not VOLUME[k][0] <= vol[k] <= VOLUME[k][1]:
            raise ValueError(f"manual: {k} volume out of range")
    if any(not VOLUME["sfx"][0] <= d <= VOLUME["sfx"][1] for d in vol.get("sfx", {}).values()):
        raise ValueError("manual: sound volume out of range")
    added = m.get("added", [])   # only its shape here (v4 Δ65): an item that went stale stays, and is never in the way
    if not isinstance(added, list) or len(added) > MAX_ADDED:
        raise ValueError(f"manual: added = a list of up to {MAX_ADDED}")
    if not all(isinstance(a, dict) and ADDED_ID.match(str(a.get("id"))) and _finite(a) for a in added):
        raise ValueError("manual: a bad added item")
    if len({a["id"] for a in added}) < len(added):
        raise ValueError("manual: two added items with one id")
    return m


def _finite(v):
    if isinstance(v, float):
        return math.isfinite(v)
    if isinstance(v, dict):
        return all(map(_finite, v.values()))
    return all(map(_finite, v)) if isinstance(v, list) else True


# ---- "+ אפקט כאן" (stage f)
def rules():
    """Everything the room checks an added item against before saving it (v4 Δ40, Δ49), from this one place."""
    return {"props": ADD_PROPS, "defaults": ADD_DEFAULTS, "seconds": ADD_SECONDS, "lookMin": LOOK_MIN, "minFrames": MIN_FRAMES,
            "maxItems": MAX_ADDED, "maxSeconds": MAX_ADD_S, "textKinds": TEXT_KINDS, "maxWords": MAX_WORDS,
            "effectKinds": EFFECT_KINDS, "text": {"perChar": PER_CHAR, "gap": LINE_GAP, "tail": TEXT_TAIL, "least": TEXT_LEAST}}


# ---- stage f2: a library block or a studio effect, requested at a moment; Claude makes it in the next round
SOURCES, MAX_WORDS, STUDIO_SECONDS = ("hyperframes", "studio"), 200, 3
REQUEST_KEYS = {"id", "layer", "source", "name", "rawFrame", "try", "words"}
FX_HE = Path(__file__).parent / "room" / "fx-he.json"   # the blocks the room offers, with their Hebrew names (Δ74)
_LIB = {}


def library():
    """{source: {name: {he, what, seconds, thirdParty, still}}}: what may be requested (v5 Δ74). The blocks of fx-he.json that are
    blocks, ready or adapt on Instagram, in the library's catalog; the 18 studio effects with their Hebrew names."""
    import fxlib
    studio = Path(__file__).parent / "studio"
    key = tuple(f.stat().st_mtime_ns if f.exists() else 0 for f in (FX_HE, fxlib.LIB / "catalog.json", fxlib.STATE / "catalog.json"))
    if key not in _LIB:
        cat, he = fxlib.catalog(), json.loads((studio / "he.json").read_text(encoding="utf-8"))
        blocks = {}
        for name, v in json.loads(FX_HE.read_text(encoding="utf-8"))["blocks"].items():
            c = cat.get(name) or {}
            r = c.get("registry") or {}
            if r.get("type") == "block" and (c.get("status") or {}).get("instagram") in ("ready", "adapt"):
                shots = c.get("stills") or []
                blocks[name] = {**v, "seconds": float(r.get("duration") or 5), "thirdParty": bool(c.get("third_party")),
                                "still": f"/fxlib/{name}/{shots[len(shots) // 2]}" if shots else None}
        fx = {f["id"]: {"he": he.get(f["name_key"], f["id"]), "what": he.get(f["desc_key"], ""), "seconds": STUDIO_SECONDS,
                        "thirdParty": False, "still": None} for f in json.loads((studio / "effects.json").read_text(encoding="utf-8"))}
        _LIB.clear()
        _LIB[key] = {"hyperframes": blocks, "studio": fx}
    return _LIB[key]


def _why_request(a, ctx, where):
    """why_not for a request (v5 Δ70-Δ71): its own keys, a name on the list, a frame of the raw, and its words."""
    fps, raw_n, lib = ctx.get("fps"), ctx.get("rawFrames"), ctx.get("library")
    if not (lib and fps and raw_n):
        return "אי אפשר להוסיף לסרטון הזה עכשיו"
    if set(a) - REQUEST_KEYS or not REQUEST_KEYS - {"words"} <= set(a) or a["source"] not in SOURCES:
        return "לא תקין"
    if not isinstance(a["name"], str) or a["name"] not in lib[a["source"]]:
        return "הבלוק כבר לא בספרייה"
    whole = lambda x: isinstance(x, int) and not isinstance(x, bool)
    if not (whole(a["rawFrame"]) and whole(a["try"]) and a["try"] >= 1):
        return "לא תקין"
    if not 0 <= a["rawFrame"] < raw_n:
        return "מחוץ לגלם"
    if "words" in a and not (isinstance(a["words"], str) and 1 <= len(a["words"].strip()) <= MAX_WORDS):
        return "טקסט לא תקין"
    if where and ctx.get("clock") is not None and place(ctx["clock"], a["rawFrame"], fps) is None:
        return "הרגע נחתך"
    return None


def clock(segments, fps):
    """The cut as frames of the raw, in the order they play: [[first, past the last]] (the rounding of nle.py)."""
    return [[round(s * fps), round(e * fps)] for s, e in segments]


def place(clk, raw, fps):
    """A frame of the raw -> its frame on the cut: the first piece that has it. Cut out but within half a second of a
    piece: that piece's nearest end. Further: None (the moment was cut)."""
    at, near = 0, None
    for fs, fe in clk:
        if fs <= raw < fe:
            return at + raw - fs
        if fe > fs:
            d = fs - raw if raw < fs else raw - (fe - 1)
            if near is None or d < near[0]:
                near = (d, at + (0 if raw < fs else fe - 1 - fs))
        at += max(0, fe - fs)
    return near[1] if near and near[0] <= round(NEAR_S * fps) else None


def layer_of(kind):
    return "effects" if kind in EFFECT_KINDS else "graphics"


def why_not(a, ctx, where=True):
    """Why an added item can't be shown, in Hebrew; None = it can. ctx = live(): the video as it is now. where: also
    whether its moment is still in the cut. Every rule of check_added; the only gate to the render (v4 §11.1)."""
    if a.get("layer") == "library":   # a request (stage f2)
        return _why_request(a, ctx, where)
    kind, fps, raw_n = a.get("kind"), ctx.get("fps"), ctx.get("rawFrames")
    if not (ctx.get("known") and fps and raw_n):
        return "אי אפשר להוסיף לסרטון הזה עכשיו"
    if kind not in ADD_PROPS or a.get("layer") != layer_of(kind) or kind not in ctx["known"].get(a.get("layer"), ()):
        return "סוג לא מוכר"
    if set(a) - {"id", "layer", "kind", "rawFrame", "durFrames", "whole", "props"}:
        return "לא תקין"
    if kind == "Look":
        if a.get("whole") is not True or "rawFrame" in a or "durFrames" in a:
            return "לא תקין"
    else:
        r, d = a.get("rawFrame"), a.get("durFrames")
        if "whole" in a or not all(isinstance(x, int) and not isinstance(x, bool) for x in (r, d)):
            return "לא תקין"
        if not 0 <= r < raw_n:
            return "מחוץ לגלם"
        if not LOOK_MIN.get(kind, MIN_FRAMES.get(kind, 1)) <= d <= round(MAX_ADD_S * fps):
            return "אורך לא תקין"
    p = a.get("props")
    if not isinstance(p, dict) or set(p) != set(ADD_PROPS[kind]):
        return "לא תקין"
    for k, (how, *arg) in ADD_PROPS[kind].items():
        v = p[k]
        num = lambda x: isinstance(x, (int, float)) and not isinstance(x, bool)
        if how == "num" and not (num(v) and arg[0] <= v <= arg[1]):
            return "מחוץ לטווח"
        if how == "enum" and v not in arg:
            return "לא תקין"
        if how == "texts" and not (isinstance(v, list) and 1 <= len(v) <= arg[0]
                                   and all(isinstance(t, str) and 1 <= len(t.strip()) <= arg[1] for t in v)):
            return "טקסט לא תקין"
        if how == "raw" and not (isinstance(v, dict) and set(v) == {"source", "t"} and v["source"] == "raw" and num(v["t"])
                                 and 0 <= v["t"] and round(v["t"] * fps) + a["durFrames"] <= raw_n):
            return "מחוץ לגלם"
    if where and kind != "Look" and ctx.get("clock") is not None and place(ctx["clock"], a["rawFrame"], fps) is None:
        return "הרגע נחתך"
    return None


class Refused(ValueError):
    """An added item the room may not save (/api/manual answers 400 and names it)."""
    def __init__(self, item, why):
        super().__init__(f"{LABELS.get(item.get('kind'), item.get('kind') or 'בקשה מהספרייה')}: {why}")
        self.item = item.get("id")


def check_added(new, before, ctx):
    """Only an added item that is new or changed against the saved file (v4 Δ59, Δ65): one that went stale since stays."""
    old = {a.get("id"): a for a in before.get("added", []) if isinstance(a, dict)}
    for a in new.get("added", []):
        if old.get(a["id"]) != a and (why := why_not(a, ctx, where=False)):
            raise Refused(a, why)


_DISK = {}


def live(vdir, m=None):
    """The video as it is now, for the added items (v3 Δ19, build rule 3): the cut as a clock, the kinds the catalog
    knows, the raw's length, and why each added item can't be shown. Never raises: anything missing = clock None."""
    vdir = Path(vdir)
    src, segs = vdir / "takes" / "source.mkv", vdir / "takes" / "edit_segments.json"
    out = {"clock": None, "fps": None, "rawFrames": None, "known": None, "labels": LABELS, "library": None}
    try:
        import render   # here: render imports this module
        from media import probe
        key = (str(vdir), *(f.stat().st_mtime_ns for f in (src, segs, vdir / "takes" / "edit.mkv")))
        if key not in _DISK:
            fps = float(probe(src)["fps"])
            effects, graphics = render.catalog_kinds()
            _DISK[key] = {"fps": fps, "rawFrames": round(float(probe(src)["duration"]) * fps), "known": {"graphics": graphics, "effects": effects},
                          "clock": clock(json.loads(segs.read_text(encoding="utf-8"))["segments"], fps)}
        out.update(_DISK[key])
    except Exception:   # no cut yet, cleaned after it was done, a long video: nothing to anchor to
        pass
    try:
        out["library"] = library()
    except Exception:   # no library list here: no requests can be made or shown
        pass
    added = (load(vdir) if m is None else m).get("added", [])
    out["bad"] = {a["id"]: why for a in added if out["known"] and (why := why_not(a, out))}
    return out


def added_changed(vdir, was):
    """After a round of Claude's (v4 Δ62): which of Ron's added items it deleted or changed, against manual.json in the
    snapshot taken before the job (`was`; none = nothing to compare, as the spec says). -> review/added-changed.json
    {round, items: [{id, label, time, what}]}, which "מה קלוד עשה" shows. Never raises: the job's end goes on."""
    vdir = Path(vdir)
    try:
        if not Path(was).exists():
            return
        old = {a.get("id"): a for a in json.loads(Path(was).read_text(encoding="utf-8")).get("added", [])}
        new = {a.get("id"): a for a in load(vdir).get("added", [])}
        lv = live(vdir)

        def when(a):   # seconds on the cut as it is now
            if a.get("whole"):
                return 0.0
            f = lv["clock"] and place(lv["clock"], a.get("rawFrame", 0), lv["fps"])
            return None if f is None else round(f / lv["fps"], 1)
        items = [{"id": i, "label": LABELS.get(a.get("kind")) or a.get("name") or a.get("kind"), "what": "נמחקה" if i not in new else "שונתה",
                  "time": when(a)} for i, a in old.items() if new.get(i) != a]
        rounds = [int(f.stem[6:]) for f in (vdir / "review").glob("round-*.json") if f.stem[6:].isdigit()]
        tmp = vdir / "review" / "added-changed.tmp"
        tmp.write_text(json.dumps({"round": max(rounds, default=0), "items": items}, ensure_ascii=False), encoding="utf-8")
        tmp.replace(vdir / "review" / "added-changed.json")
    except Exception as e:   # the job's end must go on
        print("added-changed:", e)


def text_frames(texts, fps):
    """How long a text item is at first: the last line typed to its end, and a moment to read it (v3 Δ22, rule 4)."""
    return max(round(TEXT_LEAST * fps / 30), sum(PER_CHAR * len(t) for t in texts) + LINE_GAP * len(texts) + TEXT_TAIL)


def _added(props, m):
    """manual.json "added" as graphics and effects in frames, [{id, label, why}] of those that can't be shown, and the
    requests (stage f2) as {id, source, name, label, from, dur, state}: shown in the room, never rendered (v5 Δ72)."""
    clk, known, labels = props.get("clock"), props.get("known"), props.get("labels") or {}
    if clk is None or known is None:   # an old version, or the cut changed since it was published: none at all (Δ19)
        return [], [], []
    fps, frames, bad, made, lost, asked = props["fps"], props["durationInFrames"], props.get("addedBad") or {}, [], [], []
    lib, states = props.get("library") or {}, props.get("requestStates") or {}
    for a in m.get("added", []):
        if a.get("layer") == "library":
            src, name = (x if isinstance(x, str) else "" for x in (a.get("source"), a.get("name")))
            item = (lib.get(src) or {}).get(name)
            label = item["he"] if item else name
            why = bad.get(a["id"]) or (None if item else "הבלוק כבר לא בספרייה")
            at = None if why else place(clk, a["rawFrame"], fps)
            if why or at is None:
                lost.append({"id": a["id"], "label": label, "why": why or "הרגע נחתך"})
                continue
            start = min(at, frames - 1)
            asked.append({"id": a["id"], "source": a["source"], "name": a["name"], "label": label, "from": start,
                          "dur": max(1, min(round(item["seconds"] * fps), frames - start)), "state": states.get(a["id"], "waiting")})
            continue
        kind = a.get("kind")
        why = bad.get(a["id"]) or (None if kind in labels and kind in known.get(a.get("layer"), ()) else "סוג לא מוכר")
        at = None if why or kind == "Look" else place(clk, a["rawFrame"], fps)
        if not why and kind != "Look" and at is None:
            why = "הרגע נחתך"
        if why:
            lost.append({"id": a["id"], "label": labels.get(kind, kind), "why": why})
            continue
        start, dur = (0, frames) if kind == "Look" else (min(at, frames - 1), a["durFrames"])
        p = dict(a["props"])
        g = {"id": a["id"], "kind": kind, "label": labels.get(kind, kind), "from": start, "dur": max(1, min(dur, frames - start))}
        if "texts" in p:   # one typed line after another (TypedText's own pace), the other text kinds through swap()
            ats = [sum(PER_CHAR * len(t) + LINE_GAP for t in p["texts"][:k]) for k in range(len(p["texts"]))]
            g = {**g, "kind": "TypedText", "props": {"lines": [{"text": t, "at": x} for t, x in zip(p["texts"], ats)]}}
            g = swap(g, kind) if kind != "TypedText" else g
        else:
            g["props"] = p
        made.append(g)
    return made, lost, asked


def _blocks(props, m, lost):
    """Claude's library blocks with the request they answer (v5 Δ73, Δ81, Δ85, Δ90, Δ94): only while the request is in
    "added" and done; at the request's moment when there is a clock (none if it was cut), at graphics.json's time when
    there is not; the block's own length (`own`, frames) from there."""
    fps, frames, clk = props["fps"], props["durationInFrames"], props.get("clock")
    asked = {a["id"]: a for a in m.get("added", []) if a.get("layer") == "library"}
    states, out = props.get("requestStates") or {}, []
    for h in props.get("hf", []):
        r = h.get("request")
        if r is None:
            out.append(h)
            continue
        if r not in asked or states.get(r) != "done":   # deleted by Ron, or not made and checked yet
            continue
        start = h["from"]
        if clk is not None and props.get("known") is not None:
            at = place(clk, asked[r]["rawFrame"], fps)
            if at is None:
                lost.append({"id": h["id"], "label": h.get("label", h["id"]), "why": "הרגע נחתך"})
                continue
            start = min(at, frames - 1)
        out.append({**h, "from": start, "dur": max(1, min(h.get("own", h["dur"]), frames - start))})
    return out


def units(text):
    """A subtitle's words as Overlay units: consecutive English words stay one unit (= subtitles.units)."""
    out = []
    for w in text.split():
        if out and out[-1][1] and LATIN.match(w):
            out[-1][0] += " " + w
        else:
            out.append([w, bool(LATIN.match(w))])
    return out


def swap(g, kind):
    """The graphic as another kind: a text kind keeps its words, a picture kind starts from its own defaults."""
    p = g["props"]
    old = ([x["text"] for x in p.get("lines", [])] if g["kind"] == "TypedText" else [p.get("text", "")]
           if g["kind"] == "CallToAction" else [p.get("title", "")] + [x["text"] for x in p.get("items", [])]
           if g["kind"] == "Checklist" else [])
    if kind in TEXT_KINDS and not old or kind in PICTURE_KINDS and g["kind"] in TEXT_KINDS:
        raise ValueError(f"manual: {g['kind']} -> {kind}")
    step = lambda k, n: round(g["dur"] * 0.6 * k / max(1, n))   # one line after another over the first 60%
    new = ({"lines": [{"text": t, "at": step(k, len(old))} for k, t in enumerate(old)]} if kind == "TypedText" else
           {"text": " ".join(old)} if kind == "CallToAction" else
           {"title": old[0], "items": [{"text": t, "at": step(k + 1, len(old))} for k, t in enumerate(old[1:] or old[:1])]}
           if kind == "Checklist" else {})
    return {**g, "kind": kind, "props": new}


def drawable(g, frames):
    """A graphic or effect long enough to be drawn: only one that is too short changes, and starts earlier at the end."""
    least = MIN_FRAMES.get(g["kind"], 1)
    if g["dur"] >= least:
        return g
    return {**g, "dur": least, "from": max(0, min(g["from"], frames - least))}


def apply(props, m):
    """The room's / the render's props with Ron's fixes over them (a new object; props is left as it was)."""
    fps, frames = props["fps"], props["durationInFrames"]
    out = {**props}
    items, swaps = m.get("items", {}), m.get("swap", {})
    made, lost, out["requests"] = _added(props, m)
    out["addedLost"] = list(props.get("blockLost") or []) + lost   # blocks without their page or failing the check (f2)   # Ron's own (stage f): after Claude's graphics; effects before the first Look
    gfx = props.get("graphics", []) + [g for g in made if g["kind"] not in EFFECT_KINDS]
    fx = list(props.get("effects", []))
    for e in made:
        if e["kind"] in EFFECT_KINDS:
            looks = [k for k, x in enumerate(fx) if x["kind"] == "Look"]
            fx.insert(len(fx) if e["kind"] == "Look" or not looks else looks[0], e)

    def move(lst, length=True):
        res = []
        for g in lst:
            if g["id"] in items and not g["id"].startswith("mine-") and "request" not in g:   # times of Ron's own: in "added"
                v = items[g["id"]]
                start = min(round(v.get("from", g["from"] / fps) * fps), frames - 1)
                dur = round(v["dur"] * fps) if length and "dur" in v else g["dur"]
                g = {**g, "from": start, "dur": max(1, min(dur, frames - start))}
            g = swap(g, swaps[g["id"]]) if g["id"] in swaps and swaps[g["id"]] != g.get("kind") else g
            res.append(drawable(g, frames) if length else g)
        return res
    out["graphics"] = move(gfx)
    out["effects"] = move(fx)
    out["hf"] = move(_blocks(props, m, out["addedLost"]), length=False)
    if "dur" in items.get("title", {}):
        out["titleEnd"] = min(items["title"]["dur"], frames / fps)
    hidden = [h for h in props.get("hidden", []) if m.get("hidden", {}).get(h, True)]
    hidden += [h for h, on in m.get("hidden", {}).items() if on and h not in hidden]
    out["deleted"] = list(m.get("deleted", []))
    out["hidden"] = hidden + [d for d in out["deleted"] if d not in hidden]
    pages = [dict(p) for p in props.get("pages", [])]
    for i, v in m.get("pages", {}).items():
        i = int(i)
        if i < len(pages) and pages[i]["text"] in (v["was"], v.get("text")):   # or Claude fixed the transcript to match
            if "text" in v:
                pages[i].update(text=v["text"], units=units(v["text"]))
            pages[i].update({k: v[k] for k in ("s", "e") if k in v})
    out["pages"] = pages
    vol = m.get("volume", {})
    out["sfxGain"] = {i: round(10 ** (d / 20), 4) for i, d in vol.get("sfx", {}).items()}
    out["voiceDb"] = vol.get("voice", 0)
    return out


def music(g, m):
    """graphics.json "music" with Ron's song and level over it; None = no music."""
    pick = m.get("music")
    if pick and pick.get("off"):
        return None
    base = {"file": pick["file"], "start": 0} if pick else g.get("music")
    if not base:
        return None
    return {**base, "level_db": float(base.get("level_db", 0)) + m.get("volume", {}).get("music", 0)}


def check_file(vdir):
    """python engine/manual.py check "<video>" (after Claude changed manual.json, round.md): exit 1 = the file is broken;
    an added item that can't be shown is a warning only, and is never rendered (v4 Δ65, §11.1)."""
    import sys
    try:
        m = check(load(vdir))
    except (ValueError, TypeError, AttributeError, json.JSONDecodeError) as e:
        sys.exit(f"manual.json לא תקין: {e}")
    for i, why in live(vdir, m)["bad"].items():
        print(f"warning: {i}: {why} (not shown and not rendered)")
    print("manual.json OK")


if __name__ == "__main__":
    import sys
    if sys.argv[1:2] == ["check"]:
        sys.stdout.reconfigure(encoding="utf-8")
        check_file(sys.argv[2])
        sys.exit(0)
    import shutil
    import tempfile
    fps = 30
    tt = {"id": "a", "kind": "TypedText", "from": 30, "dur": 60, "props": {"lines": [{"text": "שורה", "at": 0}, {"text": "שתיים", "at": 20}]}}
    base = {"fps": fps, "durationInFrames": 300, "titleEnd": 2.0, "hidden": ["c"],
            "graphics": [tt, {"id": "b", "kind": "Burst", "from": 0, "dur": 10, "props": {"x": 1}}],
            "effects": [{"id": "c", "kind": "Glitch", "from": 0, "dur": 9, "props": {}}],
            "hf": [{"id": "h", "kind": "hf", "from": 0, "dur": 90, "props": {}}],
            "pages": [{"text": "רוב האנשים", "s": 0, "e": 1, "units": []}, {"text": "שלום", "s": 1, "e": 2, "units": []}]}
    m = check({"items": {"a": {"from": 5, "dur": 1}, "h": {"from": 9.5, "dur": 1}, "title": {"dur": 3}},
               "hidden": {"c": False, "b": True}, "deleted": ["h"], "swap": {"a": "Checklist"},
               "pages": {"0": {"was": "רוב האנשים", "text": "רוב Google Ads", "e": 1.5}, "1": {"was": "אחר", "text": "x"}},
               "volume": {"voice": -3, "sfx": {"a": 6}}})
    p = apply(base, m)
    a = p["graphics"][0]
    assert (a["from"], a["dur"], a["kind"]) == (150, 30, "Checklist") and a["props"]["title"] == "שורה", a
    assert a["props"]["items"] == [{"text": "שתיים", "at": 9}], a          # same words, another graphic
    assert p["hf"][0]["from"] == 285 and p["hf"][0]["dur"] == 15            # moved, kept inside the video
    assert p["titleEnd"] == 3 and p["hidden"] == ["b", "h"] and p["deleted"] == ["h"]
    assert p["pages"][0] == {"text": "רוב Google Ads", "s": 0, "e": 1.5, "units": [["רוב", False], ["Google Ads", True]]}
    assert p["pages"][1]["text"] == "שלום"                                   # its words changed since: left alone
    fixed = {**base, "pages": [{**base["pages"][0], "text": "רוב Google Ads"}]}   # Claude put Ron's words in the transcript
    assert apply(fixed, m)["pages"][0]["e"] == 1.5
    assert p["sfxGain"] == {"a": 1.9953} and p["voiceDb"] == -3 and base["graphics"][0] is tt and tt["from"] == 30
    # too short to draw: these three stop the whole render (interpolate needs a range that grows), also after a swap, also at
    # the last frame; an item that is long enough, and a library block, are never touched (24.11)
    tiny = lambda i, kind, dur, at=298: {"id": i, "kind": kind, "from": at, "dur": dur, "props": {}}
    short = {**base, "pages": [], "effects": [tiny("f", "Flash", 1, 299), tiny("gl", "Glitch", 2), tiny("z", "Zoom", 9, 100)],
             "graphics": [tiny("pl", "PaperPlane", 2), tiny("bu", "Burst", 6, 50), tiny("ok", "Burst", 7, 60)], "hf": [tiny("h", "hf", 1, 299)]}
    s = apply(short, {"swap": {"pl": "Burst"}, "items": {"f": {"from": 9.9, "dur": 0.02}}})
    got = {g["id"]: (g["from"], g["dur"]) for g in s["effects"] + s["graphics"] + s["hf"]}
    assert got == {"f": (297, 2), "gl": (297, 3), "z": (100, 9), "pl": (293, 7), "bu": (50, 7),
                   "ok": (60, 7), "h": (299, 1)}, got
    for bad in ({"swap": {"a": "Nope"}}, {"volume": {"voice": 3}}, {"pages": {"0": {"text": "x"}}},
                {"items": {"a": {"from": -1, "dur": 1}}}, {"pages": {"0": {"was": "a", "s": 2, "e": 1}}},
                {"cut": {"segments": [[0, 2], [1, 3]]}}, {"cut": {"segments": []}}, {"cut": {"segments": [[3, 2]]}}):
        try:
            check(bad)
            raise AssertionError(bad)
        except ValueError:
            pass
    try:
        swap(base["graphics"][1], "TypedText")
        raise AssertionError("a picture has no words to type")
    except ValueError:
        pass
    assert music({"music": {"file": "a.mp3", "start": 4, "level_db": 3}}, {"volume": {"music": -2}}) == \
        {"file": "a.mp3", "start": 4, "level_db": 1.0}
    assert music({"music": {"file": "a.mp3"}}, {"music": {"off": True}}) is None and music({}, {}) is None
    assert music({}, {"music": {"file": "b.mp3"}}) == {"file": "b.mp3", "start": 0, "level_db": 0.0}
    tmp = Path(tempfile.mkdtemp())
    try:
        save(tmp, {"items": {"a": {"from": 1, "dur": 1}}})
        save(tmp, {"deleted": ["a"]})
        assert load(tmp) == {"deleted": ["a"]} and len(history(tmp)) == 2   # the first fix too: before it, {}
        (tmp / "final").mkdir()
        (tmp / "final" / "final.mp4").write_bytes(b"")
        t0 = path(tmp).stat().st_mtime
        ago = lambda f, s: os.utime(f, (t0 - s,) * 2)   # the clock ticks coarser than a test: times set by hand
        ago(tmp / "review" / "manual-history" / "0002.json", 20)
        ago(path(tmp), 20)
        ago(tmp / "final" / "final.mp4", 10)
        assert mine(tmp) == {"count": 1, "pending": False}, mine(tmp)   # rendered after the last fix
        assert undo(tmp) == {"items": {"a": {"from": 1, "dur": 1}}}
        assert mine(tmp) == {"count": 1, "pending": True}, mine(tmp)    # the undo is not in the video
        assert undo(tmp) == {} and undo(tmp) is None                      # the very first fix undone: nothing
        save(tmp, {})
        ago(path(tmp), 20)
        assert mine(tmp)["pending"] is False   # a fix, then a render
        save(tmp, {})
        assert mine(tmp) == {"count": 0, "pending": True}   # back to nothing after a render: the video still has the fix
        path(tmp).write_text(json.dumps({"items": {"a": {}}, "hidden": {"b": False}, "deleted": ["c"], "swap": {"d": "x"},
                                         "pages": {"1": {}}, "volume": {"voice": -2, "music": 1, "sfx": {"e": 1, "f": 2}},
                                         "music": {"off": True}, "cutPending": {"x": 1},
                                         "cut": {"segments": [[0, 1]], "fixes": {"3": "x", "4": "y"}}}), encoding="utf-8")
        assert mine(tmp)["count"] == 1 + 1 + 1 + 1 + 1 + 2 + 2 + 1 + 3, mine(tmp)
        # stage c2: undo, "שוב", a new fix forgets what was undone, the barrier
        for f in history(tmp) + redos(tmp):
            f.unlink()
        path(tmp).unlink()
        for k in range(3):
            save(tmp, {"deleted": [f"g{k}"]})
        assert undo(tmp) == {"deleted": ["g1"]} and undo(tmp) == {"deleted": ["g0"]} and undo(tmp) == {} and undo(tmp) is None
        assert len(redos(tmp)) == 3 and redo(tmp) == {"deleted": ["g0"]}
        assert redo(tmp) == {"deleted": ["g1"]} and redo(tmp) == {"deleted": ["g2"]} and redo(tmp) is None
        assert undo(tmp) == {"deleted": ["g1"]} and len(redos(tmp)) == 1
        save(tmp, {"deleted": ["h"]})
        assert not redos(tmp) and redo(tmp) is None and undo(tmp) == {"deleted": ["g1"]}
        write(tmp, {"deleted": ["moved"]})   # the machine's move of a new cut
        assert not redos(tmp) and len(history(tmp)) == 2
        undo(tmp)
        barrier(tmp, "x1")
        assert not history(tmp) and not redos(tmp) and undo(tmp) is None and load(tmp) == {"deleted": ["g0"]}
        assert [f.name for f in (tmp / "review" / "manual-history" / "before-x1").iterdir()] == ["0001.json"]   # kept, not lost
        save(tmp, {"deleted": ["k"]})
        barrier(tmp, "x2")
        assert [f.name for f in (tmp / "review" / "manual-history" / "before-x2").iterdir()] == ["0001.json"] and not history(tmp)
    finally:
        shutil.rmtree(tmp)
    print("manual self-check OK")
