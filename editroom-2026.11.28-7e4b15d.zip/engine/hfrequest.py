"""Library requests (stage f2, docs/addfx-spec-f2-v5-diff.md): Ron marks a moment and asks for a library block or a studio
effect (manual.json "added", layer "library"); Claude makes it in the next round, and only the check here lets it into the
video.

review/requests.json = {"<request id>": {"try", "state": "working" | "done" | "failed", "why"?}}
Claude prepares hf/<lib-id>.html and hf/<lib-id>.json (its place: {id, request, label, x, y, width, from, dur?}), then

usage: python engine/hf_layer.py request "videos/<name>" list                  (the open requests: what, where, what is said)
       python engine/hf_layer.py request "videos/<name>" <request id> done <lib-id>   (checks it; only then into graphics.json)
       python engine/hf_layer.py request "videos/<name>" <request id> failed <why>
       python engine/hf_layer.py request "videos/<name>" drop <lib-id>         (a block whose request Ron deleted)
"""
import json
import re
import sys
from pathlib import Path

import fxlib
import manual
from media import read_json

LIB_ID = re.compile(r"^lib-[a-z0-9-]{1,40}$")
HEBREW = re.compile(r"[א-ת]{2,}")
LATIN = re.compile(r"[A-Za-z]")


def path(vdir):
    return Path(vdir) / "review" / "requests.json"


def load(vdir):
    p = path(vdir)
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def _write(p, data):
    tmp = Path(p).with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(p)


def save(vdir, states):
    path(vdir).parent.mkdir(exist_ok=True)
    _write(path(vdir), states)


def asked(vdir):
    """{request id: the request} in manual.json "added"."""
    return {a["id"]: a for a in manual.load(vdir).get("added", []) if isinstance(a, dict) and a.get("layer") == "library"}


def is_open(a, st):
    """Still to be made in a round: no record (try 0), or a "לנסות שוב" that raised its try past the recorded one (Δ76)."""
    return st is None or a.get("try", 1) > st.get("try", 0)


def start(vdir):
    """A round begins (jobs.start): every open request is "working". Returns the states before, for job.json (Δ80)."""
    states, before = load(vdir), {}
    for i, a in asked(vdir).items():
        if is_open(a, states.get(i)):
            before[i] = states.get(i)
            states[i] = {"try": a.get("try", 1), "state": "working"}
    if before:
        save(vdir, states)
    return before


def end(vdir, before, how):
    """A round ended (jobs.finish). how: "back" = Claude was not available and the round waits again: the states go back;
    "failed" / "done": what is still "working" failed (Claude did not finish it)."""
    states = load(vdir)
    if not before or not any(states.get(i, {}).get("state") == "working" for i in before):
        return
    for i, was in before.items():
        if states.get(i, {}).get("state") != "working":
            continue
        if how == "back":
            if was is None:
                states.pop(i, None)
            else:
                states[i] = was
        else:
            states[i] = {**states[i], "state": "failed", "why": "העבודה נעצרה" if how == "failed" else "קלוד לא סיים את הבקשה"}
    save(vdir, states)


def shown(vdir, alive=False):
    """The states the room and the render go by (Δ80, Δ95, rule 2): "working" with no job alive on the video is failed;
    "done" with no ready block for it in graphics.json is failed."""
    states, out, wanted = load(vdir), {}, asked(vdir)
    g = Path(vdir) / "graphics.json"
    ready = {h.get("request") for h in (read_json(g).get("hf", []) if g.exists() else []) if h.get("ready")}
    for i, st in states.items():
        if i in wanted and is_open(wanted[i], st):   # "לנסות שוב" raised its try: waiting again
            continue
        s = st.get("state")
        out[i] = ("failed" if s == "working" and not alive else
                  "failed" if s == "done" and i not in ready else s)
    return out


def _texts(html):
    body = re.sub(r"<script\b.*?</script>|<style\b.*?</style>|<!--.*?-->", "", html, flags=re.S | re.I)
    return [t.strip() for t in re.findall(r">([^<>]+)<", body) if t.strip()]


def problem(vdir, h, html, words=None):
    """Why a made block may not go into the video (Δ82, Δ91, build rules 3-4); None = it may. Shown text only (no script,
    style or comments): a Hebrew word; no line left from the library's own block that has a Latin letter; no file of
    someone else's sample media; and Ron's words never as markup."""
    texts = _texts(html)
    if not any(HEBREW.search(t) for t in texts):
        return "אין בבלוק טקסט בעברית"
    name = h.get("name")
    if name:
        src = fxlib.LIB / "compositions" / f"{name}.html"
        if src.exists():
            left = {t for t in _texts(src.read_text(encoding="utf-8")) if LATIN.search(t)} & set(texts)
            if left:
                return f"נשאר בבלוק טקסט באנגלית מהבלוק המקורי: {sorted(left)[0][:40]}"
        for f in fxlib.catalog().get(name, {}).get("third_party") or []:
            if Path(f).name in html:
                return f"יש בבלוק מדיה לדוגמה של מישהו אחר ({Path(f).name})"
    if words and "<" in words and words.strip() in html:
        return "המילים שלך נכנסו לבלוק כקוד ולא כטקסט"
    return None


def done(vdir, rid, lib_id):
    """`request … done`: the pending block is checked, and only then written into graphics.json with "ready" (Δ90)."""
    vdir = Path(vdir)
    a, states = asked(vdir).get(rid), load(vdir)
    tried = (a or {}).get("try", 1)

    def fail(why):
        states[rid] = {"try": tried, "state": "failed", "why": why}
        save(vdir, states)
        sys.exit(f"הבקשה {rid} לא עברה: {why}")
    if not a or not LIB_ID.match(lib_id):
        sys.exit(f"אין בקשה {rid}, או שם בלוק לא תקין: {lib_id}")
    pending, page = vdir / "hf" / f"{lib_id}.json", vdir / "hf" / f"{lib_id}.html"
    if not (pending.exists() and page.exists()):
        fail("לא נמצאו הבלוק או המקום שלו")
    h = json.loads(pending.read_text(encoding="utf-8"))
    if h.get("id") != lib_id or h.get("request") != rid:
        fail("המקום של הבלוק לא מתאים לבקשה")
    if a["source"] == "hyperframes":
        h["name"] = a["name"]
    else:
        h.pop("name", None)
        h["studio"] = a["name"]
    if why := problem(vdir, h, page.read_text(encoding="utf-8"), a.get("words")):
        fail(why)
    g = read_json(vdir / "graphics.json")
    g["hf"] = [x for x in g.get("hf", []) if x.get("id") != lib_id] + [{**h, "ready": True}]
    _write(vdir / "graphics.json", g)
    pending.unlink()
    states[rid] = {"try": tried, "state": "done"}
    save(vdir, states)
    print(f"הבלוק {lib_id} נכנס לסרטון")


def failed(vdir, rid, why):
    a = asked(vdir).get(rid)
    if not a:
        sys.exit(f"אין בקשה {rid}")
    states = load(vdir)
    states[rid] = {"try": a.get("try", 1), "state": "failed", "why": why[:200]}
    save(vdir, states)


def drop(vdir, lib_id):
    """A block whose request Ron deleted: out of graphics.json, with its files (Δ93, build rule 5)."""
    vdir = Path(vdir)
    if not LIB_ID.match(lib_id) or ".." in lib_id:
        sys.exit(f"שם בלוק לא תקין: {lib_id}")
    g = read_json(vdir / "graphics.json")
    h = next((x for x in g.get("hf", []) if x.get("id") == lib_id), None)
    if h is not None and (not h.get("request") or h["request"] in asked(vdir)):
        sys.exit(f"{lib_id} אינו בלוק של בקשה שנמחקה")
    others = [x for x in g.get("hf", []) if x.get("id") != lib_id]
    keep = {t for x in others + _pending(vdir, lib_id) if x.get("name") for t in fxlib.item_files(x["name"])}
    gone = {t for t in fxlib.item_files(h["name"])} - keep if h and h.get("name") else set()
    if h is not None:
        g["hf"] = others
        _write(vdir / "graphics.json", g)
    for f in [vdir / "hf" / f"{lib_id}.html", vdir / "hf" / f"{lib_id}.json",
              *(vdir / "takes" / "hf").glob(f"{lib_id}.*"), *(vdir / "hf" / "files" / t for t in gone)]:
        if f.is_file():
            f.unlink()
    print(f"{lib_id} הוסר")


def _pending(vdir, but=None):
    out = []
    for f in (Path(vdir) / "hf").glob("lib-*.json"):
        if f.stem != but:
            try:
                out.append(json.loads(f.read_text(encoding="utf-8")))
            except ValueError:
                pass
    return out


def listing(vdir):
    """`request … list`: what Claude has to make, where it is on the cut, and what is said there (Δ84)."""
    vdir = Path(vdir)
    lv, states = manual.live(vdir), load(vdir)
    words = read_json(vdir / "takes" / "edit_words.json")["words"] if (vdir / "takes" / "edit_words.json").exists() else []
    for i, a in asked(vdir).items():
        if not is_open(a, states.get(i)) and states.get(i, {}).get("state") != "working":
            continue
        f = lv["clock"] and manual.place(lv["clock"], a["rawFrame"], lv["fps"])
        t = None if f is None or not lv["fps"] else f / lv["fps"]
        said = " ".join(w["w"] for w in words if t is not None and t - 2 <= w["s"] <= t + 4)
        item = (lv["library"] or {}).get(a["source"], {}).get(a["name"], {})
        print(json.dumps({"request": i, "source": a["source"], "name": a["name"], "he": item.get("he"), "words": a.get("words"),
                          "second": None if t is None else round(t, 2), "said": said, "try": a.get("try", 1)}, ensure_ascii=False))
    for h in _pending(vdir):
        if h.get("request") not in asked(vdir):
            print(json.dumps({"pending without a request (drop it)": h.get("id")}, ensure_ascii=False))


def main(args):
    vdir = args[0]
    if args[1:] == ["list"]:
        return listing(vdir)
    if args[1] == "drop":
        return drop(vdir, args[2])
    rid, what = args[1], args[2]
    if what == "done":
        return done(vdir, rid, args[3])
    if what == "failed":
        return failed(vdir, rid, " ".join(args[3:]) or "לא הצליח")
    sys.exit(f"לא מכיר: {what}")
