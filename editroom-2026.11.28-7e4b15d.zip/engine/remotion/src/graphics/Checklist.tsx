// A short action plan: a header, then items ticked off as the speaker says them.
import {AbsoluteFill, interpolate, spring, useVideoConfig} from 'remotion';
import {FONT} from '../style';
import {GREEN, Sfx, typed, useInOut} from './motion';

export type ChecklistProps = {dur: number; title: string; items: {text: string; at: number}[]; y?: number};

const Tick: React.FC<{p: number}> = ({p}) => (
  <svg width={64} height={64} viewBox="0 0 64 64" style={{flex: 'none'}}>
    <circle cx={32} cy={32} r={28} fill={GREEN} opacity={0.18 + 0.82 * p} />
    <path d="M18 33 L28 43 L47 22" fill="none" stroke="white" strokeWidth={7} strokeLinecap="round" strokeLinejoin="round"
      strokeDasharray={48} strokeDashoffset={48 * (1 - p)} />
  </svg>
);

export const Checklist: React.FC<ChecklistProps> = ({dur, title, items, y = 300}) => {
  const {frame, enter, exit} = useInOut(dur);
  const {fps} = useVideoConfig();
  return (
    <AbsoluteFill style={{opacity: exit}}>
      <div dir="rtl" style={{position: 'absolute', top: y, left: 150, right: 150, fontFamily: FONT,
        transform: `translateY(${interpolate(enter, [0, 1], [-30, 0])}px)`, opacity: enter}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 16, fontSize: 64, fontWeight: 900, color: 'white',
          textShadow: `0 0 28px ${GREEN}, 0 4px 14px rgba(0,0,0,0.7)`, marginBottom: 10}}>
          <svg width={58} height={68} viewBox="0 0 58 68">
            <rect x={4} y={10} width={50} height={56} rx={8} fill="#F8FAFF" />
            <rect x={17} y={3} width={24} height={14} rx={5} fill={GREEN} />
            {[0, 1, 2].map((k) => <rect key={k} x={14} y={28 + k * 11} width={30} height={5} rx={2.5} fill="#A9B6D3" />)}
          </svg>
          {typed(title)}
        </div>
        {items.map((it, i) => {
          const p = spring({frame: frame - it.at, fps, config: {damping: 13}});
          if (frame < it.at) return null;
          return (
            <div key={i} style={{display: 'flex', alignItems: 'center', gap: 16, fontSize: 50, fontWeight: 800, color: 'white',
              height: 78, opacity: p, transform: `translateX(${(1 - p) * -60}px)`, textShadow: '0 3px 12px rgba(0,0,0,0.75)'}}>
              <Tick p={p} />
              {typed(it.text)}
            </div>
          );
        })}
      </div>
      <Sfx name="pop" at={0} volume={0.3} />
      {items.map((it, i) => <Sfx key={i} name="click" at={it.at + 2} volume={0.35} />)}
    </AbsoluteFill>
  );
};
