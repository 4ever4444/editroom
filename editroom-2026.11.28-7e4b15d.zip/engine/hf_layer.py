"""Library blocks in a reel (stage 5.1): a HyperFrames block from fx-library, adapted for this video, rendered as a
see-through layer over the picture, under the subtitles and title.

usage: python engine/hf_layer.py add "videos/<name>" <id> <block name>   (copy the block to videos/<name>/hf/<id>.html,
                                                                   to adapt: Hebrew text, dir="rtl", colours)
       python engine/hf_layer.py render "videos/<name>"            (render every graphics.json "hf" item)
       python engine/hf_layer.py studio [<effect id>]           (the studio's effect instructions, to build one as a block)
       python engine/hf_layer.py request "videos/<name>" ...      (Ron's library requests, stage f2: engine/hfrequest.py)

graphics.json "hf": [{"id", "name": <block>, "from": <phrase | seconds>, "dur"?: <seconds, default the block's own>,
                      "x": 0, "y": <top, in 1080x1920>, "width": <px, default 1080>}]
Each item renders once per change to takes/hf/<id>.mov (ProRes 4444, alpha: render.py lays it in) and
takes/hf/<id>.webm (VP9 alpha: the room plays it). The block is shrunk to `width` and placed at x/y.
"""
import hashlib
import json
import re
import shutil
import sys
from pathlib import Path

import fxlib
import paths
import tools
import vendor
from media import read_json

HOST = """<!doctype html>
<html lang="he"><head><meta charset="UTF-8" /><meta name="viewport" content="width=1080, height=1920" />
<script src="/vendor/gsap.min.js"></script>
<style>*{{margin:0;padding:0;box-sizing:border-box}}html,body{{width:1080px;height:1920px;overflow:hidden;background:transparent}}
#place{{position:absolute;left:{x}px;top:{y}px;width:{bw}px;height:{bh}px;transform:scale({s});transform-origin:0 0}}</style>
</head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{d}" data-width="1080" data-height="1920">
<div id="place"><div data-composition-id="{cid}" data-composition-src="compositions/_v/{file}" data-start="0"
 data-duration="{d}" data-width="{bw}" data-height="{bh}"></div></div>
</div>
<script>const tl = gsap.timeline({{paused: true}}); window.__timelines["main"] = tl; tl.seek(0);</script>
</body></html>
"""


STUDIO_FX = Path(__file__).parent / "studio" / "effects.json"   # the studio's 18 effects: instructions to build


def block_info(name, html=""):
    """(width, height, seconds) of a block: from the block itself first (its root says data-width/height/duration;
    the same as the library's catalog for all 202 blocks, checked 23.11), so a video renders the same on a
    computer that has no library installed (found in the 13.3 trial: the block was placed as a reel frame and fell
    off screen); then the catalog; a block Claude built from a studio effect is a full reel frame."""
    item = fxlib.catalog().get(name or "", {}).get("registry") or {}
    w, h = fxlib.shape(item) or (1080, 1920)
    d = float(item.get("duration") or 5)
    size = re.search(r'data-width="(\d+)"\s+data-height="(\d+)"', html)
    if size:
        w, h = int(size.group(1)), int(size.group(2))
        if dur := re.search(r'data-duration="([\d.]+)"', html):
            d = float(dur.group(1))
    return w, h, d


def studio_fx(fx_id=None):
    """The studio's effect instructions (engine/studio/effects.json), for a job to build one from."""
    fx = json.loads(STUDIO_FX.read_text(encoding="utf-8"))
    return [f for f in fx if fx_id in (None, f["id"])]


def add(vdir, item_id, name):
    """A library item into the video: its page as hf/<id>.html (Claude adapts it), and every other file it loads
    (lib/, assets/, the items it depends on) under hf/files/ as the library lays them out (13.6 G1), so the video
    renders the same on any computer and whatever the library's version. Someone else's sample media is named."""
    src = fxlib.LIB / "compositions" / f"{name}.html"
    if not src.exists():
        raise SystemExit(f"אין בספרייה רכיב בשם {name}")
    out = Path(vdir) / "hf" / f"{item_id}.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, out)
    for t in fxlib.item_files(name):
        f = fxlib.LIB / t
        if f.is_file() and t != f"compositions/{name}.html":
            (out.parent / "files" / t).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, out.parent / "files" / t)
    print(out)
    if theirs := fxlib.catalog().get(name, {}).get("third_party"):
        print("someone else's sample media in this block (name it in the report):", ", ".join(theirs))
    return out


def stage_files(vdir):
    """The video's library files onto the render stage, where the library has them and beside compositions/_v/
    (where its pages are rendered from), so a relative src resolves either way."""
    files = Path(vdir) / "hf" / "files"
    if not files.is_dir():
        return
    for f in files.rglob("*"):
        if f.is_file():
            rel = f.relative_to(files)
            own = [] if paths.HF_STAGE.resolve() == fxlib.LIB.resolve() else [paths.HF_STAGE / rel]   # Ron's stage is the library: never write into it
            for out in own + ([paths.HF_STAGE / "compositions" / "_v" / rel.relative_to("compositions")]
                              if rel.parts[0] == "compositions" else []):
                if not (out.is_file() and out.stat().st_size == f.stat().st_size):
                    out.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, out)


def host(item, html):
    w, h, d = block_info(item.get("name"), html)
    width = float(item.get("width", 1080))
    s = width / w
    cid = re.search(r'data-composition-id="([^"]+)"', html).group(1)   # the block's own id, as its timeline knows it
    return HOST.format(x=item.get("x", 0), y=item.get("y", 960 - h * s / 2), bw=w, bh=h, s=f"{s:.5f}",
                       d=item.get("dur", d), cid=cid, file=f"{item['id']}.html")


def items(vdir):
    """graphics.json "hf" as the video has them, the one source for build_props and render (v3 Δ27, v5 Δ73, Δ90): a block
    for a request only once it was made, checked and is done (still passing the check, build rule 3); a block without its
    page is left out. -> (items, lost [{id, label, why}]), never a crash."""
    import hfrequest
    vdir = Path(vdir)
    g, states, out, lost = read_json(vdir / "graphics.json"), hfrequest.load(vdir), [], []
    asked = hfrequest.asked(vdir)
    for h in g.get("hf", []):
        page = vdir / "hf" / f"{h.get('id')}.html"
        why = None if page.is_file() else "אין קובץ לבלוק"
        r = h.get("request")
        if r is not None and not why:
            if not h.get("ready") or (states.get(r) or {}).get("state") != "done":
                continue   # not made yet: the room shows the request, not the block
            why = hfrequest.problem(vdir, h, page.read_text(encoding="utf-8"), (asked.get(r) or {}).get("words"))
            why = why and "הבלוק השתנה ולא עובר את הבדיקה"
        if why:
            lost.append({"id": h.get("id"), "label": h.get("label", h.get("id")), "why": why})
        else:
            out.append(h)
    return out, lost


def render(vdir):
    """Every block of items() -> takes/hf/<id>.mov + .webm, re-rendered only when its block or place changed."""
    vdir = Path(vdir)
    out_dir = vdir / "takes" / "hf"
    out_dir.mkdir(parents=True, exist_ok=True)
    made = []
    for item in items(vdir)[0]:
        html = (vdir / "hf" / f"{item['id']}.html").read_text(encoding="utf-8")
        page = host(item, html)
        key = hashlib.sha1((html + page).encode()).hexdigest()[:16]
        mov, webm, stamp = out_dir / f"{item['id']}.mov", out_dir / f"{item['id']}.webm", out_dir / f"{item['id']}.key"
        if not (mov.exists() and webm.exists() and stamp.exists() and stamp.read_text() == key):
            stamp.unlink(missing_ok=True)   # half a layer must never be taken for a ready one (stage b2)
            v = paths.HF_STAGE / "compositions" / "_v"   # ponytail: one shared render stage; renders run one at a time
            v.mkdir(parents=True, exist_ok=True)   # an installed stage starts empty (13.3 trial run)
            stage_files(vdir)
            (v / f"{item['id']}.html").write_text(vendor.local(html), encoding="utf-8")
            (paths.HF_STAGE / "index.html").write_text(page, encoding="utf-8")
            tools.hf_render(paths.HF_STAGE, mov)
            tools._run(tools.FFMPEG, "-y", "-loglevel", "error", "-i", mov, "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p",
                       "-b:v", "2M", "-an", webm)
            stamp.write_text(key)
        made.append({"id": item["id"], "mov": mov, "webm": webm})
    return made


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if sys.argv[1] == "add":
        add(sys.argv[2], sys.argv[3], sys.argv[4])
    elif sys.argv[1] == "request":   # stage f2: engine/hfrequest.py
        import hfrequest
        hfrequest.main(sys.argv[2:])
    elif sys.argv[1] == "studio":   # python engine/hf_layer.py studio [<effect id>]: the instructions to build it from
        for f in studio_fx(sys.argv[2] if len(sys.argv) > 2 else None):
            print(f"## {f['id']} ({f['category']})\n{f['instructions']}\n")
    else:
        print(json.dumps([{k: str(v) for k, v in m.items()} for m in render(sys.argv[2])], ensure_ascii=False))
