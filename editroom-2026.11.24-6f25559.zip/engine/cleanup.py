"""After Ron approves a video: delete the work-in-progress media, keep what matters.

usage: python engine/cleanup.py "videos/<name>" [--dry]

Kept: raw/ (never touched), final/final.mp4, final/cover_*.jpg, and every small text file
(json, txt, html, md) anywhere, so the history and the approved choices stay readable.
Deleted: every other media file under takes/, final/ and review/ (source.mkv, edit.mkv,
proxies, overlay renders, cover candidates, check images). All of them can be rebuilt from raw/.
Writes review/approved.json with what was removed and how much space it freed.
"""
import json
import sys
from datetime import datetime
from pathlib import Path

KEEP_SUFFIXES = {".json", ".txt", ".html", ".md"}
WORK_DIRS = ("takes", "final", "review")


def keep(path, vdir):
    rel = path.relative_to(vdir)
    if rel.suffix.lower() in KEEP_SUFFIXES:
        return True
    return rel.parts[0] == "final" and len(rel.parts) == 2 and (
        rel.name == "final.mp4" or (rel.name.startswith("cover_v") and rel.suffix == ".jpg"))


def doomed(vdir):
    return [p for d in WORK_DIRS for p in sorted((vdir / d).rglob("*")) if p.is_file() and not keep(p, vdir)]


def main(vdir, dry=False):
    vdir = Path(vdir)
    if not (vdir / "final" / "final.mp4").is_file():
        sys.exit(f"{vdir.name}: no final/final.mp4 yet, nothing is deleted before there is a finished video")
    files = doomed(vdir)
    freed = sum(p.stat().st_size for p in files)
    for p in files:
        print(("would delete " if dry else "deleted ") + str(p.relative_to(vdir)))
        if not dry:
            p.unlink()
    if not dry:
        for d in sorted({p.parent for p in files}, key=lambda d: -len(d.parts)):   # now-empty folders
            if d.exists() and not any(d.iterdir()):
                d.rmdir()
        (vdir / "review").mkdir(exist_ok=True)
        (vdir / "review" / "approved.json").write_text(json.dumps(
            {"at": datetime.now().isoformat(timespec="seconds"), "freed_mb": round(freed / 2**20, 1),
             "deleted": [str(p.relative_to(vdir)) for p in files]}, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{'would free' if dry else 'freed'} {freed / 2**20:.0f} MB")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main(sys.argv[1], "--dry" in sys.argv)
