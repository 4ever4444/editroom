// Stage 11.5: the ad versions of one reel side by side (engine/ads.py): what differs in each, its video once edited,
// and the text for the ads manager, ready to copy.
const $ = (s) => document.querySelector(s);
const el = (tag, cls, text) => Object.assign(document.createElement(tag), {className: cls || '', textContent: text ?? ''});
const reel = new URLSearchParams(location.search).get('video');
const enc = encodeURIComponent;
const CTA = {same: 'כמו בריל', short: 'קצרה, בציווי', question: 'בשאלה', benefit: 'מה הצופה מקבל'};
let shown = '';

async function load() {
  $('#back').href = `/v/${enc(reel)}`;
  const d = await (await fetch(`/api/ads?video=${enc(reel)}`)).json();
  const key = JSON.stringify(d);
  if (key !== shown) {
    shown = key;
    $('#status').textContent = d.versions.length ? '' : 'לריל הזה עוד אין גרסאות מודעה. יוצרים אותן בכפתור "מודעה ב-3 גרסאות" בחדר העריכה של הריל.';
    $('#ads').replaceChildren(...d.versions.map(card));
    $('#ads').style.setProperty('--n', Math.max(1, d.versions.length));
  }
  if (d.versions.some((v) => !v.final)) setTimeout(load, 5000);   // the edits run one after another
}

function card(v) {   // Ron 20.11: a card that folds, wide and proportioned, the ad text in its own window
  const c = el('details', 'card adcard');
  c.open = true;
  const sum = el('summary');
  sum.append(el('b', '', `גרסה ${v.variant}`), el('span', 'pill', v.final ? 'מוכנה' : v.label));
  c.append(sum);
  const body = el('div', 'adbody');
  if (v.final) {
    body.append(Object.assign(el('video'), {src: `/final/${enc(v.name)}`, controls: true, preload: 'metadata'}));
  } else {
    const wait = el('div', 'adwait');
    if (v.thumb) wait.style.backgroundImage = `url("${v.thumb}")`;
    body.append(wait);
  }
  const dl = el('dl', 'addiff');
  for (const [k, val] of [['פתיחה', `"${v.hook}"`], ['כותרת', v.title.join(' / ')], ['קריאה לפעולה', CTA[v.cta] || v.cta]]) {
    dl.append(el('dt', '', k), el('dd', '', val));
  }
  body.append(dl);
  const row = el('div', 'upload-row');
  if (v.ad_text) {
    const show = el('button', 'primary', 'טקסט לפוסט');
    show.onclick = () => adText(v);
    row.append(show);
  }
  row.append(Object.assign(el('a', 'dl', 'לחדר העריכה'), {href: `/v/${enc(v.name)}`}));
  if (v.final) row.append(Object.assign(el('a', 'dl', 'ייצוא'), {href: `/export?video=${enc(v.name)}`}));
  body.append(row);
  c.append(body);
  return c;
}

function adText(v, editing = false) {   // the text for the ads manager, in a window of its own
  let dlg = $('#adText');
  if (!dlg) {
    dlg = Object.assign(el('dialog', 'drivedlg'), {id: 'adText'});
    document.body.append(dlg);
  }
  dlg.replaceChildren(el('h2', '', `טקסט למודעה · גרסה ${v.variant}`));
  if (v.writing) {   // Claude is writing another text (Ron 20.11: "a button that makes a new text")
    dlg.append(el('p', 'hint', 'קלוד כותב טקסט חדש לגרסה הזו… (כדקה). החלונית תתעדכן לבד.'));
  }
  const fields = {};
  for (const [key, label, field, rows] of [['primary', 'הטקסט הראשי', 'Primary text', 7], ['headline', 'הכותרת', 'Headline', 1]]) {
    const text = v.ad_text[key];
    const box = el('div', 'adtextpart');
    box.append(el('h3', '', label), el('p', 'hint', `מדביקים בשדה "${field}" במנהל המודעות`));
    if (editing) {   // Ron's own words, saved for this version before he copies them
      fields[key] = Object.assign(el('textarea', 'adedit'), {value: text, rows, dir: 'rtl'});
      box.append(fields[key]);
    } else {
      const copy = el('button', '', 'העתקה');
      copy.onclick = async () => { await navigator.clipboard.writeText(text); copy.textContent = '✓ הועתק'; setTimeout(() => (copy.textContent = 'העתקה'), 1500); };
      box.append(Object.assign(el('p', 'adtext', text), {dir: 'rtl'}), copy);
    }
    dlg.append(box);
  }
  const status = el('span', 'status');
  const row = el('div', 'upload-row');
  if (editing) {
    const save = el('button', 'primary', 'שמירה');
    save.onclick = async () => {
      const ad = {primary: fields.primary.value, headline: fields.headline.value};
      const r = await fetch(`/api/posts?video=${enc(v.name)}`, {method: 'POST', body: JSON.stringify({ad})});
      if (!r.ok) return (status.textContent = (await r.json()).error);
      v.ad_text = {...v.ad_text, ...ad};
      shown = '';
      adText(v);
    };
    const cancel = el('button', '', 'ביטול');
    cancel.onclick = () => adText(v);
    row.append(save, cancel);
  } else {
    const edit = el('button', '', '✎ עריכה ידנית');
    edit.disabled = !!v.writing;
    edit.onclick = () => adText(v, true);
    const fresh = el('button', '', '↻ טקסט חדש');
    fresh.disabled = !!v.writing;
    fresh.onclick = async () => {
      const r = await fetch(`/api/newtext?video=${enc(v.name)}`, {method: 'POST'});
      if (!r.ok) return (status.textContent = (await r.json()).error);
      v.writing = true;
      adText(v);
      waitForText(v.name);
    };
    const close = el('button', '', 'סגירה');
    close.onclick = () => dlg.close();
    row.append(fresh, edit, close);
  }
  row.append(status);
  dlg.append(row);
  if (!dlg.open) dlg.showModal();
}

async function waitForText(name) {   // the new text appears in the window as soon as Claude saved it
  const d = await (await fetch(`/api/ads?video=${enc(reel)}`)).json();
  const v = d.versions.find((x) => x.name === name);
  if (!v) return;
  if (v.writing) return setTimeout(() => waitForText(name), 3000);
  shown = '';
  load();
  if ($('#adText')?.open) adText(v);
}

load();
