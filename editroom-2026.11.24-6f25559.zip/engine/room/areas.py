"""The room's areas besides the videos (16.11): tool status, the studio's effects, inspirations + learning, analysis.

What came from the studio (claude-video-studio) is in engine/studio since stage 13.2.
"""
import json
import os
import re
import subprocess
import sys
import threading
import uuid

import jobs
import rounds
from rounds import now, read, write_atomic

sys.path.insert(0, str(rounds.ROOT / "engine"))
import paths  # noqa: E402
import tools  # noqa: E402

LESSONS = paths.LESSONS
STUDIO = paths.APP / "engine" / "studio"   # what came from the studio (stage 13.2): its 18 effects and their demos
STUDIO_FILES = {   # what the effects page may load
    "fx-demos.js": (STUDIO / "fx-demos.js", "text/javascript"),
    "presenter-cutout.png": (STUDIO / "presenter-cutout.png", "image/png"),
}
ID_OK = re.compile(r"^[a-z0-9-]{1,40}$")

# ---- tool status: checking runs every tool once (a few seconds), so it runs in the background and is kept
_tools = {"state": "checking", "rows": []}


def _check_tools():
    rows = tools.check()
    _tools.update(state="ready", rows=[dict(name=n, ok=o, detail=d, required=r) for n, o, d, r in rows])


def tool_status():
    if _tools["state"] == "checking" and not _tools.get("started"):
        _tools["started"] = True
        threading.Thread(target=_check_tools, daemon=True).start()
    return _tools


# ---- the studio's effects (shown beside the room's own catalog)
def studio_effects():
    he = json.loads((STUDIO / "he.json").read_text(encoding="utf-8"))
    fx = json.loads((STUDIO / "effects.json").read_text(encoding="utf-8"))
    return {"effects": [{"id": e["id"], "category": e["category"], "demo": e.get("demo"),
                         "name": he.get(e["name_key"], e["id"]), "desc": he.get(e["desc_key"], "")} for e in fx],
            "strings": {k: v for k, v in he.items() if k.startswith("fx.demo.")}}


# ---- inspirations: library/inspiration/<id>/{source.mp4, meta.json, analysis/rNN/, style-card.md}
def insp_dir(iid):
    if not ID_OK.match(iid or ""):
        raise FileNotFoundError(iid)
    return jobs.insp_dir(f"insp:{iid}")


def source(d):
    """The inspiration's own video, when it has one (a .part is an upload that did not finish)."""
    return next((p for p in d.glob("source.*") if p.suffix != ".part"), None)


def learn(d):
    """Background: measure the video, then Claude writes its style card (no shell, see jobs.LEARN_TOOLS)."""
    job_f = d / "review" / "job.json"
    write_atomic(job_f, {"state": "running", "kind": "analyze", "started": now(), "pid": os.getpid()})
    write_atomic(d / "review" / "progress.json", {"step": "המערכת מודדת את הסרטון: קצב, עוצמה ופריימים", "at": now()})
    try:
        analyze(d)
        jobs.start(f"insp:{d.name}", "learn")
    except (RuntimeError, OSError, subprocess.TimeoutExpired, jobs.Busy) as e:
        busy = isinstance(e, jobs.Busy)
        write_atomic(job_f, {"state": "failed", "kind": "analyze", "finished": now(), "fromRound": 0,
                             "error": f'קלוד עסוק עכשיו ב-"{e}". אפשר לנסות שוב כשהוא יסיים.' if busy else f"המדידה נכשלה: {e}"})


def new_inspiration(note, link):
    iid = f"{now()[:10]}-{uuid.uuid4().hex[:6]}"
    d = rounds.INSP / iid
    (d / "review").mkdir(parents=True)
    write_atomic(d / "meta.json", {"id": iid, "note": note[:600], "link": link[:500], "created": now()})
    return d


def card_lines(text):
    """The front matter of a style card as {key: line}."""
    m = re.match(r"---\n(.*?)\n---", text, re.S)
    return dict(re.findall(r"^(\w+):\s*(.+)$", m.group(1), re.M)) if m else {}


def inspiration(d):
    meta = read(d / "meta.json")
    rounds_ = sorted((d / "analysis").glob("r*/analysis.json"))
    analysis = read(rounds_[-1]) if rounds_ else None
    card = d / "style-card.md"
    job = read(d / "review" / "job.json") if (d / "review" / "job.json").exists() else None
    if job and job["state"] == "running" and job.get("kind") == "analyze" and job.get("pid") != os.getpid():
        job = {"state": "failed", "error": "המדידה נקטעה כשהחדר נסגר. אפשר לנסות שוב."}
    elif job and job.get("kind") == "learn":
        job = jobs.status(f"insp:{d.name}")["job"]   # notices a Claude job that ended while the room was closed
    if job and job["state"] == "running":
        state = "working"
    elif card.exists():
        state = "ready"
    elif job and job["state"] == "failed":
        state = "failed"
    else:
        state = "saved" if source(d) else "new"
    hook = rounds_[-1].parent / "hook.jpg" if rounds_ else None
    return {**meta, "state": state, "measured": (analysis or {}).get("measured"),
            "card": card_lines(card.read_text(encoding="utf-8")) if card.exists() else None,
            "hook": f"/insp/{d.name}/{hook.relative_to(d).as_posix()}" if hook and hook.exists() else None,
            "error": (job or {}).get("error")}


def inspirations():
    return [inspiration(d) for d in sorted(rounds.INSP.iterdir(), reverse=True) if (d / "meta.json").exists()] if rounds.INSP.exists() else []


def analyze(d):
    """Measure the video (cuts, loudness, contact sheets, words; engine/studio/learn_analysis.py), into d/analysis/rNN."""
    r = subprocess.run([str(paths.PYTHON), str(STUDIO / "learn_analysis.py"), str(d)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5400,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if r.returncode:
        raise RuntimeError((r.stderr or r.stdout).strip().splitlines()[-1][:300] if (r.stderr or r.stdout).strip() else "analysis failed")


# ---- lessons: what Claude learned from Ron's notes (library/lessons.json, kept by every round job)
def lessons():
    return read(LESSONS) if LESSONS.exists() else []


# ---- analysis of one video: what the system found, from the files the pipeline already writes
def speaker_shares(sp):
    """analysis/speakers.json (engine/episode.py) -> [{name, share, camera}] for the analysis page."""
    if not sp:
        return None
    turns = sp["turns"]
    total = sum(t["e"] - t["s"] for t in turns) or 1
    rows = []
    for who in sorted({t["who"] for t in turns}, key=str):
        secs = sum(t["e"] - t["s"] for t in turns if t["who"] == who)
        both = who == "both"
        rows.append({"name": "שניהם יחד" if both else f"דובר {who + 1}",
                     "share": round(100 * secs / total),
                     "camera": "מסך מפוצל" if both else sp["cameras"][who]})
    return rows


def video_analysis(vdir):
    def j(p):
        return read(p) if p.exists() else None
    words = j(vdir / "transcript" / "words.json")
    segs = j(vdir / "takes" / "edit_segments.json")
    progress = j(vdir / "review" / "progress.json")
    report = j(vdir / "review" / "report.json")
    seg_list = segs.get("segments", segs) if isinstance(segs, dict) else (segs or [])
    kept = sum(max(0.0, float(s[1]) - float(s[0])) for s in seg_list if isinstance(s, (list, tuple)) and len(s) >= 2)
    return {"name": vdir.name,
            "words": len(words["words"]) if words else None,
            "segments": len(seg_list) or None,
            "kept_seconds": round(kept, 1) if kept else None,
            "progress": progress, "report": report,
            "speakers": speaker_shares(j(vdir / "analysis" / "speakers.json")),   # podcasts (stage 3)
            "highlights": j(vdir / "analysis" / "highlights.json"),   # proposed moments (stage 4)
            "cuts": j(vdir / "analysis" / "cuts.json"),               # proposed cuts inside an episode (4.3)
            "brief": j(vdir / "review" / "brief.json")}
