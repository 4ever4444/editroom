"""Clients and folders (stage 7, Ron 19.11): order for people who edit for many clients.

A folder is a piece of source material (an uploaded raw, a podcast episode) together with everything made from it
(reels and stories from the episode, short versions of a reel). A client sits above the folders. Only the source
carries the client (its brief.json "client"); what was made from it follows its source, so moving a folder to
another client moves all of it. The video folders on disk do not move: this is order on the page, not on the disk.
"""
import json
import uuid

import paths
import rounds

CLIENTS = paths.CLIENTS / "clients.json"   # the user's own data (not in git); logos go beside it (stage 8)
MADE_FROM = ("from_episode", "cutdown_of")          # brief.json keys that name the video something was made from


def listing():
    return json.loads(CLIENTS.read_text(encoding="utf-8")) if CLIENTS.exists() else []


def add(name):
    name = " ".join(str(name).split())[:60]
    if not name:
        raise ValueError("צריך שם ללקוח")
    rows = listing()
    if any(c["name"] == name for c in rows):
        raise FileExistsError(name)
    row = {"id": uuid.uuid4().hex[:10], "name": name, "at": rounds.now()}
    CLIENTS.parent.mkdir(parents=True, exist_ok=True)
    rounds.write_atomic(CLIENTS, rows + [row])
    return row


def brief(vdir):
    p = vdir / "review" / "brief.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def source(vdir):
    """The source material a video was made from (itself if it is one). Follows made-from links that still exist;
    a loop or a deleted source stops at the last video found."""
    seen = {vdir.name}
    while True:
        b = brief(vdir)
        parent = next((b[k] for k in MADE_FROM if b.get(k)), None)
        if not parent or parent in seen or not (rounds.VIDEOS / parent).is_dir():
            return vdir
        seen.add(parent)
        vdir = rounds.VIDEOS / parent


def client_of(vdir):
    """The client of a video: its source's, if that client still exists."""
    cid = brief(source(vdir)).get("client")
    return cid if any(c["id"] == cid for c in listing()) else None


def assign(vdir, client_id):
    """Put a whole folder under a client (or none, with an empty id). Written on the source only."""
    if client_id and not any(c["id"] == client_id for c in listing()):
        raise KeyError(client_id)
    src = source(vdir)
    p = src / "review" / "brief.json"
    if not client_id and not p.exists():   # nothing to take off: leave an old video without a brief as it was
        return src.name
    p.parent.mkdir(exist_ok=True)
    b = brief(src)
    if client_id:
        b["client"] = client_id
    else:
        b.pop("client", None)
    rounds.write_atomic(p, b)
    return src.name
