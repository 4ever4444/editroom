"""Ron's own fixes in the editing room (stage 12.1): review/manual.json, applied over what Claude made, with no Claude.

They are locked (Ron 21.11): Claude does not change or undo them in later rounds unless Ron asks to change, add or close
one. The room shows them at once (engine/room/manual.js does the same as apply() here, on the same data), and the
render applies them (render.build_props, music.bed, render.compose).

manual.json, every part optional; times in seconds on the cut:
  "items":  {"<graphic / effect / library block id>": {"from", "dur"}}  ("title": {"dur"} = how long the title stays;
            a library block only moves: its length is the block's own)
  "hidden": {"<id>": true | false}   over graphics.json "hidden" (false shows what Claude hid)
  "deleted": ["<id>"]                gone from the video and from the room's lists
  "swap":   {"<graphic id>": "<kind>"}  another graphic from the catalog, same words (text kinds) or same place
  "pages":  {"<page index>": {"was", "text"?, "s"?, "e"?}}  a subtitle's words and times ("was" = its words as
            Claude made them: a page that has neither those words nor Ron's (a new cut) is left alone)
  "volume": {"voice": dB, "music": dB, "sfx": {"<graphic / effect id>": dB}}
  "music":  {"file": "<song>"} | {"off": true}   another song from the library (with a licence), or none
  "cut":    {"segments": [[start, end], ...], "fixes": {"<word index>": "<spelling>"}}  Ron's own cut (stage 12.2):
            pieces of the raw (source.mkv seconds) in the order they play, and his spelling of words (indexes in the
            room's word list). engine/mycut.py applies it on "סרטון סופי".
Every save keeps the one before it in review/manual-history/, and "ביטול" (undo) brings it back.
"""
import json
import re
from pathlib import Path

LATIN = re.compile(r"^[A-Za-z0-9' \-]+[,.?!:;]?$")   # = subtitles.LATIN
TEXT_KINDS = ("TypedText", "CallToAction", "Checklist")
PICTURE_KINDS = ("CoinStack", "PaperPlane", "Burst")
MIN_FRAMES = {"Flash": 2, "Glitch": 3, "Burst": 7}   # shorter than this they cannot be drawn and stop the whole render (24.11)
VOLUME = {"voice": (-12, 0), "music": (-12, 6), "sfx": (-18, 6)}   # dB ranges the room offers


def path(vdir):
    return Path(vdir) / "review" / "manual.json"


def load(vdir):
    p = path(vdir)
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def history(vdir):
    return sorted((Path(vdir) / "review" / "manual-history").glob("*.json"))


def save(vdir, m):
    """Check and write; the previous state goes to the history first."""
    m = check(m)
    p = path(vdir)
    if p.exists():
        h = p.parent / "manual-history"
        h.mkdir(exist_ok=True)
        n = int(history(vdir)[-1].stem) + 1 if history(vdir) else 1
        (h / f"{n:04d}.json").write_bytes(p.read_bytes())
    p.parent.mkdir(exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(m, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(p)
    return m


def write(vdir, m):
    """Ron's fixes moved by the machine (a new cut, engine/mycut.py): written as they are, no undo step of their own."""
    p = path(vdir)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(check(m), ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(p)


def undo(vdir):
    """Back to the state before the last save. None when there is nothing to undo."""
    h = history(vdir)
    if not h:
        return None
    p = path(vdir)
    h[-1].replace(p)
    return load(vdir)


def check(m):
    if not isinstance(m, dict):
        raise ValueError("manual: an object")
    num = lambda x: isinstance(x, (int, float)) and not isinstance(x, bool) and x >= 0
    for i, v in m.get("items", {}).items():
        if not all(num(v.get(k, 0)) for k in ("from", "dur")) or v.get("dur", 1) <= 0:
            raise ValueError(f"manual: bad times for {i}")
    for i, k in m.get("swap", {}).items():
        if k not in TEXT_KINDS + PICTURE_KINDS:
            raise ValueError(f"manual: unknown graphic {k}")
    for i, v in m.get("pages", {}).items():
        if not str(i).isdigit() or "was" not in v or ("text" in v and not str(v["text"]).strip()):
            raise ValueError(f"manual: bad subtitle {i}")
        if "s" in v and "e" in v and not (num(v["s"]) and v["e"] > v["s"]):
            raise ValueError(f"manual: subtitle {i} ends before it starts")
    if "cut" in m:
        segs = m["cut"].get("segments")
        if not (isinstance(segs, list) and segs and all(isinstance(x, list) and len(x) == 2 and num(x[0]) and x[1] > x[0]
                                                         for x in segs)):
            raise ValueError("manual: bad cut")
        by_time = sorted(segs)
        if any(a[1] > b[0] + 1e-6 for a, b in zip(by_time, by_time[1:])):
            raise ValueError("manual: two pieces of the cut share a moment of the raw")
        if not all(str(i).isdigit() and str(t).strip() for i, t in m["cut"].get("fixes", {}).items()):
            raise ValueError("manual: bad spelling fix")
    import longfix   # the long-video parts (stage 12.3)
    longfix.check(m)
    vol = m.get("volume", {})
    for k in ("voice", "music"):
        if k in vol and not VOLUME[k][0] <= vol[k] <= VOLUME[k][1]:
            raise ValueError(f"manual: {k} volume out of range")
    if any(not VOLUME["sfx"][0] <= d <= VOLUME["sfx"][1] for d in vol.get("sfx", {}).values()):
        raise ValueError("manual: sound volume out of range")
    return m


def units(text):
    """A subtitle's words as Overlay units: consecutive English words stay one unit (= subtitles.units)."""
    out = []
    for w in text.split():
        if out and out[-1][1] and LATIN.match(w):
            out[-1][0] += " " + w
        else:
            out.append([w, bool(LATIN.match(w))])
    return out


def swap(g, kind):
    """The graphic as another kind: a text kind keeps its words, a picture kind starts from its own defaults."""
    p = g["props"]
    old = ([x["text"] for x in p.get("lines", [])] if g["kind"] == "TypedText" else [p.get("text", "")]
           if g["kind"] == "CallToAction" else [p.get("title", "")] + [x["text"] for x in p.get("items", [])]
           if g["kind"] == "Checklist" else [])
    if kind in TEXT_KINDS and not old or kind in PICTURE_KINDS and g["kind"] in TEXT_KINDS:
        raise ValueError(f"manual: {g['kind']} -> {kind}")
    step = lambda k, n: round(g["dur"] * 0.6 * k / max(1, n))   # one line after another over the first 60%
    new = ({"lines": [{"text": t, "at": step(k, len(old))} for k, t in enumerate(old)]} if kind == "TypedText" else
           {"text": " ".join(old)} if kind == "CallToAction" else
           {"title": old[0], "items": [{"text": t, "at": step(k + 1, len(old))} for k, t in enumerate(old[1:] or old[:1])]}
           if kind == "Checklist" else {})
    return {**g, "kind": kind, "props": new}


def drawable(g, frames):
    """A graphic or effect long enough to be drawn: only one that is too short changes, and starts earlier at the end."""
    least = MIN_FRAMES.get(g["kind"], 1)
    if g["dur"] >= least:
        return g
    return {**g, "dur": least, "from": max(0, min(g["from"], frames - least))}


def apply(props, m):
    """The room's / the render's props with Ron's fixes over them (a new object; props is left as it was)."""
    fps, frames = props["fps"], props["durationInFrames"]
    out = {**props}
    items, swaps = m.get("items", {}), m.get("swap", {})

    def move(lst, length=True):
        res = []
        for g in lst:
            if g["id"] in items:
                v = items[g["id"]]
                start = min(round(v.get("from", g["from"] / fps) * fps), frames - 1)
                dur = round(v["dur"] * fps) if length and "dur" in v else g["dur"]
                g = {**g, "from": start, "dur": max(1, min(dur, frames - start))}
            g = swap(g, swaps[g["id"]]) if g["id"] in swaps and swaps[g["id"]] != g.get("kind") else g
            res.append(drawable(g, frames) if length else g)
        return res
    out["graphics"] = move(props.get("graphics", []))
    out["effects"] = move(props.get("effects", []))
    out["hf"] = move(props.get("hf", []), length=False)
    if "dur" in items.get("title", {}):
        out["titleEnd"] = min(items["title"]["dur"], frames / fps)
    hidden = [h for h in props.get("hidden", []) if m.get("hidden", {}).get(h, True)]
    hidden += [h for h, on in m.get("hidden", {}).items() if on and h not in hidden]
    out["deleted"] = list(m.get("deleted", []))
    out["hidden"] = hidden + [d for d in out["deleted"] if d not in hidden]
    pages = [dict(p) for p in props.get("pages", [])]
    for i, v in m.get("pages", {}).items():
        i = int(i)
        if i < len(pages) and pages[i]["text"] in (v["was"], v.get("text")):   # or Claude fixed the transcript to match
            if "text" in v:
                pages[i].update(text=v["text"], units=units(v["text"]))
            pages[i].update({k: v[k] for k in ("s", "e") if k in v})
    out["pages"] = pages
    vol = m.get("volume", {})
    out["sfxGain"] = {i: round(10 ** (d / 20), 4) for i, d in vol.get("sfx", {}).items()}
    out["voiceDb"] = vol.get("voice", 0)
    return out


def music(g, m):
    """graphics.json "music" with Ron's song and level over it; None = no music."""
    pick = m.get("music")
    if pick and pick.get("off"):
        return None
    base = {"file": pick["file"], "start": 0} if pick else g.get("music")
    if not base:
        return None
    return {**base, "level_db": float(base.get("level_db", 0)) + m.get("volume", {}).get("music", 0)}


if __name__ == "__main__":
    import shutil
    import tempfile
    fps = 30
    tt = {"id": "a", "kind": "TypedText", "from": 30, "dur": 60, "props": {"lines": [{"text": "שורה", "at": 0}, {"text": "שתיים", "at": 20}]}}
    base = {"fps": fps, "durationInFrames": 300, "titleEnd": 2.0, "hidden": ["c"],
            "graphics": [tt, {"id": "b", "kind": "Burst", "from": 0, "dur": 10, "props": {"x": 1}}],
            "effects": [{"id": "c", "kind": "Glitch", "from": 0, "dur": 9, "props": {}}],
            "hf": [{"id": "h", "kind": "hf", "from": 0, "dur": 90, "props": {}}],
            "pages": [{"text": "רוב האנשים", "s": 0, "e": 1, "units": []}, {"text": "שלום", "s": 1, "e": 2, "units": []}]}
    m = check({"items": {"a": {"from": 5, "dur": 1}, "h": {"from": 9.5, "dur": 1}, "title": {"dur": 3}},
               "hidden": {"c": False, "b": True}, "deleted": ["h"], "swap": {"a": "Checklist"},
               "pages": {"0": {"was": "רוב האנשים", "text": "רוב Google Ads", "e": 1.5}, "1": {"was": "אחר", "text": "x"}},
               "volume": {"voice": -3, "sfx": {"a": 6}}})
    p = apply(base, m)
    a = p["graphics"][0]
    assert (a["from"], a["dur"], a["kind"]) == (150, 30, "Checklist") and a["props"]["title"] == "שורה", a
    assert a["props"]["items"] == [{"text": "שתיים", "at": 9}], a          # same words, another graphic
    assert p["hf"][0]["from"] == 285 and p["hf"][0]["dur"] == 15            # moved, kept inside the video
    assert p["titleEnd"] == 3 and p["hidden"] == ["b", "h"] and p["deleted"] == ["h"]
    assert p["pages"][0] == {"text": "רוב Google Ads", "s": 0, "e": 1.5, "units": [["רוב", False], ["Google Ads", True]]}
    assert p["pages"][1]["text"] == "שלום"                                   # its words changed since: left alone
    fixed = {**base, "pages": [{**base["pages"][0], "text": "רוב Google Ads"}]}   # Claude put Ron's words in the transcript
    assert apply(fixed, m)["pages"][0]["e"] == 1.5
    assert p["sfxGain"] == {"a": 1.9953} and p["voiceDb"] == -3 and base["graphics"][0] is tt and tt["from"] == 30
    # too short to draw: these three stop the whole render (interpolate needs a range that grows), also after a swap, also at
    # the last frame; an item that is long enough, and a library block, are never touched (24.11)
    tiny = lambda i, kind, dur, at=298: {"id": i, "kind": kind, "from": at, "dur": dur, "props": {}}
    short = {**base, "pages": [], "effects": [tiny("f", "Flash", 1, 299), tiny("gl", "Glitch", 2), tiny("z", "Zoom", 9, 100)],
             "graphics": [tiny("pl", "PaperPlane", 2), tiny("bu", "Burst", 6, 50), tiny("ok", "Burst", 7, 60)], "hf": [tiny("h", "hf", 1, 299)]}
    s = apply(short, {"swap": {"pl": "Burst"}, "items": {"f": {"from": 9.9, "dur": 0.02}}})
    got = {g["id"]: (g["from"], g["dur"]) for g in s["effects"] + s["graphics"] + s["hf"]}
    assert got == {"f": (297, 2), "gl": (297, 3), "z": (100, 9), "pl": (293, 7), "bu": (50, 7),
                   "ok": (60, 7), "h": (299, 1)}, got
    for bad in ({"swap": {"a": "Nope"}}, {"volume": {"voice": 3}}, {"pages": {"0": {"text": "x"}}},
                {"items": {"a": {"from": -1, "dur": 1}}}, {"pages": {"0": {"was": "a", "s": 2, "e": 1}}},
                {"cut": {"segments": [[0, 2], [1, 3]]}}, {"cut": {"segments": []}}, {"cut": {"segments": [[3, 2]]}}):
        try:
            check(bad)
            raise AssertionError(bad)
        except ValueError:
            pass
    try:
        swap(base["graphics"][1], "TypedText")
        raise AssertionError("a picture has no words to type")
    except ValueError:
        pass
    assert music({"music": {"file": "a.mp3", "start": 4, "level_db": 3}}, {"volume": {"music": -2}}) == \
        {"file": "a.mp3", "start": 4, "level_db": 1.0}
    assert music({"music": {"file": "a.mp3"}}, {"music": {"off": True}}) is None and music({}, {}) is None
    assert music({}, {"music": {"file": "b.mp3"}}) == {"file": "b.mp3", "start": 0, "level_db": 0.0}
    tmp = Path(tempfile.mkdtemp())
    try:
        save(tmp, {"items": {"a": {"from": 1, "dur": 1}}})
        save(tmp, {"deleted": ["a"]})
        assert load(tmp) == {"deleted": ["a"]} and len(history(tmp)) == 1
        assert undo(tmp) == {"items": {"a": {"from": 1, "dur": 1}}} and undo(tmp) is None
    finally:
        shutil.rmtree(tmp)
    print("manual self-check OK")
