"""Two-camera podcast -> one 16:9 episode that cuts to whoever speaks.

usage: python engine/episode.py "videos/<name>" [--preview | --check | --map <preview seconds>]
raw/ (or the video folder itself, sub-folders like AUDIO/ included) holds the camera files (sorted by name:
camera 1, camera 2) and, optionally, separate mic recordings (.wav/.m4a/.mp3/.aac, sorted the same way:
mic 1 = the speaker on camera 1).
Without separate mics, each camera's own sound is that camera's speaker.
writes analysis/sync.json, analysis/speakers.json, analysis/shots.json and
final/episode.mp4 (1920x1080) or, with --preview, takes/episode_preview.mp4 (640x360, fast).
"""
import json
import re
import subprocess
import sys
from pathlib import Path

import numpy as np

import endcard
import logo
import longfix
import podcast
import talk
import title
import tools
from media import HOP, envelope_db, load_audio, probe, read_json, write_json

VIDEO_EXT = {".mp4", ".mov", ".mkv", ".mxf", ".avi"}
AUDIO_EXT = {".wav", ".m4a", ".mp3", ".aac", ".flac"}
LUFS = -14
SYNC_MIN_PEAK = 0.3   # weaker correlation = the files may not be from the same session


WORK_DIRS = {"takes", "final", "analysis", "transcript", "review", "slides"}   # slides: a talk's deck (engine/talk.py)


def sources(vdir):
    """Camera and mic files from raw/ (a room podcast) or from the video folder itself (copied in by hand),
    including sub-folders such as AUDIO/. Our own work folders are skipped. Two cameras = a podcast, three or four = a
    panel (stage 11.3); one camera = a long YouTube video or a talk (11.2, 11.3), the same machine without camera
    switches. One camera may come with several sound files: a Zoom or Meet recording with a file per participant."""
    base = vdir / "raw" if (vdir / "raw").is_dir() else vdir
    raw = sorted((p for p in base.rglob("*")
                  if p.is_file() and not WORK_DIRS & set(p.relative_to(base).parts[:-1])), key=lambda p: p.name)
    cams = [p for p in raw if p.suffix.lower() in VIDEO_EXT]
    mics = [p for p in raw if p.suffix.lower() in AUDIO_EXT]
    if not 1 <= len(cams) <= MAX_CAMS:
        sys.exit(f"צריך בין מצלמה אחת ל-{MAX_CAMS} מצלמות בתיקייה, נמצאו {len(cams)}")
    if mics and len(mics) != len(cams) and len(cams) > 1:
        sys.exit(f"נמצאו {len(mics)} קבצי קול ו-{len(cams)} מצלמות: צריך קובץ קול לכל מצלמה, או בלי קבצי קול")
    return cams, mics


def sync(files, same_clock=False):
    """Offsets onto the first file's clock + drift check, from the sound of each file.
    same_clock: the files were recorded together from one start (a Zoom meeting's file per participant, where a
    participant who hardly speaks has too little sound to line up on): no search, every offset 0."""
    envs = [envelope_db(load_audio(f)) for f in files]
    if same_clock:
        return [{"file": f.name, "offset": 0.0, "peak": 1.0, "drift": [0.0, 0.0]} for f in files], envs
    rows = [{"file": files[0].name, "offset": 0.0, "peak": 1.0, "drift": [0.0, 0.0]}]
    for f, e in zip(files[1:], envs[1:]):
        off, peak = podcast.offset(envs[0], e)
        rows.append({"file": f.name, "offset": round(off, 3), "peak": round(peak, 3),
                     "drift": podcast.drift(envs[0], e, off)})
    return rows, envs


def window(rows, durations):
    """Master timeline: from when every file runs to when the first one stops (first file's clock)."""
    t0 = max(r["offset"] for r in rows)
    t1 = min(r["offset"] + d for r, d in zip(rows, durations))
    return t0, t1


def aligned(env, off, t0, t1):
    a = int(round((t0 - off) / HOP))
    return env[a:a + int(round((t1 - t0) / HOP))]


MAX_CAMS = 4   # a panel on a stage (stage 11.3): a camera and a mic per speaker


def video_graph(shots, w, h, fps, focus=(0.5, 0.5), cams=2):
    """Each camera and the split screen run side by side; a streamselect, switched by timed commands (one per shot,
    so an hour-long episode stays small), picks which one is shown: camera i = input i, the split screen (shot
    cam 99, several talking at once) = the last input.
    Split screen: wide frames put the cameras side by side (four: a 2x2 grid), tall frames (reels) one above the other.
    focus: where each camera's person sits across its frame (engine/reframe.py), so a narrower crop keeps them in it."""
    focus = [focus[i] if i < len(focus) else 0.5 for i in range(cams)]
    if cams == 1:   # one camera (a long YouTube video): the picture, sized; nothing to switch
        return (f"[0:v]fps={fps},scale={w}:{h}:force_original_aspect_ratio=increase,"
                f"crop={w}:{h}:'min(max(0,iw*{focus[0]}-ow/2),iw-ow)':'(ih-oh)/2',setsar=1[v]")
    # ponytail: split screen takes each camera's centre strip; follow the face if speakers sit off-centre
    if w > h and cams == 4:
        cell, join = f"scale={w // 2}:{h // 2}", "xstack=inputs=4:layout=0_0|w0_0|0_h0|w0_h0"
    elif w > h:
        cell, join = f"crop=iw/{cams}:ih:iw*{(cams - 1) / (2 * cams):.4f}:0", f"hstack=inputs={cams}"
    else:
        cell, join = f"crop=iw:ih/{cams}:0:ih*{(cams - 1) / (2 * cams):.4f}", f"vstack=inputs={cams}"
    sel = lambda cam: cams if cam == 99 else cam
    cmds = ";".join(f"{s['s']} streamselect@sel map {sel(s['cam'])}" for s in shots)
    g = []
    for i, f in enumerate(focus):
        g.append(f"[{i}:v]" + (f"sendcmd=c='{cmds}'," if i == 0 else "") +
                 f"fps={fps},scale={w}:{h}:force_original_aspect_ratio=increase,"
                 f"crop={w}:{h}:'min(max(0,iw*{f}-ow/2),iw-ow)':'(ih-oh)/2',setsar=1,split[a{i}][b{i}];[b{i}]{cell}[c{i}]")
    g.append("".join(f"[c{i}]" for i in range(cams)) + f"{join}[sp]")
    g.append("".join(f"[a{i}]" for i in range(cams)) + f"[sp]streamselect@sel=inputs={cams + 1}:map={sel(shots[0]['cam'])}[v]")
    return ";".join(g)


def audio_graph(audio_inputs, tail):
    ins = "".join(f"[{i}:a]" for i in audio_inputs)
    mix = f"amix=inputs={len(audio_inputs)}:normalize=0," if len(audio_inputs) > 1 else ""
    return f"{ins}{mix}{tail}[ao]"


def run(*args):
    r = subprocess.run([tools.FFMPEG, "-hide_banner", "-y", *map(str, args)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode:
        raise RuntimeError(r.stderr[-3000:])
    return r.stderr


PREVIEW = {"size": (640, 360), "enc": ["-c:v", "libx264", "-preset", "ultrafast", "-crf", "28"]}
FINAL = {"size": (1920, 1080), "enc": ["-c:v", "libx264", "-preset", "medium", "-crf", "18"]}


def clip_shots(shots, a, b, opening=True):
    """The shots between a and b on the episode, moved to start at 0. An opening never opens on the split screen
    (Ron, 17.11: a split screen in the first seconds looks like a glitch): the first speaker's camera instead.
    opening=False: a piece from the middle of the episode, which keeps the shot as it is."""
    out = [{"cam": s["cam"], "s": round(max(s["s"], a) - a, 2), "e": round(min(s["e"], b) - a, 2)}
           for s in shots if s["e"] > a and s["s"] < b]
    if opening and out and out[0]["cam"] == 99:
        out[0]["cam"] = next((s["cam"] for s in out if s["cam"] != 99), 0)
    return out


def trim(vdir, total):
    """The part of the recording that is the episode, in seconds on the preview: analysis/trim.json
    {"from", "to"} (set after reading the transcript: setup chatter before, goodbyes after). Default: all."""
    p = vdir / "analysis" / "trim.json"
    t = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    a, b = longfix.trim(vdir, (t.get("from", 0.0), t.get("to", total)))   # Ron's own start and end (12.3) first
    return max(0.0, a), min(total, b)


MAX_KEEP = 60   # kept parts in one select expression: 300 failed ("Cannot allocate memory"); more go in pieces (render_long)
PIECE_ENC = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "12"]   # a piece, before the last pass


def cut_list(vdir):
    """Cuts Ron accepted inside the episode (analysis/cuts.json, `apply` true), preview seconds, merged."""
    p = vdir / "analysis" / "cuts.json"
    rows = longfix.cuts(json.loads(p.read_text(encoding="utf-8")) if p.exists() else [], longfix.load(vdir))   # + Ron's (12.3)
    spans = sorted((c["s"], c["e"]) for c in rows if c.get("apply") and c["e"] > c["s"])
    merged = []
    for s, e in spans:
        if merged and s <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    return merged


def keep_parts(vdir, total):
    """The episode as played: the trim minus the accepted cuts, as (from, to) in preview seconds."""
    a, b = trim(vdir, total)
    parts, at = [], a
    for s, e in cut_list(vdir):
        if e <= at or s >= b:
            continue
        if s > at:
            parts.append((at, s))
        at = max(at, e)
    if at < b:
        parts.append((at, b))
    return parts


def to_final(parts, t):
    """A preview second -> the same moment in the final episode, or None if it was trimmed or cut."""
    done = 0.0
    for s, e in parts:
        if s <= t < e:
            return round(done + t - s, 3)
        done += e - s
    return None


def from_final(parts, f):
    """A second on the final episode -> the same moment on the preview (Ron marks cuts by the episode's clock)."""
    done = 0.0
    for s, e in parts:
        if f < done + (e - s):
            return round(s + f - done, 3)
        done += e - s
    return round(parts[-1][1], 3) if parts else None


JUMP_ZOOM = 1.1   # every other kept part a little closer (Ron 19.11: cuts inside one shot jumped, "not natural")


def jump_zoom(keep, w, h):
    """After the cut: each kept part after a cut alternates between the frame and a punch-in of JUMP_ZOOM, so a cut
    inside one shot (the person moved a little across the silence that went) reads as a deliberate change of framing,
    as YouTube editors do. Timed commands on the cut clock; the punch-in leans to the upper part, where the faces are."""
    t, cmds = 0.0, []
    for i, (s, e) in enumerate(keep[:-1]):
        t += e - s
        z = JUMP_ZOOM if i % 2 == 0 else 1.0
        cmds.append(f"{t:.3f} crop@jz w iw/{z}, crop@jz h ih/{z}")
    return (f"sendcmd=c='{';'.join(cmds)}',crop@jz=w=iw:h=ih:x=(iw-ow)/2:y=(ih-oh)*0.35,"
            f"scale={w}:{h},setsar=1")


def keep_filter(keep, audio=False):
    expr = "+".join(f"between(t,{s:.3f},{e - 0.001:.3f})" for s, e in keep)
    return f"aselect='{expr}',asetpts=N/SR/TB" if audio else f"select='{expr}',setpts=N/FRAME_RATE/TB"


def render(vdir, cams, mics, rows, t0, t1, shots, out, size, enc, keep=None, focus=(0.5, 0.5), logo_item=None,
           title_mov=None, piece=False, deck=None):
    """keep: the parts to play, (from, to) seconds from t0; None = all of t0..t1. logo_item: the client's logo
    (engine/logo.py, frame "episode"), laid in on the cut clock. title_mov: the opening title (engine/title.py), over
    everything from the first frame. piece: one piece of a long cut (render_long): the sound as mixed, no loudness.
    deck: a talk's slides (engine/talk.py), (video, its offset on the master clock); then shots are cam 0 = the speaker,
    cam 1 = the slide with the speaker in the corner, and no punch-ins (they would cut the slide's edges)."""
    if keep and len(keep) > MAX_KEEP:
        return render_long(vdir, cams, mics, rows, t0, shots, out, size, enc, keep, focus, logo_item, title_mov, deck)
    fps = probe(cams[0])["fps"]
    w, h = size
    files = cams + mics
    inputs = []
    for f, r in zip(files, rows):
        inputs += ["-ss", f"{t0 - r['offset']:.3f}", "-t", f"{t1 - t0:.3f}", "-i", f]
    audio_inputs = list(range(len(cams), len(files))) if mics else list(range(len(cams)))
    if deck:
        start = t0 - deck[1]   # below 0: the screen recording was switched on after the camera
        inputs += ["-ss", f"{max(start, 0):.3f}", "-t", f"{t1 - t0 + min(start, 0):.3f}", "-i", deck[0]]
        picture = talk.graph(shots, w, h, fps, len(files), late=max(-start, 0))
    else:
        picture = video_graph(shots, w, h, fps, focus, cams=len(cams))
    cut_a = keep_filter(keep, audio=True) + "," if keep else ""
    graph = vdir / "takes" / "episode_filter.txt"
    if piece:
        video = picture + (f";[v]{keep_filter(keep)}[vk]" if keep else "")
        graph.write_text(video + ";" + audio_graph(audio_inputs, cut_a + "anull"), encoding="utf-8")
        run(*inputs, "-/filter_complex", graph, "-map", "[vk]" if keep else "[v]", "-map", "[ao]", *enc,
            "-pix_fmt", "yuv420p", "-c:a", "pcm_s24le", "-ar", "48000", out)
        return out
    # loudness: measure the mixed sound (sound only, fast), then apply it in the render
    graph.write_text(audio_graph(audio_inputs, f"{cut_a}loudnorm=I={LUFS}:TP=-1:LRA=11:print_format=json"),
                     encoding="utf-8")
    log = run(*inputs, "-/filter_complex", graph, "-map", "[ao]", "-f", "null", "-")
    m = json.loads(re.findall(r"\{[^{}]*\}", log)[-1])
    ln = (f"loudnorm=I={LUFS}:TP=-1:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:"
          f"measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true")
    # the camera switches run on the uncut clock (sendcmd), the cut comes after them
    video = picture + (f";[v]{keep_filter(keep)}" + ("" if deck else f",{jump_zoom(keep, w, h)}") + "[vk]" if keep else "")
    vout = "vk" if keep else "v"
    if logo_item:   # stage 8: the logo's way in, its still and its way out, each at its time (no hour-long layer)
        more, lg, vout = logo.overlay(logo_item, float(fps), inputs.count("-i"), vout)
        inputs += more
        video += ";" + lg
    if title_mov:   # stage 11.1: the opening title, last, so nothing covers it
        more, tt, vout = title.overlay(title_mov, inputs.count("-i"), vout)
        inputs += more
        video += ";" + tt
    graph.write_text(video + ";" + audio_graph(audio_inputs, cut_a + ln), encoding="utf-8")
    run(*inputs, "-/filter_complex", graph, "-map", f"[{vout}]", "-map", "[ao]", *enc,
        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-movflags", "+faststart", out)
    return out


def render_long(vdir, cams, mics, rows, t0, shots, out, size, enc, keep, focus, logo_item, title_mov, deck=None):
    """More kept parts than one select expression holds (a solo YouTube video cut tight, stage 11.2): the parts go in
    pieces of MAX_KEEP, each rendered on its own; the pieces are joined, and one last pass lays the logo and the title
    over the whole and sets its loudness, so the sound is levelled once and not piece by piece."""
    takes = vdir / "takes"
    pieces = []
    for i in range(0, len(keep), MAX_KEEP):
        g = keep[i:i + MAX_KEEP]
        a, b = g[0][0], g[-1][1]
        piece = takes / f"piece_{i // MAX_KEEP:03}.mkv"
        render(vdir, cams, mics, rows, t0 + a, t0 + b, clip_shots(shots, a, b, opening=not i), piece, size, PIECE_ENC,
               keep=[(s - a, e - a) for s, e in g] if len(g) > 1 else None, focus=focus, piece=True, deck=deck)
        pieces.append(piece)
    joined = takes / "pieces.txt"
    joined.write_text("".join(f"file '{p.resolve().as_posix()}'" + chr(10) for p in pieces), encoding="utf-8")
    fps = probe(cams[0])["fps"]
    inputs = ["-f", "concat", "-safe", "0", "-i", joined]
    log = run(*inputs, "-vn", "-af", f"loudnorm=I={LUFS}:TP=-1:LRA=11:print_format=json", "-f", "null", "-")
    m = json.loads(re.findall(r"\{[^{}]*\}", log)[-1])
    ln = (f"loudnorm=I={LUFS}:TP=-1:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:"
          f"measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true")
    video, vout = f"[0:v]{'null' if deck else jump_zoom(keep, *size)}[v]", "v"   # the punch-ins on the whole cut
    if logo_item:
        more, lg, vout = logo.overlay(logo_item, float(fps), 1, vout)
        inputs += more
        video += ";" + lg
    if title_mov:
        more, tt, vout = title.overlay(title_mov, inputs.count("-i"), vout)
        inputs += more
        video += ";" + tt
    graph = takes / "episode_filter.txt"
    graph.write_text(video + f";[0:a]{ln}[ao]", encoding="utf-8")
    run(*inputs, "-/filter_complex", graph, "-map", f"[{vout}]", "-map", "[ao]", *enc,
        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-movflags", "+faststart", out)
    for p in pieces + [joined]:
        p.unlink()
    return out


def episode_logo(vdir, seconds, fps):
    """analysis/logo.json (the "◆ לוגו" button on the episode's card) -> the logo item on this episode's clock, with
    its pieces made (engine/logo.py), or None."""
    f = vdir / "analysis" / "logo.json"
    if not f.exists():
        return None
    item = logo.resolve({"logo": read_json(f)}, fps, round(seconds * fps), frame="episode")
    if not item:   # "none": only the logo at the end (engine/endcard.py)
        return None
    item["parts"] = logo.parts(vdir, item, fps)
    return item


def main(vdir, preview=False):
    vdir = Path(vdir)
    (vdir / "analysis").mkdir(exist_ok=True)
    (vdir / "takes").mkdir(exist_ok=True)
    (vdir / "final").mkdir(exist_ok=True)
    cams, mics = sources(vdir)
    deck_src = talk.source(vdir)
    screen = deck_src if deck_src and deck_src.suffix.lower() in VIDEO_EXT else None
    files = cams + mics
    zoom = len(cams) == 1 and len(mics) > 1   # one meeting video and a sound file per participant
    rows, envs = sync(files + ([screen] if screen else []), same_clock=zoom)
    if screen:   # a screen recording is synced like a camera, and is not one
        screen_row, rows, envs = rows[-1], rows[:-1], envs[:-1]
        if screen_row["peak"] < SYNC_MIN_PEAK:
            sys.exit("לא הצלחתי לסנכרן את הקלטת המסך לפי הקול. האם יש בה קול מאותה הרצאה?")
    bad = [r["file"] for r in rows[1:] if r["peak"] < SYNC_MIN_PEAK]
    if bad:
        sys.exit(f"לא הצלחתי לסנכרן לפי הקול: {', '.join(bad)}. האם הקבצים מאותה הקלטה?")
    durations = [probe(f)["duration"] if f in cams else len(e) * HOP for f, e in zip(files, envs)]
    t0, t1 = window(rows, durations)
    write_json(vdir / "analysis/sync.json", {"files": rows, "start": round(t0, 3), "end": round(t1, 3)})

    mic_envs = envs[len(cams):] if mics else envs[:len(cams)]
    mic_rows = rows[len(cams):] if mics else rows[:len(cams)]
    aligned_envs = [aligned(e, r["offset"], t0, t1) for e, r in zip(mic_envs, mic_rows)]
    if len(aligned_envs) == 1:   # one voice: talking or not
        e = aligned_envs[0]
        rs = podcast.runs(np.where(e - np.percentile(e, 3) > podcast.SPEECH_DB, 0, -1))
    else:   # a mic per speaker (a camera each, or a Zoom file per participant): who speaks when
        rs = podcast.runs(podcast.labels(aligned_envs))
    if len(cams) == 1:   # one camera: a single shot
        shots = [{"cam": 0, "s": 0.0, "e": round(t1 - t0, 2)}]
    else:
        shots = podcast.plan(rs, t1 - t0, first_cam=next((lb for lb, *_ in rs if 0 <= lb < len(cams)), 0))
        write_json(vdir / "analysis/shots_plan.json", shots)   # the plan alone: the page lays Ron's choices on it itself
        shots = longfix.shots(shots, longfix.load(vdir))   # Ron's camera choices (12.3) over the plan
    write_json(vdir / "analysis/speakers.json", {"mics": [r["file"] for r in mic_rows],
                                                 "cameras": [c.name for c in cams],
                                                 "turns": podcast.speakers(rs)})
    fps = float(probe(cams[0])["fps"])
    deck = None
    if deck_src:   # a talk (stage 11.3): the slide shots replace the camera's single shot
        shots, deck = talk.deck_for(vdir, t0, t1, fps, screen_row["offset"] if screen else None)
    write_json(vdir / "analysis/shots.json", shots)
    if preview:   # the whole recording, so the transcript and the moments use one timeline
        out = vdir / "takes/episode_preview.mp4"
        render(vdir, cams, mics, rows, t0, t1, shots, out, **PREVIEW, deck=deck)
    else:
        a, b = trim(vdir, t1 - t0)
        parts = keep_parts(vdir, t1 - t0)
        keep = [(s - a, e - a) for s, e in parts] if len(parts) > 1 else None
        work, out = vdir / "takes/episode_final.mp4", vdir / "final/episode.mp4"   # the room sees only a finished file
        ttl = title.chosen(vdir)
        render(vdir, cams, mics, rows, t0 + a, t0 + b, clip_shots(shots, a, b), work, **FINAL, keep=keep,
               logo_item=episode_logo(vdir, sum(e - s for s, e in parts), fps),
               title_mov=title.layer(vdir, title.check(ttl), fps) if ttl else None, deck=deck)
        level(work)
        lg = vdir / "analysis" / "logo.json"
        endcard.finish(vdir, work, read_json(lg) if lg.exists() else None, "episode")   # stage 11.6: the logo at the end
        work.replace(out)
        write_json(vdir / "analysis/final_parts.json", parts)   # the clock of this episode.mp4, for marks made on it
        (vdir / "analysis/title_rendered.json").unlink(missing_ok=True)
        if ttl:   # which title is in this episode.mp4: the page says when a new choice will replace it
            write_json(vdir / "analysis/title_rendered.json", ttl)
        if ttl:
            title.thumbnail(vdir, title.check(ttl))   # the YouTube thumbnail, from this episode's picture
    print(f"sync {[(r['file'], r['offset'], r['peak'], r['drift']) for r in rows]}")
    print(f"recording {t1 - t0:.1f}s, {len(shots)} shots -> {out}")


def loudness(path):
    return json.loads(re.findall(r"\{[^{}]*\}", run("-i", path, "-vn", "-af", "loudnorm=print_format=json",
                                                    "-f", "null", "-"))[-1])


def level(path, tol=0.5):
    """loudnorm can land under target when speech peaks hold it back (an hour-long episode came out at -15.4).
    Then: the missing gain plus a limiter, on the sound only; the picture is copied, not re-encoded."""
    gap = LUFS - float(loudness(path)["input_i"])
    if abs(gap) <= tol:
        return
    tmp = path.with_name(path.stem + "_level.mp4")
    run("-i", path, "-map", "0", "-c:v", "copy", "-af", f"volume={gap:.2f}dB,alimiter=limit=0.84:level=false",
        "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-movflags", "+faststart", tmp)
    tmp.replace(path)


def check(vdir):
    """One line per check on final/episode.mp4, OK or FAIL (the raw-output-is-evidence rule)."""
    vdir = Path(vdir)
    out = vdir / "final/episode.mp4"
    sync = json.loads((vdir / "analysis/sync.json").read_text(encoding="utf-8"))
    p = probe(out)
    m = loudness(out)
    want = sum(e - s for s, e in keep_parts(vdir, sync["end"] - sync["start"]))
    lg = vdir / "analysis" / "logo.json"
    if lg.exists() and read_json(lg).get("end"):   # the logo at the end (11.6) plays on after the episode
        want += endcard.catalog()["after"]

    rows = [("size", (p["w"], p["h"]) == FINAL["size"], f"{p['w']}x{p['h']}"),
            ("length", abs(p["duration"] - want) < 0.5, f"{p['duration']:.1f}s, expected {want:.1f}s"),
            ("loudness", abs(float(m["input_i"]) - LUFS) <= 1, f"{m['input_i']} LUFS"),
            ("true peak", float(m["input_tp"]) <= -0.5, f"{m['input_tp']} dBTP")]
    for f in sync["files"][1:]:
        d = [x for x in f["drift"] if x is not None]
        rows.append((f"sync {f['file']}", f["peak"] >= SYNC_MIN_PEAK and (max(d) - min(d) if d else 0) < 0.05,
                     f"offset {f['offset']}s, match {f['peak']}, start/end {f['drift']}"))
    for name, ok, detail in rows:
        print(f"{name}: {detail} {'OK' if ok else 'FAIL'}")
    return all(ok for _, ok, _ in rows)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if "--check" in sys.argv:
        sys.exit(0 if check(sys.argv[1]) else 1)
    if "--map" in sys.argv:   # a preview second -> the final episode (for chapters): prints mm:ss, or "cut"
        v = Path(sys.argv[1])
        sy = json.loads((v / "analysis/sync.json").read_text(encoding="utf-8"))
        f = to_final(keep_parts(v, sy["end"] - sy["start"]), float(sys.argv[sys.argv.index("--map") + 1]))
        sys.exit(print("cut" if f is None else f"{int(f // 60):02}:{int(f % 60):02}"))

    main(sys.argv[1], "--preview" in sys.argv)
