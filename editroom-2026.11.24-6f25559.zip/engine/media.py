"""Shared helpers: ffmpeg path, probing, audio loading, loudness envelope."""
import json
import subprocess
from pathlib import Path

import av
import imageio_ffmpeg
import numpy as np
from faster_whisper import decode_audio

FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
SR = 16000
HOP = 0.01  # envelope resolution, seconds


def ffmpeg(*args, capture=False):
    r = subprocess.run([FFMPEG, "-hide_banner", "-y", *map(str, args)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode:
        raise RuntimeError(r.stderr[-3000:])
    return r.stderr if capture else None


def probe(path):
    with av.open(str(path)) as c:
        v, a = c.streams.video[0], c.streams.audio[0]
        return {"fps": v.average_rate, "w": v.width, "h": v.height,
                "duration": float(c.duration / av.time_base), "channels": a.channels, "rate": a.rate}


def load_audio(path):
    return decode_audio(str(path), sampling_rate=SR)


def envelope_db(audio):
    """RMS in dBFS per HOP window."""
    n = int(SR * HOP)
    frames = audio[: len(audio) // n * n].reshape(-1, n)
    return 20 * np.log10(np.sqrt((frames ** 2).mean(1)) + 1e-9)


def hiss_ratio(audio, cutoff=3500):
    """Share of energy above cutoff per HOP window: high for ס/ש/צ/ז, ~0 for vowels."""
    n = int(SR * HOP)
    frames = audio[: len(audio) // n * n].reshape(-1, n)
    p = np.abs(np.fft.rfft(frames * np.hanning(n), axis=1)) ** 2
    hi = np.fft.rfftfreq(n, 1 / SR) > cutoff
    return p[:, hi].sum(1) / (p.sum(1) + 1e-12)


def noise_floor(env):
    return float(np.percentile(env, 10))


def read_json(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def write_json(p, data):
    Path(p).write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
