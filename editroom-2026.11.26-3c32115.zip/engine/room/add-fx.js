// "+ אפקט כאן" (stage f, docs/addfx-spec*.md): the room's own 5 effects and 6 graphics, added by the user at the player's
// moment, shown at once and saved as one of their own fixes (review/manual.json "added", locked like every fix). Nothing
// here knows the rules by heart: the kinds, their props, ranges and lengths come from the server (manual.rules()), and
// whyNot (= manual.why_not) checks an item before it is saved, so the server has nothing to refuse (v4 Δ40, Δ49).
import {rawAt, textFrames, whyNot} from './manual.js';

const ICON = {TypedText: '⌨', CallToAction: '👆', Checklist: '☑', CoinStack: '🪙', PaperPlane: '✈', Glitch: '▦', Zoom: '🔍',
  Split: '◫', Look: '🎞', Flash: '✦', Burst: '💥'};
const DOES = {TypedText: 'המילים נכתבות אות אחרי אות', CallToAction: 'כפתור עם חץ, למשל "שלחו הודעה"', Checklist: 'כותרת ושורה עם וי',
  CoinStack: 'מטבעות נערמים', PaperPlane: 'מטוס נייר עף מעל', Glitch: 'קריעה קצרה של התמונה', Zoom: 'כניסה מהירה לנקודה וחזרה',
  Split: 'המסך מתחלק לשניים: עכשיו ורגע אחר מהגלם', Look: 'צבע של סרט על כל הסרטון', Flash: 'הבזק לבן קצר',
  Burst: 'פיצוץ קומיקס עם צליל'};
const GRADES = {tealOrange: 'טורקיז-כתום', warm: 'חם', cool: 'קר', bw: 'שחור-לבן', faded: 'דהוי'};
const POINTED = {Zoom: ['x', 'y'], Burst: ['x', 'y'], CoinStack: ['x', 'baseY']};   // a press on the frame puts these
const SOFT = 1.25;   // a zoom closer than this looks soft in the finished video (D1)
const MAX_FX = 3;    // effects on at the same moment, not counting a look (v2 Δ2, the panel only)
const el = (tag, cls, text) => Object.assign(document.createElement(tag), {className: cls || '', textContent: text || ''});
const newId = () => `mine-${Math.random().toString(36).slice(2, 12).padEnd(10, '0')}`;

// the subtitles over a window, joined into lines of whole words, at most `n` lines of `most` letters (v3 Δ22)
export function linesOf(pages, s, e, n, most) {
  const words = pages.filter((p) => p.e > s && p.s < e).flatMap((p) => p.text.split(/\s+/).filter(Boolean));
  const lines = [''];
  for (const w of words) {
    const next = lines.at(-1) ? `${lines.at(-1)} ${w}` : w;
    if ([...next].length <= most) lines[lines.length - 1] = next;
    else if (lines.length < n && [...w].length <= most) lines.push(w);
    else break;
  }
  return lines.filter(Boolean);
}

export function addFxPanel(api) {
  const {fps, V} = api;
  let dlg = null, editing = null;

  const rules = () => api.state().addRules;
  const ctx = () => api.state();
  const layerOf = (kind) => (rules().effectKinds.includes(kind) ? 'effects' : 'graphics');
  const least = (kind) => rules().lookMin[kind] ?? rules().minFrames[kind] ?? 1;
  const lengthOf = (kind, texts) => Math.max(least(kind), texts ? textFrames(texts, fps, rules().text)
    : Math.round((rules().seconds[kind] ?? 2.5) * fps));

  function close() { dlg?.close(); }

  // overlapping text: a warning and "להזיז אחרי", never a block (D2)
  function textClash(id) {
    const eff = api.eff(), g = eff.graphics.find((x) => x.id === id);
    if (!g || !rules().textKinds.includes(g.kind)) return null;
    const on = (x) => !eff.hidden.includes(x.id) && x.from < g.from + g.dur && g.from < x.from + x.dur;
    const titleEnd = Math.round(eff.titleEnd * fps);
    return [...eff.graphics.filter((x) => x.id !== id && rules().textKinds.includes(x.kind) && on(x)),
      ...(eff.hf || []).filter(on), ...(!eff.hidden.includes('title') && g.from < titleEnd ? [{label: 'הכותרת', from: 0, dur: titleEnd}] : [])][0] || null;
  }
  function warnClash(id) {
    const other = textClash(id);
    if (!other) return;
    const bar = el('span', 'clash');
    bar.append(el('span', '', `הטקסט עולה על "${other.label}". `), Object.assign(el('button', '', 'להזיז אחרי'), {type: 'button', onclick: () => {
      const a = api.man().added.find((x) => x.id === id), to = other.from + other.dur;
      if (a && to + a.durFrames <= api.frames) { a.rawFrame = rawAt(ctx().clock, to); api.commit(); }
      bar.remove();
    }}));
    api.note(bar);
  }

  // the item as it will be saved: refused here (the reason shown), never by the server
  function put(item, isNew) {
    const why = whyNot(item, rules(), ctx());
    if (why) { api.note(`לא נוסף: ${why}`); return false; }
    const added = (api.man().added ||= []);
    if (isNew && added.length >= rules().maxItems) { api.note(`אפשר עד ${rules().maxItems} תוספות בסרטון`); return false; }
    if (isNew && item.kind !== 'Look' && layerOf(item.kind) === 'effects') {
      const a = api.frameOf(item);
      const busy = api.eff().effects.filter((e) => e.kind !== 'Look' && !api.eff().hidden.includes(e.id)
        && e.from < a + item.durFrames && a < e.from + e.dur).length;
      if (busy >= MAX_FX) { api.note(`כבר יש ${MAX_FX} אפקטים ברגע הזה. יותר מזה הופך לבלגן ומאריך את ההכנה`); return false; }
    }
    if (isNew) added.push(item);
    else added[added.findIndex((x) => x.id === item.id)] = item;
    api.commit();
    if (isNew && item.kind !== 'Look') { const t = api.frameOf(item) / fps; api.seek(Math.max(0, t - 0.5)); api.play(); }
    warnClash(item.id);
    return true;
  }

  // ---- the panel
  function open(id) {
    const st = ctx();
    if (!st.clock || !st.clockMatches) return api.note(st.clock ? 'החיתוך השתנה מאז הגרסה הזו: קודם להכין סרטון או לחכות לגרסה הבאה' : 'אי אפשר להוסיף לסרטון הזה');
    editing = id ? api.man().added.find((x) => x.id === id) : null;
    api.stop();
    if (!dlg) {
      dlg = Object.assign(document.createElement('dialog'), {id: 'addFxDlg', className: 'drivedlg addfx'});
      document.body.append(dlg);
    }
    dlg.textContent = '';
    if (editing) form(editing.kind);
    else {
      dlg.append(el('h2', '', `להוסיף ב-${fmt(api.outTime())}`),
        el('p', 'hint', 'בוחרים, וזה נכנס מיד לסרטון ולציר. נעול כמו כל תיקון שלך: קלוד לא משנה אותו. אפשר לגרור, להאריך, להסתיר ולבטל (Ctrl+Z).'));
      const grid = el('div', 'fxgrid');
      Object.keys(rules().props).forEach((kind) => {   // the server's order: Burst last (D6)
        const b = Object.assign(el('button', 'fxkind'), {type: 'button', onclick: () => form(kind)});
        b.append(el('i', '', ICON[kind] || '✦'), el('b', '', st.labels[kind] || kind), el('span', '', DOES[kind] || ''));
        grid.append(b);
      });
      dlg.append(grid, closeRow());
    }
    if (!dlg.open) dlg.showModal();
  }
  const closeRow = (...more) => {
    const row = el('div', 'upload-row');
    row.append(...more, Object.assign(el('button', '', 'סגירה'), {type: 'button', onclick: close}));
    return row;
  };

  function form(kind) {
    const st = ctx(), spec = rules().props[kind], label = st.labels[kind] || kind;
    const now = Math.round(api.outTime() * fps);
    const p = editing ? structuredClone(editing.props) : structuredClone(rules().defaults[kind] || {});
    dlg.textContent = '';
    dlg.append(el('h2', '', editing ? `לשנות: ${label}` : `${label} ב-${fmt(now / fps)}`), el('p', 'hint', DOES[kind] || ''));
    let texts = null;
    if (spec.texts) {   // text: from what is said there (not a button), up to two lines (v3 Δ22)
      const [, n, most] = spec.texts;
      const filled = editing ? p.texts : kind === 'CallToAction' ? [] : linesOf(api.eff().pages, now / fps, (now + lengthOf(kind, ['x'.repeat(20)])) / fps, n, most);
      texts = Array.from({length: n}, (_, k) => Object.assign(document.createElement('input'),
        {value: filled[k] || '', maxLength: most, placeholder: k ? 'שורה שנייה (לא חובה)' : kind === 'CallToAction' ? 'מה כתוב על הכפתור' : 'הטקסט'}));
      dlg.append(el('p', 'hint', `עד ${most} אותיות בשורה${kind === 'CallToAction' ? '. הכפתור מתמלא רק ממה שכותבים כאן' : ''}`), ...texts);
    }
    if (POINTED[kind]) {   // where: a press on the frame, held inside what the rules allow
      const [kx, ky] = POINTED[kind], box = el('div', 'fxframe'), dot = el('i', 'dot');
      const img = Object.assign(document.createElement('img'), {alt: 'הפריים ברגע הזה', src: `/media/${V}/frame.jpg?t=${(now / fps).toFixed(2)}`});
      img.onerror = () => { box.hidden = true; };
      const norm = kind === 'Zoom';   // 0..1, else pixels of 1080x1920
      const show = () => { dot.style.left = `${(norm ? p[kx] : p[kx] / 1080) * 100}%`; dot.style.top = `${(norm ? p[ky] : p[ky] / 1920) * 100}%`; };
      box.onclick = (e) => {
        const r = box.getBoundingClientRect(), fx = (e.clientX - r.left) / r.width, fy = (e.clientY - r.top) / r.height;
        const clamp = (k, v) => Math.min(spec[k][2], Math.max(spec[k][1], v));
        p[kx] = clamp(kx, norm ? +fx.toFixed(3) : Math.round(fx * 1080));
        p[ky] = clamp(ky, norm ? +fy.toFixed(3) : Math.round(fy * 1920));
        show();
      };
      box.append(img, dot);
      show();
      dlg.append(el('p', 'hint', kind === 'Zoom' ? 'לוחצים על הנקודה שאליה נכנסים' : 'לוחצים איפה לשים. אי אפשר במקום שאינסטגרם מכסה'), box);
    }
    if (kind === 'Zoom') {
      const row = Object.assign(document.createElement('label'), {className: 'vol'});
      row.innerHTML = '<span>כמה קרוב</span><input type="range" step="0.05"><output></output>';
      const input = row.querySelector('input'), out = row.querySelector('output'), soft = el('p', 'hint warn', 'מעל 1.25 הסרטון הסופי ייראה רך יותר');
      Object.assign(input, {min: spec.scale[1], max: spec.scale[2], value: p.scale});
      const show = () => { p.scale = +input.value; out.textContent = `×${p.scale.toFixed(2)}`; soft.hidden = p.scale <= SOFT; };
      input.oninput = show;
      show();
      dlg.append(row, soft);
    }
    if (kind === 'Split') {   // the other half: a moment of the raw that is not in the cut, when there is one
      const dur = editing?.durFrames ?? lengthOf(kind), most = (st.rawFrames - dur) / fps;
      if (!p.b) {
        const inCut = (f) => st.clock.some(([a, b]) => a <= f && f < b);
        const out = Array.from({length: st.rawFrames - dur}, (_, f) => f).find((f) => !inCut(f));
        p.b = {source: 'raw', t: +((out ?? Math.min(rawAt(st.clock, now) + 5 * fps, st.rawFrames - dur)) / fps).toFixed(2)};
      }
      const row = Object.assign(document.createElement('label'), {className: 'vol'});
      row.innerHTML = '<span>רגע מהגלם</span><input type="range" step="0.1" min="0"><output></output>';
      const input = row.querySelector('input'), out = row.querySelector('output');
      Object.assign(input, {max: Math.max(0, most).toFixed(1), value: p.b.t});
      const show = () => { p.b.t = +input.value; out.textContent = fmt(p.b.t); };
      input.oninput = show;
      show();
      dlg.append(row);
    }
    let replace = null;
    if (kind === 'Look') {
      const sel = document.createElement('select');
      Object.entries(GRADES).forEach(([k, t]) => sel.append(new Option(t, k)));
      sel.value = p.grade;
      sel.onchange = () => { p.grade = sel.value; };
      const row = Object.assign(document.createElement('label'), {className: 'vol'});
      row.append(el('span', '', 'צבע'), sel);
      const eff = api.eff();
      replace = editing ? null : eff.effects.find((e) => e.kind === 'Look' && !eff.hidden.includes(e.id)) || null;
      dlg.append(row, el('p', 'hint', `${replace ? 'יש כבר מראה בסרטון: הוא יוסתר וזה יבוא במקומו. ' : ''}על כל הסרטון. ההכנה של הסרטון תהיה ארוכה יותר, כי כל הסרטון עובר דרכו.`));
    }
    const go = Object.assign(el('button', 'primary', editing ? 'שמירה' : replace ? 'להחליף' : 'להוסיף'), {type: 'button'});
    go.onclick = () => {
      const props = {...p};
      if (texts) {
        props.texts = texts.map((t) => t.value.trim().replace(/\s+/g, ' ')).filter(Boolean);
        if (!props.texts.length) return api.note('צריך לכתוב טקסט');
      }
      const layer = layerOf(kind);
      let item;
      if (editing) item = {...api.man().added.find((x) => x.id === editing.id), props};   // read now, not when opened (Δ52)
      else if (kind === 'Look') item = {id: newId(), layer, kind, whole: true, props};
      else {
        const dur = lengthOf(kind, props.texts);
        const from = Math.max(0, Math.min(now, api.frames - dur));   // near the end: it starts earlier, so it is seen whole
        item = {id: newId(), layer, kind, rawFrame: rawAt(st.clock, from), durFrames: dur, props};
      }
      if (!put(item, !editing)) return;
      if (replace) { (api.man().hidden ||= {})[replace.id] = true; api.commit(); }
      close();
    };
    dlg.append(closeRow(go));
    texts?.[0]?.focus();
  }

  return {open, close, isOpen: () => !!dlg?.open, warnClash, least};
}

const fmt = (t) => `${Math.floor(t / 60)}:${(t % 60).toFixed(1).padStart(4, '0')}`;
