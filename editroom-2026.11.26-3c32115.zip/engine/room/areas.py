"""The room's areas besides the videos (16.11): tool status, the studio's effects, inspirations + learning, analysis.

What came from the studio (claude-video-studio) is in engine/studio since stage 13.2.
"""
import datetime
import json
import logging
import re
import shutil
import subprocess
import sys
import threading
import uuid

import jobqueue
import jobs
import rounds
import rules
from rounds import now, read, write_atomic

sys.path.insert(0, str(rounds.ROOT / "engine"))
import paths  # noqa: E402
import platform_util  # noqa: E402
import tools  # noqa: E402

STUDIO = paths.APP / "engine" / "studio"   # what came from the studio (stage 13.2): its 18 effects and their demos
STUDIO_FILES = {   # what the effects page may load
    "fx-demos.js": (STUDIO / "fx-demos.js", "text/javascript"),
    "presenter-cutout.png": (STUDIO / "presenter-cutout.png", "image/png"),
}
ID_OK = re.compile(r"^[a-z0-9-]{1,40}$")

# ---- tool status: checking runs every tool once (a few seconds), so it runs in the background and is kept
_tools = {"state": "checking", "rows": []}


def _check_tools():
    rows = tools.check()
    _tools.update(state="ready", rows=[dict(name=n, ok=o, detail=d, required=r) for n, o, d, r in rows])


def tool_status():
    if _tools["state"] == "checking" and not _tools.get("started"):
        _tools["started"] = True
        threading.Thread(target=_check_tools, daemon=True).start()
    return _tools


# ---- the studio's effects (shown beside the room's own catalog)
def studio_effects():
    he = json.loads((STUDIO / "he.json").read_text(encoding="utf-8"))
    fx = json.loads((STUDIO / "effects.json").read_text(encoding="utf-8"))
    return {"effects": [{"id": e["id"], "category": e["category"], "demo": e.get("demo"),
                         "name": he.get(e["name_key"], e["id"]), "desc": he.get(e["desc_key"], "")} for e in fx],
            "strings": {k: v for k, v in he.items() if k.startswith("fx.demo.")}}


# ---- inspirations: library/inspiration/<id>/{source.mp4, meta.json, analysis/rNN/, style-card.md}
def insp_dir(iid):
    if not ID_OK.match(iid or ""):
        raise FileNotFoundError(iid)
    return jobs.insp_dir(f"insp:{iid}")


def source(d):
    """The inspiration's own video, when it has one (a .part is an upload that did not finish)."""
    return next((p for p in d.glob("source.*") if p.suffix != ".part"), None)


MEASURE_S = 5400   # how long measuring one video may take
MEASURE = lambda d: [str(paths.PYTHON), str(STUDIO / "learn_analysis.py"), str(d)]   # cuts, loudness, contact sheets, words -> d/analysis/rNN


def learn(d, entry=None):
    """One entry of the queue (the worker's thread): measure the video, then Claude writes its style card (no shell, see
    jobs.LEARN_TOOLS). The measurement counts as running like any job, with no gap before Claude's."""
    name = f"insp:{d.name}"
    job_f, prog_f, logs = jobs.files(name)
    logs.mkdir(parents=True, exist_ok=True)
    log = logs / f"{now().replace(':', '')}-analyze.log"
    write_atomic(prog_f, {"step": "המערכת מודדת את הסרטון: קצב, עוצמה ופריימים", "at": now()})
    with open(log, "wb") as out:
        p = subprocess.Popen(MEASURE(d), stdin=subprocess.DEVNULL, stdout=out, stderr=subprocess.STDOUT,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    with jobs.gate:
        jobs.running[name] = p
        jobs.measuring.add(name)
    # no entryId: a room closed while measuring has not run this entry yet (build rule 1)
    job = {"state": "running", "kind": "analyze", "started": now(), "pid": p.pid, "pidStart": platform_util.pid_start(p.pid),
           "log": log.name, "fromRound": jobs.done_count(name)}
    try:
        write_atomic(job_f, job)
        if p.wait(MEASURE_S):
            said = log.read_text(encoding="utf-8", errors="replace").strip().splitlines()
            raise RuntimeError(said[-1][:300] if said else "analysis failed")
        jobs.start(name, "learn", entry=entry)
    except (RuntimeError, OSError, subprocess.TimeoutExpired, jobs.Busy) as e:
        p.kill()   # nothing, when it ended by itself
        write_atomic(job_f, {**job, "state": "failed", "finished": now(), "error": f"המדידה נכשלה: {e}"})
        jobqueue.tell("failed", name, "learn", why=f"המדידה נכשלה: {e}")
    finally:
        with jobs.gate:
            jobs.measuring.discard(name)
            if jobs.running.get(name) is p:
                jobs.running.pop(name)


def new_inspiration(note, link):
    iid = f"{now()[:10]}-{uuid.uuid4().hex[:6]}"
    d = rounds.INSP / iid
    (d / "review").mkdir(parents=True)
    write_atomic(d / "meta.json", {"id": iid, "note": note[:600], "link": link[:500], "created": now()})
    return d


def card_lines(text):
    """The front matter of a style card as {key: line}."""
    m = re.match(r"---\n(.*?)\n---", text, re.S)
    return dict(re.findall(r"^(\w+):\s*(.+)$", m.group(1), re.M)) if m else {}


def inspiration(d):
    meta = read(d / "meta.json")
    rounds_ = sorted((d / "analysis").glob("r*/analysis.json"))
    analysis = read(rounds_[-1]) if rounds_ else None
    card = d / "style-card.md"
    name = f"insp:{d.name}"
    jobs.status(name)   # notices a job that ended while the room was closed
    seen = jobqueue.look(name)
    job, queued = seen["job"], seen["queued"]
    note = jobqueue.note(name)   # why it did not start, when its turn came
    if queued:
        state = "queued"
    elif seen["runs"] or job and job["state"] == "running":
        state = "working"
    elif card.exists():
        state = "ready"
    elif note or job and job["state"] == "failed":
        state = "failed"
    else:
        state = "saved" if source(d) else "new"
    hook = rounds_[-1].parent / "hook.jpg" if rounds_ else None
    return {**meta, "state": state, "queued": queued, "measured": (analysis or {}).get("measured"),
            "card": card_lines(card.read_text(encoding="utf-8")) if card.exists() else None,
            "hook": f"/insp/{d.name}/{hook.relative_to(d).as_posix()}" if hook and hook.exists() else None,
            "error": f"לא התחיל: {note}" if note else (job or {}).get("error")}


def inspirations():
    return [inspiration(d) for d in sorted(rounds.INSP.iterdir(), reverse=True) if (d / "meta.json").exists()] if rounds.INSP.exists() else []


# ---- stage ט (docs/learn-spec*.md): fixing one field of a style card by hand, and the graphics log, read only
FIELD_MAX = 400
FIELD_BAKS = 5   # style-card.<stamp>.bak kept beside the card; style-card.orig.md (Claude's own) is never overwritten
QUEUED = "הכרטיס מחכה בתור ללמידה. אפשר לתקן אחרי שקלוד יסיים."
LEARNING = "קלוד לומד עכשיו את ההשראה הזו. אפשר לתקן אחרי שהוא יסיים."


def fix_field(d, key, value):
    """One line of the card's front matter, under the same locks as the rules (v2 Δ11): a job that runs may read the
    card. The body gets a line that says the fix wins, the backups come first, then meta.json, then the card."""
    import media   # the engine's text writer: whole or not at all
    value = str(value or "").strip()
    if not value or len(value) > FIELD_MAX or "\n" in value or "\r" in value or "---" in value:
        raise rules.Refused(400, f"ערך בשורה אחת, עד {FIELD_MAX} תווים, בלי ---")
    name = f"insp:{d.name}"
    with jobqueue.lock:
        card = inspiration(d)   # before jobs.gate: it may finish a job that ended, which takes the gate
        with jobs.gate:
            if not jobs.owner:
                raise rules.Refused(409, jobqueue.NOT_OWNER)
            if rules.busy():
                raise rules.Refused(423, rules.BUSY)
            if card["queued"]:
                raise rules.Refused(409, QUEUED)
            if card["state"] == "working" or jobs.busy(name) or name in jobs.stopping:
                raise rules.Refused(409, LEARNING)
            f = d / "style-card.md"
            text = f.read_text(encoding="utf-8") if f.is_file() else ""
            m = re.match(r"---\n(.*?)\n---", text, re.S)
            if not isinstance(key, str) or key in ("id", "name_he") or key not in card_lines(text):
                raise rules.Refused(400, "אפשר לתקן רק שדה שכבר יש בכרטיס")
            head = re.sub(rf"^{re.escape(key)}:\s*(.+)$", lambda _: f"{key}: {value}", m.group(1), flags=re.M)
            stamp = datetime.datetime.now()
            body = text[m.end():].rstrip("\n")
            new = (f"---\n{head}\n---{body}\n\nתוקן ידנית ב-{stamp:%d.%m.%Y}: {key} = {value}. "
                   "זה גובר על מה שכתוב למעלה.\n")
            orig = d / "style-card.orig.md"
            if not orig.exists():
                shutil.copy2(f, orig)
            shutil.copy2(f, d / f"style-card.{stamp:%Y%m%d-%H%M%S-%f}.bak")
            for old in sorted(d.glob("style-card.*.bak"))[:-FIELD_BAKS]:
                old.unlink()
            meta = read(d / "meta.json")
            if meta.get("import"):   # fixed by the user: undoing the import keeps this card (as with the rules)
                meta["importKept"] = meta.pop("import")
                write_atomic(d / "meta.json", meta)
            media.write_text(f, new)
    logging.info("style card %s: %s fixed by hand", d.name, key)
    return card_lines(new)


def graphics_log():
    """library/graphics-log.json for "מה עובד אצלך": {rows}, or {error} when it is not a list of rows."""
    f = paths.GRAPHICS_LOG
    if not f.exists():
        return {"rows": []}
    try:
        data = read(f)
    except (OSError, ValueError):
        data = None
    if not isinstance(data, list) or not all(isinstance(r, dict) for r in data):
        return {"error": "קובץ הרישום לא תקין, ולכן לא מוצג."}
    return {"rows": data}


# ---- a style for a new video (stage d3): a style card the user picks, kept in brief.json as styleCard
def styles():
    """The cards a new video may take, newest first."""
    if not rounds.INSP.exists():
        return []
    found = [(d.name, rules.style_card(d.name)) for d in sorted(rounds.INSP.iterdir(), reverse=True) if d.is_dir()]
    return [{"id": sid, "name": card_lines(f.read_text(encoding="utf-8")).get("name_he") or sid} for sid, f in found if f]


# ---- analysis of one video: what the system found, from the files the pipeline already writes
def speaker_shares(sp):
    """analysis/speakers.json (engine/episode.py) -> [{name, share, camera}] for the analysis page."""
    if not sp:
        return None
    turns = sp["turns"]
    total = sum(t["e"] - t["s"] for t in turns) or 1
    rows = []
    for who in sorted({t["who"] for t in turns}, key=str):
        secs = sum(t["e"] - t["s"] for t in turns if t["who"] == who)
        both = who == "both"
        rows.append({"name": "שניהם יחד" if both else f"דובר {who + 1}",
                     "share": round(100 * secs / total),
                     "camera": "מסך מפוצל" if both else sp["cameras"][who]})
    return rows


def video_analysis(vdir):
    def j(p):
        return read(p) if p.exists() else None
    words = j(vdir / "transcript" / "words.json")
    segs = j(vdir / "takes" / "edit_segments.json")
    progress = j(vdir / "review" / "progress.json")
    report = j(vdir / "review" / "report.json")
    seg_list = segs.get("segments", segs) if isinstance(segs, dict) else (segs or [])
    kept = sum(max(0.0, float(s[1]) - float(s[0])) for s in seg_list if isinstance(s, (list, tuple)) and len(s) >= 2)
    return {"name": vdir.name,
            "words": len(words["words"]) if words else None,
            "segments": len(seg_list) or None,
            "kept_seconds": round(kept, 1) if kept else None,
            "progress": progress, "report": report,
            "speakers": speaker_shares(j(vdir / "analysis" / "speakers.json")),   # podcasts (stage 3)
            "highlights": j(vdir / "analysis" / "highlights.json"),   # proposed moments (stage 4)
            "cuts": j(vdir / "analysis" / "cuts.json"),               # proposed cuts inside an episode (4.3)
            "brief": j(vdir / "review" / "brief.json")}
