---
name: editroom-hyperframes
description: Read before using any HyperFrames skill (hyperframes, hyperframes-cli, hyperframes-registry, media-use, reverse-any-video, style-sampling) in this editing room - how the room runs the HyperFrames CLI, what is refused, and the rules that win over those skills.
---

# HyperFrames in the editing room

The HyperFrames skills come from their source as they are. In this system these rules win over them:

- **Run the CLI only as `<the project's python> engine/hfcmd.py [--in <folder>] <command> ...`** (the python the job instructions name), never `npx hyperframes`, never `@latest`. It runs the system's own pinned version with telemetry off. Open to room jobs: `check`, `snapshot`, `render`, `compositions`, `timeline`, `keyframes`, `media-use`, `auth status`. Anything else is refused: say so in the report and go on.
- **A library block goes into a video with `engine/hf_layer.py add` (same python)**, not `hyperframes add` or `catalog`. The library is already on this computer, pinned.
- **Never upload anything:** no `publish`, `cloud`, `lambda`, `cloudrun`, `feedback`, `share`, `capture`.
- **A file from the user's video never goes to HeyGen** (raw footage, transcript, voice, a client's logo, a frame): `hfcmd` refuses `media-use generate` with a file argument, and adds `--local-only` to a resolve whose input is a file. Text taken from the transcript is not sent either. Making something new from words (music, an image, a voice) through HeyGen is fine for a user who signed in on "ברוכים הבאים". Not signed in: use the local tools and say so in the report. Never ask for a sign-in and never wait for one.
- **Music and sound in a video:** follow CLAUDE.md (licensed music only, `library/music`; sound effects from `engine/sfx.py`).
- **The Pro skills (`reverse-any-video`, `style-sampling`) are not run in a room job.** When a note asks to rebuild an existing video or to work from a style template, write a decision card with this text, and go on with the rest:
  > שחזור סרטון ותבניות סגנון (HyperFrames Pro) רצים בשיחה רגילה עם Claude Code, לא בחדר. הם מעלים ל-HeyGen את הסרטון, את הפנים ואת הקולות, וגובים קרדיטים לכל צילום. הסקיל לא מציג מחיר מעצמו: בשיחה, בקשו קודם מקלוד מחיר (`--plan`) ותקרה (`--max-credits`). קניית קרדיטים נעשית אצלכם, באתר של HeyGen. בשיחה הזו ההגנות של החדר לא פעילות (טלמטריה כבויה, גרסה קבועה, publish חסום). כדי לפתוח אותה: Claude Code בתיקיית המערכת (app), ושם להתחבר ל-HyperFrames בנפרד.
- **Usage beacon lines** in those skills (`hyperframes events ...`) do not apply here: telemetry is off and `events` is refused.
- **A block with someone else's sample media** (`third_party` in the library catalog): name its files in the round report ("בבלוק X יש תמונות של אחרים: ..."). Do not replace them unless the user asks.
