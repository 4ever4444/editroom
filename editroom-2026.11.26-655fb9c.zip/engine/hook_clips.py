"""Short preview clips of opening candidates (hooks), cut from the raw, for the decision card in the room.

usage: python engine/hook_clips.py "videos/<name>" '[{"id": "h1", "s": 12.3, "e": 16.8}, ...]'
s/e = seconds in takes/source.mkv (the raw, aligned). Writes final/hooks/<id>.mp4 (540 wide, small)
and prints the paths to put in the card options as "clip": "final/hooks/<id>.mp4".
"""
import json
import sys
from pathlib import Path

from media import ffmpeg

PAD_S = 0.15     # a breath either side, so the first and last syllables are whole
MAX_S = 12.0     # a hook is a sentence, not a scene


def clip(source, s, e, out):
    s, e = max(0.0, s - PAD_S), e + PAD_S
    if not 0 < e - s <= MAX_S + 2 * PAD_S:
        raise ValueError(f"hook {out.stem}: {e - s:.1f}s; a hook is up to {MAX_S:.0f}s")
    out.parent.mkdir(parents=True, exist_ok=True)
    ffmpeg("-ss", f"{s:.3f}", "-to", f"{e:.3f}", "-i", source, "-vf", "scale=540:-2",
           "-c:v", "libx264", "-preset", "veryfast", "-crf", "26", "-c:a", "aac", "-b:a", "128k",
           "-movflags", "+faststart", out)
    return out


def main(vdir, hooks):
    vdir = Path(vdir)
    source = vdir / "takes" / "source.mkv"
    for h in hooks:
        out = clip(source, float(h["s"]), float(h["e"]), vdir / "final" / "hooks" / f"{h['id']}.mp4")
        print(f"final/hooks/{out.name}")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main(sys.argv[1], json.loads(sys.argv[2]))
