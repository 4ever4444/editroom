"""The logo at the end of a video (stage 11.6, Ron 19.11): the client's logo comes in LEAD seconds before the video
ends, the background fills in as it ends, and the video goes on AFTER seconds more on that background (black, white
or gray) while the logo keeps moving (spin, pulse, shine, zoom, neon).

The choice rides with the video's logo: graphics.json "logo" (a reel) or analysis/logo.json (an episode) gets
"end": {"bg", "fx"}; its "file" is the logo. A logo only at the end has "when": "none" (no corner logo).
The animation is room/endcard-fx.js, the same code the "◆ לוגו" window previews, rendered with HyperFrames into
takes/endcard/endcard.mov (see-through, then solid); finish() lays it over the end of the finished video and extends
it (the last frame held under the background, silence under the sound).
usage: python engine/endcard.py "videos/<name>"   (adds the end to final/final.mp4 or final/episode.mp4 as chosen)
"""
import hashlib
import json
import re
import shutil
import sys
from pathlib import Path

import logo
import paths
import tools
from media import probe, read_json

FX_JS = Path(__file__).parent / "room" / "endcard-fx.js"
FRAMES = {"reel": (1080, 1920), "episode": (1920, 1080)}


def catalog():
    """{"fx": {id: label}, "bgs": {id: label}, "lead", "after"}, read from the one file the room and the render use."""
    t = FX_JS.read_text(encoding="utf-8")
    return {"fx": dict(re.findall(r"^    (\w+): \{label: '([^']+)'", t, re.M)),
            "bgs": dict(re.findall(r"(\w+): \{label: '([^']+)', color:", t)),
            "lead": float(re.search(r"LEAD: ([\d.]+)", t).group(1)), "after": float(re.search(r"AFTER: ([\d.]+)", t).group(1))}


def check(end):
    """The "end" of a logo choice, as stored, or ValueError."""
    if end is None:
        return None
    c = catalog()
    if not isinstance(end, dict) or end.get("bg") not in c["bgs"] or end.get("fx") not in c["fx"]:
        raise ValueError(f"logo end: bg {list(c['bgs'])}, fx {list(c['fx'])}")
    return {"bg": end["bg"], "fx": end["fx"]}


PAGE = """<!doctype html>
<html><head><meta charset="UTF-8"><script src="{gsap}"></script>
<style>html,body{{margin:0;width:{W}px;height:{H}px;overflow:hidden;background:transparent}}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{d}" data-width="{W}" data-height="{H}"
     style="position:relative;width:{W}px;height:{H}px;overflow:hidden">{markup}</div>
<script>{fx_js}</script>
<script>
const tl = END_FX.stage(document, document.getElementById('root'),
  {{src: '{src}', w: {w}, h: {h}, W: {W}, H: {H}, bg: '{bg}', fx: '{fx}'}});
window.__timelines["main"] = tl; tl.seek(0);
</script></body></html>
"""


def render(vdir, choice, frame, fps):
    """takes/endcard/endcard.mov: LEAD + AFTER seconds, made again only when the logo, the end or the frame rate changed."""
    out = Path(vdir) / "takes" / "endcard"
    out.mkdir(parents=True, exist_ok=True)
    src = logo.path(choice["file"])
    end, c = choice["end"], catalog()
    W, H = FRAMES[frame]
    mov, stamp = out / "endcard.mov", out / "endcard.key"
    key = hashlib.sha1(json.dumps([choice["file"], end, frame, fps, src.stat().st_mtime_ns,
                                   FX_JS.stat().st_mtime_ns]).encode()).hexdigest()
    if mov.exists() and stamp.exists() and stamp.read_text() == key:
        return mov
    stamp.unlink(missing_ok=True)   # half of it must never be taken for ready (stage b2)
    iw, ih = logo.size(src)
    w = min(round(W * (0.56 if W < H else 0.34)), round(iw * (H * (0.28 if W < H else 0.42)) / ih))   # = END_FX.size
    h = round(ih * w / iw)
    assets = paths.HF_STAGE / "assets" / "_logo"   # the same shared stage as the corner logo (logo.fx_parts)
    assets.mkdir(parents=True, exist_ok=True)
    img = assets / f"{hashlib.sha1(src.read_bytes()).hexdigest()[:12]}{src.suffix.lower()}"
    shutil.copy2(src, img)
    js, src_web = FX_JS.read_text(encoding="utf-8"), f"assets/_logo/{img.name}"
    color = re.search(rf"{end['bg']}: {{label: '[^']+', color: '([^']+)'", js).group(1)
    markup = re.search(r"markup\(src, w, h, W, H, color\) \{\s*return `(.*?)`;", js, re.S).group(1)   # END_FX.markup
    for k, val in (("src", src_web), ("color", color), ("(W - w) / 2", (W - w) / 2), ("(H - h) / 2", (H - h) / 2),
                   ("w", w), ("h", h)):
        markup = markup.replace("${" + k + "}", str(val))
    (paths.HF_STAGE / "index.html").write_text(PAGE.format(gsap=logo.GSAP, d=c["lead"] + c["after"], W=W, H=H, w=w, h=h,
                                                      src=src_web, bg=end["bg"], fx=end["fx"], markup=markup,
                                                      fx_js=js), encoding="utf-8")
    tools.hf_render(paths.HF_STAGE, mov, fps=round(fps))
    stamp.write_text(key)
    return mov


def apply(video, mov, lead, after, out):
    """The finished video with the end laid over its last LEAD seconds and AFTER seconds added (the last frame held,
    silence) -> out. The picture is encoded once more (crf 18), the sound padded."""
    info = probe(video)
    start = max(0.0, info["duration"] - lead)
    tools._run(tools.FFMPEG, "-y", "-loglevel", "error", "-i", video, "-i", mov, "-filter_complex",
               f"[0:v]tpad=stop_mode=clone:stop_duration={after:.3f}[v];"
               f"[1:v]setpts=PTS-STARTPTS+{start:.3f}/TB[e];[v][e]overlay=eof_action=pass:format=auto,format=yuv420p[o];"
               f"[0:a]apad=pad_dur={after:.3f}[a]", "-map", "[o]", "-map", "[a]", "-r", str(info["fps"]),
               "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-c:a", "aac", "-b:a", "256k", "-ar", "48000",
               "-movflags", "+faststart", out)
    return out


def finish(vdir, video, choice, frame):
    """If the video's logo choice has an end: render it and put it on `video` in place. Returns the seconds added."""
    if not choice or not choice.get("end"):
        return 0.0
    c = catalog()
    mov = render(vdir, {**choice, "end": check(choice["end"])}, frame, float(probe(video)["fps"]))
    tmp = Path(video).with_name(Path(video).stem + "_end.mp4")
    apply(video, mov, c["lead"], c["after"], tmp)
    tmp.replace(video)
    return c["after"]


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    v = Path(sys.argv[1])
    reel = v / "final" / "final.mp4"
    if reel.exists():
        print(finish(v, reel, read_json(v / "graphics.json").get("logo"), "reel"))
    else:
        f = v / "analysis" / "logo.json"
        print(finish(v, v / "final" / "episode.mp4", read_json(f) if f.exists() else None, "episode"))
