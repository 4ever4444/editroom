"""Shared helpers: ffmpeg path, probing, audio loading, loudness envelope."""
import json
import os
import shutil
import subprocess
import threading
import time
from pathlib import Path

import av
import imageio_ffmpeg
import numpy as np
from faster_whisper import decode_audio

FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
SR = 16000
HOP = 0.01  # envelope resolution, seconds


def part_of(out):
    """Where a file is written until it is whole: beside it, with its own ending (ffmpeg goes by the ending)."""
    out = Path(out)
    return out.with_name(f"{out.stem}.part{out.suffix}")


def swap_in(tmp, out, tries=40):
    """A whole file takes its place in one step, so a stop or a power cut never leaves half of it (stage b2). Windows
    refuses while a page plays the old one: asked again for ten seconds, then written into it, as before, but never when
    that file is also somebody's snapshot (a hard link: it would change there too)."""
    tmp, out = Path(tmp), Path(out)
    for k in range(tries):
        try:
            return os.replace(tmp, out)
        except PermissionError:
            if k < tries - 1:
                time.sleep(0.25)
    try:
        if out.stat().st_nlink != 1:
            raise PermissionError(f"{out.name} is in use")
        shutil.copyfile(tmp, out)
    finally:
        tmp.unlink(missing_ok=True)


def whole(args, run):
    """run(args) with the file they end with written aside and swapped in when it is done; "-" and patterns as they are."""
    out = str(args[-1])
    if out == "-" or "%" in Path(out).name:
        return run(args)
    tmp = part_of(out)
    try:
        r = run([*args[:-1], tmp])
        if tmp.exists():
            swap_in(tmp, out)
        return r
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise


def ffmpeg(*args, capture=False):
    def run(a):
        r = subprocess.run([FFMPEG, "-hide_banner", "-y", *map(str, a)],
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode:
            raise RuntimeError(r.stderr[-3000:])
        return r.stderr if capture else None
    return whole(args, run)


def probe(path):
    with av.open(str(path)) as c:
        v, a = c.streams.video[0], c.streams.audio[0]
        return {"fps": v.average_rate, "w": v.width, "h": v.height,
                "duration": float(c.duration / av.time_base), "channels": a.channels, "rate": a.rate}


def load_audio(path):
    return decode_audio(str(path), sampling_rate=SR)


def envelope_db(audio):
    """RMS in dBFS per HOP window."""
    n = int(SR * HOP)
    frames = audio[: len(audio) // n * n].reshape(-1, n)
    return 20 * np.log10(np.sqrt((frames ** 2).mean(1)) + 1e-9)


def hiss_ratio(audio, cutoff=3500):
    """Share of energy above cutoff per HOP window: high for ס/ש/צ/ז, ~0 for vowels."""
    n = int(SR * HOP)
    frames = audio[: len(audio) // n * n].reshape(-1, n)
    p = np.abs(np.fft.rfft(frames * np.hanning(n), axis=1)) ** 2
    hi = np.fft.rfftfreq(n, 1 / SR) > cutoff
    return p[:, hi].sum(1) / (p.sum(1) + 1e-12)


def noise_floor(env):
    return float(np.percentile(env, 10))


def read_json(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def write_text(p, text):
    p = Path(p)
    tmp = p.with_name(f"{p.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.write_text(text, encoding="utf-8")
    swap_in(tmp, p)


def write_json(p, data):
    write_text(p, json.dumps(data, ensure_ascii=False, indent=1))
