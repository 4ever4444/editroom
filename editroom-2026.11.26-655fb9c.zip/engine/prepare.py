"""Raw -> takes/source.mkv: constant fps, 1080x1920, video aligned to audio t=0, audio untouched (PCM).

usage: python engine/prepare.py "videos/<name>" [fps]
fps defaults to the raw's own rate; pass one only for variable-rate phone footage.
Each output slot k/fps gets the nearest not-yet-used real frame, so no frame is ever duplicated
(ffmpeg's fps filter repeats frames across phone timing gaps). Needs raw fps >= target fps.
"""
import sys
from fractions import Fraction
from pathlib import Path

import av
import numpy as np

from media import ffmpeg, probe

DUP_DIFF = 0.05   # mean abs gray diff below this = the phone repeated a frame


def raw_frames(raw):
    """Presentation times of real frames, skipping frames the camera repeated."""
    times, prev = [], None
    with av.open(str(raw)) as c:
        for f in c.decode(video=0):
            g = f.to_ndarray(format="gray")[::4, ::4].astype(np.int16)
            if prev is None or np.abs(g - prev).mean() >= DUP_DIFF:
                times.append(f.time)
            prev = g
    return sorted(times)


def pick(times, fps):
    """For each output slot, the index of the nearest unused frame."""
    chosen, i = [], 0
    for k in range(int(times[-1] * fps) + 1):
        t = k / fps
        while i + 1 < len(times) and abs(times[i + 1] - t) <= abs(times[i] - t):
            i += 1
        chosen.append(i)
        i += 1
        if i >= len(times):
            break
    return chosen


def write_video(raw, times, chosen, fps, out):
    want = {times[i]: k for k, i in enumerate(chosen)}
    with av.open(str(raw)) as src, av.open(str(out), "w") as dst:
        vin = src.streams.video[0]
        vout = dst.add_stream("libx264", rate=fps, options={"crf": "12", "preset": "medium"})
        vout.width, vout.height, vout.pix_fmt = 1080, 1920, "yuv420p"
        g = av.filter.Graph()
        sw, sh = vin.codec_context.width, vin.codec_context.height
        if sw >= 1080 and sh >= 1920:
            # scale down until it just covers 1080x1920, then trim the excess (1088x1920 loses 8px, 4K loses nothing).
            # A plain crop used to cut a 4K raw from its centre and lose the edges.
            resize_filters = [g.add("scale", "1080:1920:force_original_aspect_ratio=increase"),
                              g.add("crop", "1080:1920")]
        else:
            resize_filters = [
                g.add("scale", "1080:1920:force_original_aspect_ratio=decrease"),
                g.add("pad", "1080:1920:(ow-iw)/2:(oh-ih)/2"),
            ]
        chain = [g.add_buffer(template=vin)] + resize_filters + [g.add("setsar", "1"), g.add("buffersink")]
        for a, b in zip(chain, chain[1:]):
            a.link_to(b)
        g.configure()
        for f in src.decode(vin):
            k = want.get(f.time)
            if k is None:
                continue
            g.push(f)
            o = g.pull()
            o.pts, o.time_base = k, Fraction(1, 1) / fps
            for p in vout.encode(o):
                dst.mux(p)
        for p in vout.encode():
            dst.mux(p)


def main(video_dir, fps=None):
    video_dir = Path(video_dir)
    raw = next((video_dir / "raw").glob("*.mp4"))
    info = probe(raw)
    fps = Fraction(fps or info["fps"])
    times = raw_frames(raw)
    chosen = pick(times, fps)
    assert len(set(chosen)) == len(chosen)
    # the first ~second catches up with the camera's start delay; never usable footage anyway
    err = max(abs(times[i] - k / fps) for k, i in enumerate(chosen) if k / fps > times[0] + 1)

    tmp = video_dir / "takes" / "source_video.mkv"
    out = video_dir / "takes" / "source.mkv"
    write_video(raw, times, chosen, fps, tmp)
    ffmpeg("-i", tmp, "-i", raw, "-map", "0:v", "-map", "1:a:0", "-c:v", "copy", "-c:a", "pcm_s16le", out)
    tmp.unlink()
    print(f"{raw.name}: {info['w']}x{info['h']} -> 1080x1920 @ {fps} fps, {len(chosen)} frames "
          f"(of {len(times)} real), max timing error {err * 1000:.0f}ms, {info['channels']}ch audio -> {out}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
