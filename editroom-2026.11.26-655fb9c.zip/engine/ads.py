"""An ad in several versions (stage 11.5): the same reel with a different opening, title and call to action in each,
so an A/B test says which works. Each version is its own video, edited by Claude from the same raw.

usage: python engine/ads.py "videos/<name>" [n]   -> videos/<name> · מודעה A, B, C (n = 2-4, default 3)

The openings and titles come from the reel's own decision cards (stage 4.1, review/round-N.json): version A keeps
what the reel has now, B and C take the next options in Claude's order. Only those three things differ, so the
test measures them; the brief tells the edit exactly which (first.md, "An ad version").
"""
import json
import sys
from pathlib import Path

import cutdown
from media import read_json, write_json

LETTERS = "ABCD"
CTA = {"A": "same", "B": "short", "C": "question", "D": "benefit"}   # how the on-screen call to action is worded


def cards(vdir):
    """{"hook": [(id, label)], "title": [(id, [lines])], "chosen": {card: id}} from the reel's latest round."""
    rounds = sorted(Path(vdir, "review").glob("round-*.json"), key=lambda p: int(p.stem.split("-")[1]))
    out = {"hook": [], "title": [], "chosen": {}}
    for f in reversed(rounds):
        decisions = read_json(f).get("decisions") or []
        if any(c["id"] in ("hook", "title") for c in decisions):
            for c in decisions:
                if c["id"] in ("hook", "title"):
                    opts = [(o["id"], o["label"]) for o in c["options"]]
                    out[c["id"]] = opts if c["id"] == "hook" else [(i, [x.strip() for x in lb.split("/")]) for i, lb in opts]
                    out["chosen"][c["id"]] = c.get("choice") or c.get("recommended")
            break
    return out


def ordered(options, chosen):
    """The chosen option first, then the rest in Claude's order."""
    return sorted(options, key=lambda o: o[0] != chosen)


def plan(vdir, n=3):
    """[{"variant", "hook", "title", "cta"}]: one per version, as many as the reel has openings for (at most n)."""
    c = cards(vdir)
    hooks, titles = ordered(c["hook"], c["chosen"].get("hook")), ordered(c["title"], c["chosen"].get("title"))
    if len(hooks) < 2:
        raise ValueError("לריל הזה אין מספיק פתיחות שקלוד הציע (צריך לפחות שתיים), ולכן אין ממה לבנות גרסאות למודעה")
    g = Path(vdir) / "graphics.json"
    title_now = read_json(g).get("title") if g.exists() else None
    out = []
    for i in range(min(n, len(hooks), len(LETTERS))):
        title = titles[i][1] if i < len(titles) else (title_now or [])
        if i == 0 and title_now:
            title = title_now   # version A is the reel as it is
        out.append({"variant": LETTERS[i], "hook": hooks[i][1], "title": title, "cta": CTA[LETTERS[i]]})
    return out


def make(vdir, n=3):
    """The versions as new videos, each with a brief that names its opening, title and call to action."""
    vdir = Path(vdir)
    if versions(vdir):
        raise FileExistsError("לריל הזה כבר יש גרסאות מודעה")
    made = []
    for v in plan(vdir, n):
        new = cutdown.new_from(vdir, f"מודעה {v['variant']}")
        write_json(new / "review" / "brief.json", {
            "type": "reel", "cutdown_of": vdir.name, "ad": {"of": vdir.name, **v},
            "note": f"גרסה {v['variant']} של מודעה מתוך הריל \"{vdir.name}\" (first.md, An ad version): הפתיחה, הכותרת "
                    "והקריאה לפעולה כמו בבריף, וכל השאר כמו בריל. התמלול כבר קיים ב-transcript, אין צורך לתמלל שוב."})
        made.append(new)
    return made


def versions(vdir):
    """The ad versions made from this reel: [(variant, video folder, its brief's "ad")], in letter order."""
    vdir = Path(vdir)
    out = []
    for p in vdir.parent.glob(f"{vdir.name} · מודעה *"):
        b = p / "review" / "brief.json"
        ad = read_json(b).get("ad") if b.exists() else None
        if ad and ad.get("of") == vdir.name:
            out.append((ad["variant"], p, ad))
    return sorted(out, key=lambda x: x[0])


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for p in make(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 3):
        print(p, json.dumps(read_json(p / "review" / "brief.json")["ad"], ensure_ascii=False))
