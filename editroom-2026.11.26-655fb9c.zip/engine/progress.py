"""Claude's progress line for the editing room.

usage: python engine/progress.py "videos/<name>" "מתמלל את הגלם" [3/10]
"""
import datetime
import json
import os
import sys
from pathlib import Path

video, step = Path(sys.argv[1]), sys.argv[2]
out = video / "review" / "progress.json"
out.parent.mkdir(parents=True, exist_ok=True)
tmp = out.with_suffix(".tmp")
tmp.write_text(json.dumps({"step": step, "n": sys.argv[3] if len(sys.argv) > 3 else None,
                           "at": datetime.datetime.now().isoformat(timespec="seconds")}, ensure_ascii=False),
               encoding="utf-8")
os.replace(tmp, out)
