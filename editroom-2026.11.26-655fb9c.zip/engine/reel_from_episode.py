"""A moment of a podcast episode -> a new reel video whose raw is that moment, vertical, cut by speaker.

usage: python engine/reel_from_episode.py "videos/<episode>" <from_s> <to_s> "<new name>"
from/to are seconds on the episode (as in transcript/words.json and analysis/highlights.json).
Needs episode.py to have run (analysis/sync.json, analysis/shots.json). The new video
videos/<new name>/raw/clip.mp4 (1080x1920) then goes through the reel machine like any raw.
"""
import sys
from pathlib import Path

import episode
import reframe
from media import read_json, write_json

REEL = {"size": (1080, 1920), "enc": ["-c:v", "libx264", "-preset", "medium", "-crf", "16"]}
PAD_S = 0.5   # a little air either side, the reel machine trims it


def main(vdir, a, b, name, note="", kind="reel", length=None):
    vdir = Path(vdir)
    new = vdir.parent / name
    if new.exists():
        sys.exit(f"כבר יש סרטון בשם \"{name}\"")
    sync = read_json(vdir / "analysis/sync.json")
    shots = read_json(vdir / "analysis/shots.json")
    total = sync["end"] - sync["start"]
    a, b = max(0.0, a - PAD_S), min(total, b + PAD_S)
    cams, mics = episode.sources(vdir)
    for sub in ("raw", "transcript", "takes", "final", "review"):
        (new / sub).mkdir(parents=True)
    t0 = sync["start"]
    work = new / "takes" / "clip.mp4"   # rendered aside, so the room never sees half a raw
    # 5.5: each camera's crop follows where its person sits in this moment, not the frame's centre
    focus = [reframe.focus(c, t0 + a - r["offset"], t0 + b - r["offset"]) for c, r in zip(cams, sync["files"])]
    episode.render(new, cams, mics, sync["files"], t0 + a, t0 + b, episode.clip_shots(shots, a, b), work, **REEL,
                   focus=focus)
    work.rename(new / "raw" / "clip.mp4")
    write_json(new / "review" / "brief.json", {"type": kind, "note": note, "from_episode": vdir.name, "focus": focus,
                                              "episode_from": round(a, 2), "episode_to": round(b, 2),
                                              **({"length": length} if length else {})})   # a story: 6-15 s
    print(f"reel raw {b - a:.1f}s -> {new / 'raw' / 'clip.mp4'}")
    return new


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main(sys.argv[1], float(sys.argv[2]), float(sys.argv[3]), sys.argv[4])
