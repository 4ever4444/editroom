"""Cover frame candidates: sharp moments without speech.

usage: python engine/cover.py "videos/<name>"
writes final/cover_candidates/<seconds>.png (the room shows them as a decision card) and prints the times
"""
import sys
from pathlib import Path

import av
import numpy as np

from media import ffmpeg, read_json

COUNT = 8
MIN_APART_S = 4.0
QUIET_GAP_S = 0.6     # gap between words long enough to be "not speaking"
FACE = (slice(350, 1150), slice(240, 840))   # rows, cols of the 1080x1920 frame where the face/torso sits


def sharpness(gray):
    g = gray.astype(np.float32)
    lap = g[1:-1, 1:-1] * 4 - g[:-2, 1:-1] - g[2:, 1:-1] - g[1:-1, :-2] - g[1:-1, 2:]
    return float(lap.var())


def silent(words, t):
    for a, b in zip(words, words[1:]):
        if a["e"] + 0.2 <= t <= b["s"] - 0.2 and b["s"] - a["e"] >= QUIET_GAP_S:
            return True
    return t < words[0]["s"] - 0.2 or t > words[-1]["e"] + 0.2


def main(video_dir):
    video_dir = Path(video_dir)
    words = read_json(video_dir / "transcript" / "words.json")["words"]
    src = video_dir / "takes" / "source.mkv"
    scored = []
    with av.open(str(src)) as c:
        for i, f in enumerate(c.decode(video=0)):
            if i % 6 or f.time < 1.0 or not silent(words, f.time):   # every 0.2s, skip camera start
                continue
            scored.append((sharpness(f.to_ndarray(format="gray")[FACE]), f.time))
    picks = []
    for s, t in sorted(scored, reverse=True):
        if all(abs(t - p) >= MIN_APART_S for p in picks):
            picks.append(t)
        if len(picks) == COUNT:
            break
    picks.sort()

    out = video_dir / "final" / "cover_candidates"
    out.mkdir(parents=True, exist_ok=True)
    for t in picks:
        ffmpeg("-ss", f"{t:.3f}", "-i", src, "-frames:v", "1", out / f"{t:07.2f}.png")
    print("candidates:", ", ".join(f"{t:.2f}" for t in picks))


if __name__ == "__main__":
    main(sys.argv[1])
