"""Cut approved takes from takes/source.mkv by loudness, frame-exact.

usage: python engine/cut.py "videos/<name>"
reads  takes/takes.json, transcript/words.json
writes takes/edit.mkv (video + cleaned, -14 LUFS audio), takes/edit_words.json (whisper on the cut = subtitle
timing), takes/edit_segments.json
"""
import json
import math
import re
import sys
from pathlib import Path

import numpy as np

from media import HOP, envelope_db, ffmpeg, hiss_ratio, load_audio, noise_floor, probe, read_json, write_json
from transcribe import run_whisper

SPEECH_DB = 12       # above noise floor = speech
BREATH_DB = 6        # between this and SPEECH_DB, outside words = breath / mouth noise
PAD_S = 0.05         # silence kept each side of a cut -> ~0.1s at the join
SEARCH_S = 0.35      # how far around whisper's word time to look for the real boundary
MAX_PAUSE_S = 0.6    # longer pauses inside a take get shortened ...
KEEP_PAUSE_S = 0.3   # ... to this
HISS = 0.25          # hiss_ratio above this = inside ס/ש/צ/ז
SIBILANT = set("סשצץז")
SIBILANT_LOOK = 30   # x HOP: how far past a cut a word's missing ס may still be
LISTEN_DB = 10       # a cut this loud over the floor has no real silence: flag it for a human ear
FADE_S = 0.005
BREATH_GAIN_DB = -12
LUFS = -14


def idx(t):
    return max(0, int(round(t / HOP)))


def runs(mask):
    """[(start_idx, end_idx)] of True runs."""
    d = np.diff(np.concatenate([[0], mask.astype(int), [0]]))
    return list(zip(np.nonzero(d == 1)[0], np.nonzero(d == -1)[0]))


def snap(env, cut, lo, hi, fps):
    """Frame boundary next to cut: inside [lo, hi] if possible, else the quieter of the two."""
    cands = [math.floor(cut * fps) / fps, math.ceil(cut * fps) / fps]
    inside = [c for c in cands if lo - 1e-9 <= c <= hi + 1e-9]
    if inside:
        return min(inside, key=lambda c: abs(c - cut))
    return min(cands, key=lambda c: env[min(idx(c), len(env) - 1)])


def keep_sibilant(hiss, cut, word, fps, end):
    """ס/ש/צ/ז are quiet, so loudness alone can cut them off. If the word ends (starts) with one and there is
    no hiss just inside the cut, the hiss hasn't happened yet: move the cut past the next (previous) hiss run."""
    letter = word.strip(",.?!:;")[-1 if end else 0]
    i = idx(cut)
    inside = hiss[max(0, i - 5):i] if end else hiss[i:i + 5]
    if letter not in SIBILANT or (inside > HISS).any():
        return cut
    step = 1 if end else -1
    j = next((k for k in range(i, i + step * SIBILANT_LOOK, step) if hiss[k] > HISS), None)
    if j is None:
        return cut
    while hiss[j + (0 if end else -1)] > HISS:
        j += step
    frame = j * HOP * fps
    # nearest frame; a tie goes to the side that keeps the hiss whole
    return (math.floor(frame + 0.5 + 1e-6) if end else math.ceil(frame - 0.5 - 1e-6)) / fps


def refine_start(env, hiss, thr, soft, t, prev_end, word, fps):
    """Cut point before `word` at t: quietest spot after the previous word, then back off from the onset."""
    a, b = idx(max(t - SEARCH_S, prev_end - 0.05)), idx(t + 0.15)
    q = a + int(np.argmin(env[a:b]))
    onset = q + int(np.nonzero(env[q:] > thr)[0][0])
    while onset - 1 > q and env[onset - 1] > soft:   # soft attack ('א', 'ה') belongs to the word
        onset -= 1
    cut = snap(env, max(q, onset - PAD_S / HOP) * HOP, q * HOP, onset * HOP, fps)
    return keep_sibilant(hiss, cut, word, fps, end=False)


def refine_end(env, hiss, thr, soft, t, next_start, word, fps):
    """Cut point after `word` ending at t: quietest spot before the next word, after the word's tail."""
    a, b = idx(t - 0.15), idx(min(t + SEARCH_S, next_start + 0.05))
    q = a + int(np.argmin(env[a:b]))
    offset = int(np.nonzero(env[:q + 1] > thr)[0][-1]) + 1
    while offset < q and env[offset] > soft:         # soft tail ('ף', 'ח', 'ם') belongs to the word
        offset += 1
    cut = snap(env, min(q, offset + PAD_S / HOP) * HOP, offset * HOP, q * HOP, fps)
    return keep_sibilant(hiss, cut, word, fps, end=True)


def word_overlap(words, a, b):
    """True if some word lies mostly inside [a, b]."""
    return any(min(b, w["e"]) - max(a, w["s"]) > 0.5 * (w["e"] - w["s"]) for w in words)


def in_seg(w, s, e):
    """Whisper stretches words into neighbouring silence, so membership = real overlap, not midpoint."""
    return min(e, w["e"]) - max(s, w["s"]) > 0.05


def split_pauses(env, thr, s, e, words, fps):
    """Shorten silent runs > MAX_PAUSE_S inside [s, e]; returns sub-segments."""
    segs, cur = [], s
    for a, b in runs(env[idx(s):idx(e)] < thr):
        a, b = s + a * HOP, s + b * HOP
        if b - a > MAX_PAUSE_S and not word_overlap(words, a, b):
            cut_a = round((a + KEEP_PAUSE_S / 2) * fps) / fps
            cut_b = round((b - KEEP_PAUSE_S / 2) * fps) / fps
            segs.append((cur, cut_a))
            cur = cut_b
    return segs + [(cur, e)]


def plan(video_dir):
    video_dir = Path(video_dir)
    src = video_dir / "takes" / "source.mkv"
    fps = float(probe(src)["fps"])
    audio = load_audio(src)
    env, hiss = envelope_db(audio), hiss_ratio(audio)
    floor = noise_floor(env)
    thr = floor + SPEECH_DB
    tr = read_json(video_dir / "transcript" / "words.json")["words"]
    cfg = read_json(video_dir / "takes" / "takes.json")

    soft = floor + BREATH_DB
    exact = cfg.get("exact", [])   # hand-checked cut times where whisper's word timing is wrong
    segs, listen = [], []
    for t0, t1, _ in cfg["takes"]:
        prev_end = max([w["e"] for w in tr if w["e"] <= t0 + 0.01] or [0.0])
        next_start = min([w["s"] for w in tr if w["s"] >= t1 - 0.01] or [len(env) * HOP])
        first = min(tr, key=lambda w: abs(w["s"] - t0))["w"]
        last = min(tr, key=lambda w: abs(w["e"] - t1))["w"]
        s = round(t0 * fps) / fps if t0 in exact else refine_start(env, hiss, thr, soft, t0, prev_end, first, fps)
        e = round(t1 * fps) / fps if t1 in exact else refine_end(env, hiss, thr, soft, t1, next_start, last, fps)
        listen += [t for t in (s, e) if t in exact or env[idx(t) - 2:idx(t) + 2].max() - floor > LISTEN_DB]
        inside = [w for w in tr if in_seg(w, s, e)]
        segs += split_pauses(env, thr, s, e, inside, fps)

    # breaths, mapped onto the output timeline
    breaths, pos = [], 0.0
    for s, e in segs:
        for a, b in runs((env[idx(s):idx(e)] > floor + BREATH_DB) & (env[idx(s):idx(e)] < thr)):
            a, b = s + a * HOP, s + b * HOP
            if b - a >= 0.15 and not any(w["s"] < b and w["e"] > a for w in tr):
                breaths.append((round(pos + a - s, 3), round(pos + b - s, 3)))
        pos += e - s
    return src, fps, floor, env, segs, breaths, listen


def render(src, fps, segs, breaths, out):
    info = probe(src)
    sr, channels = info["rate"], info["channels"]
    spf = sr / fps
    parts, labels = [], ""
    for i, (s, e) in enumerate(segs):
        fs, fe = round(s * fps), round(e * fps)
        dur = (fe - fs) / fps
        parts.append(f"[0:v]trim=start_frame={fs}:end_frame={fe},setpts=PTS-STARTPTS[v{i}]")
        parts.append(f"[0:a]atrim=start_sample={round(fs * spf)}:end_sample={round(fe * spf)},asetpts=PTS-STARTPTS,"
                     f"afade=t=in:d={FADE_S},afade=t=out:st={dur - FADE_S:.4f}:d={FADE_S}[a{i}]")
        labels += f"[v{i}][a{i}]"
    duck = "".join(f",volume={BREATH_GAIN_DB}dB:enable='between(t,{a},{b})'" for a, b in breaths)
    mono = ",pan=stereo|c0=c0|c1=c0" if channels == 1 else ""   # no +3dB boost
    parts.append(f"{labels}concat=n={len(segs)}:v=1:a=1[v][ac]")
    parts.append(f"[ac]afftdn=nr=8:nf=-50{duck}{mono}[a]")
    tmp = out.with_name("edit_prenorm.mkv")
    ffmpeg("-i", src, "-filter_complex", ";".join(parts), "-map", "[v]", "-map", "[a]",
           "-c:v", "libx264", "-crf", "12", "-preset", "medium", "-pix_fmt", "yuv420p", "-r", fps,
           "-c:a", "pcm_s16le", tmp)

    # loudnorm, two passes
    log = ffmpeg("-i", tmp, "-vn", "-af", f"loudnorm=I={LUFS}:TP=-1:LRA=11:print_format=json", "-f", "null", "-",
                 capture=True)
    m = json.loads(re.findall(r"\{[^{}]*\}", log)[-1])
    ln = (f"loudnorm=I={LUFS}:TP=-1:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:"
          f"measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:"
          f"linear=true,aresample=48000")
    ffmpeg("-i", tmp, "-af", ln, "-c:v", "copy", "-c:a", "pcm_s24le", out)
    tmp.unlink()
    return m


def main(video_dir):
    video_dir = Path(video_dir)
    src, fps, floor, env, segs, breaths, listen = plan(video_dir)
    out = video_dir / "takes" / "edit.mkv"
    m = render(src, fps, segs, breaths, out)
    # subtitle timing comes from the cut itself, not from mapping raw times through the cuts
    write_json(video_dir / "takes" / "edit_words.json", {"words": run_whisper(load_audio(out))})
    write_json(video_dir / "takes" / "edit_segments.json", {"segments": segs, "breaths": breaths})
    print(f"{len(segs)} segments, {sum(e - s for s, e in segs):.2f}s, {len(breaths)} breaths ducked, "
          f"input {m['input_i']} LUFS")
    pos = 0.0
    for s, e in segs:
        mark = lambda t: "  <- no silence here, LISTEN" if t in listen else ""
        print(f"  {s:8.3f}{mark(s)}")
        print(f"  {e:8.3f}{mark(e)}   (ends at {pos + e - s:.2f}s in the cut)")
        pos += e - s


if __name__ == "__main__":
    main(sys.argv[1])
