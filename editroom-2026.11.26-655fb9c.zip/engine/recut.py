"""Render the final episode again after Ron accepted or declined cuts on the episodes page (stage 4.3).

usage: python engine/recut.py "videos/<name>"
No Claude involved: the cuts are already decided in analysis/cuts.json. Runs the final render, its checks,
and the subtitles, reporting each step the way Claude's jobs do (engine/progress.py).
"""
import subprocess
import sys
from pathlib import Path

import episode
import transcribe_long

ENGINE = Path(__file__).parent


def step(vdir, text, n):
    subprocess.run([sys.executable, str(ENGINE / "progress.py"), str(vdir), text, f"{n}/3"], check=True)


def main(vdir):
    vdir = Path(vdir)
    step(vdir, "מרנדר את הפרק עם החיתוכים שבחרת", 1)
    episode.main(vdir)
    step(vdir, "בודק את הפרק", 2)
    ok = episode.check(vdir)
    step(vdir, "מעדכן את הכתוביות לפי החיתוכים", 3)
    transcribe_long.main(vdir)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main(sys.argv[1])
