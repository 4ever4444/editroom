"""Videos made from a finished long video (stage 11.3), cut from final/episode.mp4 without Claude:

usage: python engine/pieces.py "videos/<name>" qa | lessons | best
  qa       analysis/qa.json {"s", "e", "why"}            -> final/qa.mp4 + qa.srt: the audience questions on their own
  lessons  analysis/lessons.json [{"title", "s", "e", "summary"}]
                                                         -> final/lessons/01 - <title>.mp4 + .srt each, lessons.txt
  best     analysis/highlights.json (the strongest moments, up to BEST_SECONDS, in the talk's order)
                                                         -> final/best_of.mp4 + best_of.srt
Times in those files are on the preview, like every analysis file; they are carried to the final episode through
analysis/final_parts.json (the trim and the cuts that went). A lesson gets an opening title only when a title was
chosen for the episode (analysis/title.json from the room): the same look, with the lesson's name and number.
"""
import re
import subprocess
import sys
from pathlib import Path

import title
import tools
from media import probe, read_json, whole, write_text

BEST_SECONDS = 600   # "the best moments" of a long stream: about ten minutes
FADE = 0.3           # between moments of the best-of, so a jump in time reads as one
NAME_BAD = re.compile(r'[\\/:*?"<>|]')


def span(parts, a, b):
    """Preview seconds a..b -> (from, to) on the final episode: the kept time before each, so a range that crosses a
    cut stays one piece (the cut is already gone from episode.mp4)."""
    def pos(t):
        return sum(min(max(t - s, 0), e - s) for s, e in parts)
    return round(pos(a), 3), round(pos(b), 3)


def cues(srt_text):
    out = []
    for block in srt_text.strip().split("\n\n"):
        lines = block.splitlines()
        m = re.match(r"(\d+):(\d+):(\d+),(\d+) --> (\d+):(\d+):(\d+),(\d+)", lines[1]) if len(lines) > 2 else None
        if m:
            v = list(map(int, m.groups()))
            out.append((v[0] * 3600 + v[1] * 60 + v[2] + v[3] / 1000, v[4] * 3600 + v[5] * 60 + v[6] + v[7] / 1000,
                        "\n".join(lines[2:])))
    return out


def stamp(t):
    ms = round(t * 1000)
    return f"{ms // 3600000:02}:{ms // 60000 % 60:02}:{ms // 1000 % 60:02},{ms % 1000:03}"


def srt_for(vdir, spans):
    """The episode's subtitles inside these spans, on the new video's clock (the spans played one after another)."""
    f = Path(vdir) / "final" / "episode.srt"
    if not f.exists():
        return ""
    out, at = [], 0.0
    for a, b in spans:
        for s, e, text in cues(f.read_text(encoding="utf-8")):
            if e > a and s < b:
                out.append((at + max(s, a) - a, at + min(e, b) - a, text))
        at += b - a
    return "".join(f"{i}\n{stamp(s)} --> {stamp(e)}\n{t}\n\n" for i, (s, e, t) in enumerate(out, 1))


def cut(vdir, spans, out, fades=False, title_mov=None):
    """The spans of final/episode.mp4 played one after another -> out (1920x1080, the episode's sound level kept)."""
    src = Path(vdir) / "final" / "episode.mp4"
    graph, ins = [], ""
    for i, (a, b) in enumerate(spans):
        d = b - a
        fv = f",fade=in:d={FADE},fade=out:st={d - FADE:.3f}:d={FADE}" if fades and d > 3 * FADE else ""
        fa = f",afade=in:d={FADE},afade=out:st={d - FADE:.3f}:d={FADE}" if fades and d > 3 * FADE else \
            f",afade=in:d=0.02,afade=out:st={d - 0.02:.3f}:d=0.02"   # no click at a join
        graph.append(f"[0:v]trim={a:.3f}:{b:.3f},setpts=PTS-STARTPTS{fv}[v{i}];"
                     f"[0:a]atrim={a:.3f}:{b:.3f},asetpts=PTS-STARTPTS{fa}[a{i}]")
        ins += f"[v{i}][a{i}]"
    graph.append(f"{ins}concat=n={len(spans)}:v=1:a=1[v][a]")
    inputs, vout = ["-i", str(src)], "v"
    if title_mov:
        more, tt, vout = title.overlay(title_mov, 1, vout)
        inputs += more
        graph.append(tt)
    out.parent.mkdir(parents=True, exist_ok=True)

    def run(a):
        r = subprocess.run([tools.FFMPEG, "-hide_banner", "-y", *map(str, a)], capture_output=True, text=True, encoding="utf-8",
                           errors="replace")
        if r.returncode:
            raise RuntimeError(r.stderr[-2000:])
    whole([*inputs, "-filter_complex", ";".join(graph),
           "-map", f"[{vout}]", "-map", "[a]", "-r", str(probe(src)["fps"]), "-fps_mode", "cfr",
           "-c:v", "libx264", "-preset", "medium", "-crf", "18",
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-movflags", "+faststart", out], run)
    write_text(out.with_suffix(".srt"), srt_for(vdir, spans))
    return out


def parts_of(vdir):
    f = Path(vdir) / "analysis" / "final_parts.json"
    if not f.exists() or not (Path(vdir) / "final" / "episode.mp4").exists():
        sys.exit("לסרטון הזה עוד אין גרסה מרונדרת. קודם עריכה, ואז אפשר להוציא ממנו סרטונים")
    return read_json(f)


def qa(vdir):
    q = read_json(Path(vdir) / "analysis" / "qa.json")
    a, b = span(parts_of(vdir), q["s"], q["e"])
    if b - a < 1:
        sys.exit("חלק השאלות נחתך מהסרטון. כדי להוציא אותו לבד, מבטלים את החיתוך שלו ומרנדרים מחדש")
    return [cut(vdir, [(a, b)], Path(vdir) / "final" / "qa.mp4")]


def lessons(vdir):
    vdir = Path(vdir)
    parts, items = parts_of(vdir), read_json(vdir / "analysis" / "lessons.json")
    look = title.chosen(vdir)
    fps = float(probe(vdir / "final" / "episode.mp4")["fps"])
    folder = vdir / "final" / "lessons"
    made, text = [], []
    for n, it in enumerate(items, 1):
        name = f"{n:02} - {' '.join(NAME_BAD.sub(' ', it['title']).split())[:60]}"
        mov = None
        if look:   # the episode's chosen title look, with this lesson's name and number
            mov = title.layer(vdir, title.check({**look, "lines": [it["title"][:title.MAX_CHARS], f"שיעור {n}"]}), fps)
        made.append(cut(vdir, [span(parts, it["s"], it["e"])], folder / f"{name}.mp4", title_mov=mov))
        text.append(f"{name}\n{it.get('summary', '').strip()}\n")
    write_text(folder / "lessons.txt", "\n".join(text))
    keep = {"lessons.txt", *(p.name for m in made for p in (m, m.with_suffix(".srt")))}
    for old in folder.iterdir():   # this run's lessons only; the ones before go when all the new ones are in place (b2)
        if old.name not in keep:
            old.unlink()
    return made


def best(vdir):
    vdir = Path(vdir)
    parts = parts_of(vdir)
    picked, total = [], 0.0
    for h in sorted(read_json(vdir / "analysis" / "highlights.json"), key=lambda h: -h.get("score", 0)):
        a, b = span(parts, h["start"], h["end"])
        if b - a >= 3 and total + b - a <= BEST_SECONDS and not any(a < y and b > x for x, y in picked):
            picked.append((a, b))
            total += b - a
    if not picked:
        sys.exit("אין רגעים חזקים בסרטון הזה (analysis/highlights.json)")
    return [cut(vdir, sorted(picked), vdir / "final" / "best_of.mp4", fades=True)]


WHAT = {"qa": (qa, "מוציא את השאלות מהקהל לסרטון נפרד"), "lessons": (lessons, "מחלק את הקורס לשיעורים"),
        "best": (best, "מחבר את הרגעים הטובים לסרטון אחד")}

if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    v, what = Path(sys.argv[1]), sys.argv[2]
    subprocess.run([sys.executable, str(Path(__file__).parent / "progress.py"), str(v), WHAT[what][1], "1/1"], check=True)
    for p in WHAT[what][0](v):
        print(p)
