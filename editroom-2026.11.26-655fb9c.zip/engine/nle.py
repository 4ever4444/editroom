"""Export for Premiere and DaVinci Resolve (stage 10, Ron 19.11): the edit as a timeline an editor can keep working on.

usage: python engine/nle.py "videos/<name>"

Writes final/nle/: <name>.xml (Final Cut Pro 7 XML, "xmeml": the one timeline file both Premiere (File > Import) and
DaVinci Resolve (File > Import > Timeline) open, with every track), <name>.srt (the subtitles, to edit or burn in
there) and media/ (the files the timeline points at: hard links where possible, so an hour of cameras takes no
space). Moving the folder to another computer: the program asks where the media is, and that is media/.

A reel: V1 the cut takes (from takes/source.mkv), V2 the picture effects, V3 the library blocks and the logo, V4 the
Overlay (title, subtitles, graphics, see-through); A1-2 the voice as recorded (the room's denoise, breath ducking
and loudness are not in it), A3-4 the graphics' sounds, A5-6 the music bed.
An episode: V1 the camera of each shot (camera 1 on the left of a split screen), V2 camera 2 on its right, V3 the
logo; one audio lane per microphone (or per camera without microphones); all on the cut clock of episode.mp4.
"""
import json
import os
import shutil
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import quote

import av

import episode
import render
from media import ffmpeg, read_json, write_json


def info(path):
    """What the timeline needs to know of a media file; a still image has a picture and no length."""
    with av.open(str(path)) as c:
        v = c.streams.video[0] if c.streams.video else None
        a = c.streams.audio[0] if c.streams.audio else None
        return {"w": v.width if v else None, "h": v.height if v else None, "fps": float(v.average_rate) if v and v.average_rate else None,
                "seconds": float(c.duration / av.time_base) if c.duration else None,
                "channels": a.channels if a else 0, "rate": a.rate if a else None}


def rate(fps):
    tb = round(fps)
    return {"timebase": tb, "ntsc": "TRUE" if abs(fps - tb) > 0.001 else "FALSE"}


def el(tag, *kids, text=None, **attrs):
    e = ET.Element(tag, {k: str(v) for k, v in attrs.items()})
    if text is not None:
        e.text = str(text)
    e.extend(k for k in kids if k is not None)
    return e


def fields(**kw):
    return [el(k, text=v) if not isinstance(v, (dict, ET.Element)) else
            (v if isinstance(v, ET.Element) else el(k, *fields(**v))) for k, v in kw.items()]


def motion(dx, crop):
    """Moves the picture dx of the frame's width (-0.25 = a quarter to the left) and crops `crop` percent off each
    side: one camera's half of a split screen, as the episode render makes it (the centre half of each camera)."""
    def fx(name, eid, params):
        return el("filter", el("effect", *fields(name=name, effectid=eid, effectcategory="motion", effecttype="motion",
                                                 mediatype="video"), *params))
    def param(pid, value):
        return el("parameter", *fields(parameterid=pid, name=pid), value)
    return [fx("Basic Motion", "basic", [param("scale", el("value", text=100)),
                                         param("center", el("value", el("horiz", text=dx), el("vert", text=0)))]),
            fx("Crop", "crop", [param(side, el("value", text=crop)) for side in ("left", "right")])]


class Timeline:
    """Clips on numbered tracks, in frames of the sequence; written as one xmeml sequence."""

    def __init__(self, name, fps, w, h):
        self.name, self.fps, self.w, self.h = name, fps, w, h
        self.video, self.audio, self.files = {}, {}, {}

    def frames(self, seconds):
        return round(seconds * self.fps)

    def video_clip(self, track, path, start, end, src_in, filters=()):
        self.video.setdefault(track, []).append((path, start, end, src_in, list(filters)))

    def audio_clip(self, lane, path, start, end, src_in):
        """lane = one sound (a mic, the music): a stereo file takes two tracks, left and right, as both programs expect."""
        self.audio.setdefault(lane, []).append((path, start, end, src_in))

    def file(self, path):
        if path in self.files:
            return el("file", id=self.files[path]["id"])
        m = info(path)
        fid = f"file-{len(self.files) + 1}"
        self.files[path] = {"id": fid, **m}
        url = "file://localhost/" + quote(path.resolve().as_posix(), safe="/:")
        media = el("media",
                   el("video", el("samplecharacteristics", *fields(width=m["w"], height=m["h"]))) if m["w"] else None,
                   el("audio", el("samplecharacteristics", *fields(depth=16, samplerate=m["rate"])),
                      el("channelcount", text=m["channels"])) if m["channels"] else None)
        length = self.frames(m["seconds"]) if m["seconds"] else 24 * 60 * 60 * round(self.fps)   # a still: any length
        return el("file", el("name", text=path.name), el("pathurl", text=url), el("rate", *fields(**rate(self.fps))),
                  el("duration", text=length), media, id=fid)

    def clipitem(self, n, path, start, end, src_in, extra=()):
        f = self.file(path)
        length = self.frames(self.files[path]["seconds"]) if self.files[path]["seconds"] else end - start + src_in
        return el("clipitem", *fields(name=path.name, enabled="TRUE", duration=length), el("rate", *fields(**rate(self.fps))),
                  *fields(start=start, end=end, **{"in": src_in, "out": src_in + end - start}), f, *extra, id=f"clipitem-{n}")

    def xml(self):
        n = 0
        vtracks = []
        for t in sorted(self.video):
            items = []
            for path, start, end, src_in, filters in self.video[t]:
                n += 1
                items.append(self.clipitem(n, path, start, end, src_in, filters))
            vtracks.append(el("track", *items))
        atracks = []
        for lane in sorted(self.audio):
            channels = max(1, min(2, max(info(p)["channels"] for p, *_ in self.audio[lane])))
            for ch in range(1, channels + 1):
                items = []
                for path, start, end, src_in in self.audio[lane]:
                    n += 1
                    src = el("sourcetrack", *fields(mediatype="audio", trackindex=ch))
                    items.append(self.clipitem(n, path, start, end, src_in, [src]))
                atracks.append(el("track", *items))
        end = max([c[2] for cs in self.video.values() for c in cs] + [c[2] for cs in self.audio.values() for c in cs])
        fmt = el("format", el("samplecharacteristics", el("rate", *fields(**rate(self.fps))),
                              *fields(width=self.w, height=self.h, pixelaspectratio="square", anamorphic="FALSE",
                                      fielddominance="none")))
        seq = el("sequence", *fields(name=self.name, duration=end), el("rate", *fields(**rate(self.fps))),
                 el("media", el("video", fmt, *vtracks),
                    el("audio", el("format", el("samplecharacteristics", *fields(depth=16, samplerate=48000))), *atracks)),
                 id="sequence-1")
        root = el("xmeml", seq, version=5)
        ET.indent(root)
        return '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n' + ET.tostring(root, encoding="unicode") + "\n"


def link(src, media, made=True):
    """src inside media/: a camera or a recording without copying when the disk allows (an hour of it), else a copy. What
    the system makes (a layer, the music bed) is always a copy: made again, it would change inside an export too (b2)."""
    dst = media / Path(src).name
    try:
        if made:
            raise OSError
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)
    return dst


def srt(pages):
    def ts(t):
        ms = round(t * 1000)
        return f"{ms // 3600000:02}:{ms // 60000 % 60:02}:{ms // 1000 % 60:02},{ms % 1000:03}"
    return "".join(f"{i}\n{ts(p['s'])} --> {ts(p['e'])}\n{p['text']}\n\n" for i, p in enumerate(pages, 1))


def reel(vdir, out, media):
    takes = vdir / "takes"
    if not (takes / "source.mkv").exists() or not (takes / "edit.mkv").exists():
        raise ValueError("קבצי העבודה של הסרטון הזה כבר נמחקו (אחרי אישור סופי), ולכן אין מה לייצא לתוכנת עריכה")
    meta, layer, props, clips, blocks, bed = render.layers(vdir)
    fps = float(meta["fps"])
    t = Timeline(vdir.name, fps, meta["w"], meta["h"])
    source = media / "source.mov"   # the picture and sound as prepared, frame-exact; mov holds the pcm sound
    ffmpeg("-i", takes / "source.mkv", "-map", "0", "-c", "copy", source)
    at = 0
    for s, e in read_json(takes / "edit_segments.json")["segments"]:   # frame-exact, as engine/cut.py cuts them
        fs, fe = round(s * fps), round(e * fps)
        t.video_clip(1, source, at, at + fe - fs, fs)
        t.audio_clip(1, source, at, at + fe - fs, fs)
        at += fe - fs
    for k, (first, clip) in enumerate(clips):
        mov = media / f"effect-{k + 1}.mov"
        shutil.move(clip, mov)
        t.video_clip(2, mov, first, first + t.frames(info(mov)["seconds"]), 0)
    for first, mov in blocks:
        mov = link(mov, media)
        t.video_clip(3, mov, first, first + t.frames(info(mov)["seconds"]), 0)
    graphics = media / "graphics.mov"
    shutil.move(layer, graphics)
    t.video_clip(4, graphics, 0, at, 0)
    if info(graphics)["channels"]:
        t.audio_clip(2, graphics, 0, at, 0)
    if bed:
        t.audio_clip(3, link(bed, media), 0, min(at, t.frames(info(bed)["seconds"])), 0)
    (out / f"{vdir.name}.srt").write_text(srt(props["pages"]), encoding="utf-8")
    return t


def podcast(vdir, out, media):
    if episode.talk.source(vdir):   # ponytail: the slide layout is not built in the timeline yet; add when asked
        raise ValueError("ייצוא לתוכנת עריכה עוד לא תומך בהרצאה עם שקפים")
    cams, mics = episode.sources(vdir)
    sync = read_json(vdir / "analysis" / "sync.json")
    off = {r["file"]: r["offset"] for r in sync["files"]}
    t0, total = sync["start"], sync["end"] - sync["start"]
    shots = read_json(vdir / "analysis" / "shots.json")
    done_at = vdir / "final" / "episode.mp4"
    if not done_at.exists():
        raise ValueError("לפרק הזה עוד אין פרק מרונדר לייצא")
    fp = vdir / "analysis" / "final_parts.json"   # the clock of this episode.mp4, written by every render since 18.11
    cuts = vdir / "analysis" / "cuts.json"
    if not fp.exists() and cuts.exists() and cuts.stat().st_mtime > done_at.stat().st_mtime:
        raise ValueError("יש חיתוכים שסימנת אחרי הרינדור האחרון של הפרק. לוחצים \"רנדור מחדש\" בדף הפרק, "
                         "ואז מייצאים: כך הקובץ לתוכנת העריכה והכתוביות יתאימו לפרק")
    parts = [tuple(x) for x in read_json(fp)] if fp.exists() else episode.keep_parts(vdir, total)
    m0 = info(cams[0])
    fps = m0["fps"]
    t = Timeline(vdir.name, fps, m0["w"], m0["h"])
    cam_files, lanes = [link(c, media, made=False) for c in cams], [link(f, media, made=False) for f in (mics or cams)]
    src_of = dict(zip(cam_files + lanes, cams + (mics or cams)))
    pieces = [(sh["cam"], max(s, sh["s"]), min(e, sh["e"])) for s, e in parts for sh in shots if sh["e"] > s and sh["s"] < e]
    if pieces and pieces[0][0] == 99:   # never open on the split screen (Ron, 17.11), as the render does
        pieces[0] = (next((c for c, *_ in pieces if c != 99), 0), *pieces[0][1:])
    done = 0.0
    for cam, s, e in pieces:
        a, b = t.frames(done), t.frames(done + e - s)
        done += e - s
        for k, f in enumerate(cam_files):
            src_in = t.frames(t0 + s - off[src_of[f].name])
            if cam == 99:
                t.video_clip(1 + k, f, a, b, src_in, motion(-0.25 if k == 0 else 0.25, 25))
            elif cam == k:
                t.video_clip(1, f, a, b, src_in)
    done = 0.0
    for s, e in parts:   # the sound cut once per part, not per shot
        a, b = t.frames(done), t.frames(done + e - s)
        done += e - s
        for k, f in enumerate(lanes):
            t.audio_clip(1 + k, f, a, b, t.frames(t0 + s - off[src_of[f].name]))
    item = episode.episode_logo(vdir, done, fps)
    if item:
        pc, at = item["parts"], item["from"]
        rest = (at + t.frames(pc["intro_s"]), at + item["dur"] - t.frames(pc["outro_s"]))
        if pc["intro"]:
            t.video_clip(3, link(pc["intro"], media), at, rest[0], 0)
        t.video_clip(3, link(pc["rest"], media), *rest, 0)
        if pc["outro"]:
            t.video_clip(3, link(pc["outro"], media), rest[1], at + item["dur"], 0)
    if (vdir / "final" / "episode.srt").exists():
        shutil.copy2(vdir / "final" / "episode.srt", out / f"{vdir.name}.srt")
    return t


def main(vdir):
    """final/nle/ for a reel or an episode; returns what final/nle/index.json says."""
    vdir = Path(vdir)
    out = vdir / "final" / "nle"
    shutil.rmtree(out, ignore_errors=True)   # ours: a new export replaces the previous one
    media = out / "media"
    media.mkdir(parents=True)
    is_episode = (vdir / "analysis" / "sync.json").exists()
    try:
        t = (podcast if is_episode else reel)(vdir, out, media)
    except BaseException:
        shutil.rmtree(out, ignore_errors=True)   # no half package left behind
        raise
    xml = out / f"{vdir.name}.xml"
    xml.write_text(t.xml(), encoding="utf-8")
    index = {"xml": xml.name, "srt": f"{vdir.name}.srt" if (out / f"{vdir.name}.srt").exists() else None,
             "kind": "episode" if is_episode else "reel", "fps": t.fps, "size": f"{t.w}x{t.h}",
             "video_tracks": len(t.video), "audio_lanes": len(t.audio), "clips": sum(map(len, t.video.values())),
             "media": sorted(p.name for p in media.iterdir())}
    write_json(out / "index.json", index)
    return index


if __name__ == "__main__":
    print(json.dumps(main(sys.argv[1]), ensure_ascii=False, indent=1))
