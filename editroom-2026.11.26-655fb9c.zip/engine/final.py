""""סרטון סופי" in the editing room (stage 12.1): the reel rendered again with Ron's own fixes, without Claude.

usage: python engine/final.py "videos/<name>"
Ron's own cut is cut first (engine/mycut.py, stage 12.2). His other fixes (review/manual.json) are already in what
render.py builds; this renders, runs the checks on the result, and brings the version Ron is looking at up to date
(the cut, its subtitles and graphics, the checks report). Each step is reported like Claude's jobs.
"""
import subprocess
import sys
from pathlib import Path

import mycut
import render
import verify
from media import probe, read_json, write_json

ENGINE = Path(__file__).parent
sys.path.insert(0, str(ENGINE / "room"))
import rounds  # noqa: E402


def step(vdir, text, n):
    subprocess.run([sys.executable, str(ENGINE / "progress.py"), str(vdir), text, f"{n}/4"], check=True)


def main(vdir):
    vdir = Path(vdir)
    if mycut.apply(vdir, lambda text: step(vdir, text, 1)):   # Ron's own cut (12.2), when he changed it
        print("cut: Ron's cut from the room")
    step(vdir, "מרנדר את הסרטון עם התיקונים שלך", 2)
    render.main(vdir)
    step(vdir, "בודק את הסרטון הסופי", 3)
    verify.main(vdir, vdir / "final" / "final.mp4")
    edit = vdir / "takes" / "edit.mkv"
    lost = render.build_props(vdir, float(probe(edit)["fps"]), render.frame_count(edit))["lost"]
    if lost:   # graphics whose phrase Ron cut out (12.2): left out of the video, named in the report
        qc = read_json(vdir / "final" / "qc.json")
        qc["rows"].append(verify.row("גרפיקה שהמשפט שלה נחתך", ", ".join(lost), None,
                                     "לא נכנסה לסרטון. כדי להחזיר: להחזיר את המשפט בחיתוך, או לבקש מקלוד בהערה"))
        write_json(vdir / "final" / "qc.json", qc)
    step(vdir, "מעדכן את החדר", 4)
    rounds.refresh(vdir)   # the version Ron is in: the new cut, its subtitles and graphics, the checks


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    try:
        main(sys.argv[1])
    except render.Stop as e:
        sys.exit(f"נעצר: {e}")
