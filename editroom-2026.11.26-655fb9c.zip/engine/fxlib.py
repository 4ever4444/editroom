"""The effects library (stage 5.1): every HyperFrames registry item, installed, checked, and given a status per network.

usage: python engine/fxlib.py install [folder]   (what is missing, from the engine's tag; Ron approved the download 18.11)
       python engine/fxlib.py check [name ...]   (preview frames + status; all items when no names)
       python engine/fxlib.py list      (one line per item: name, type, size, status per network)

fx-library/ is a HyperFrames project outside library/ (Remotion copies library/ into every bundle) and outside git
(registry code, rebuilt on any machine). fx-library/catalog.json = the registry's own list + our check results.
Telemetry and update checks are off for every call (tools._run's environment).
"""
import hashlib
import json
import shutil
import sys
import urllib.request
from pathlib import Path

import paths
import tools
import vendor

LIB = paths.FX_LIB
STATE = paths.FX_STATE
STAGE = paths.HF_CHECK_STAGE
SHIPPED = paths.APP / "install" / "fxlib-catalog.json"   # the items, their files and statuses (install/fxlib_build.py)
CLI = tools.HF_CLI
BATCH = 30
# the networks Ron publishes on first (18.11) and the frame shapes each one shows
NETWORKS = {"instagram": {"label": "אינסטגרם", "ratios": [(9, 16), (4, 5), (1, 1)]},
            "tiktok": {"label": "טיקטוק", "ratios": [(9, 16)]},
            "shorts": {"label": "יוטיוב שורטס", "ratios": [(9, 16)]},
            "youtube": {"label": "יוטיוב", "ratios": [(16, 9)]}}
# kinds of item that have no place in a talking-head reel or podcast
NOT_OURS = {"code", "developer", "mock-ui", "chat", "product-demo", "ui-props", "cursor", "map", "maps"}


TAG = "v0.9.16"   # the engine's own version (engine/hf/package-lock.json): items from the same release
REGISTRY = f"https://raw.githubusercontent.com/heygen-com/hyperframes/{TAG}/registry"   # never main (13.6)


def hf(*args, timeout=900):
    return tools._run(tools.NODE, CLI, *args, timeout=timeout)


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def tag_names():
    """{name: block|component} of every item at the tag (examples are whole projects, not ours)."""
    with urllib.request.urlopen(f"{REGISTRY}/registry.json", timeout=60) as r:
        items = json.load(r)["items"]
    return {i["name"]: i["type"].split(":")[1] for i in items if i["type"] in ("hyperframes:block", "hyperframes:component")}


def catalog():
    """The library's catalog (shipped with it), with this computer's own checks over it (FX_STATE: the same folder
    on Ron's computer, data/fxlib-state on an installed one, kept when the library version changes)."""
    cat = {}
    for p in dict.fromkeys([LIB / "catalog.json", STATE / "catalog.json"]):
        if p.exists():
            for name, c in json.loads(p.read_text(encoding="utf-8")).items():
                cat.setdefault(name, {}).update(c)
    return cat


def save(cat):
    STATE.mkdir(parents=True, exist_ok=True)
    (STATE / "catalog.json").write_text(json.dumps(cat, ensure_ascii=False, indent=1), encoding="utf-8")


def item_files(name, cat=None, seen=None):
    """Every library file an item needs: its own (registry files list, 13.6 G1: the composition and what it loads,
    lib/ and assets/) and those of the items it depends on."""
    cat = cat if cat is not None else catalog()
    seen = seen if seen is not None else set()
    if name in seen:
        return []
    seen.add(name)
    item = cat.get(name, {})
    out = list(item.get("files") or [f"compositions/{name}.html"])
    for dep in item.get("deps", []):
        out += item_files(dep, cat, seen)
    return out


def stage_item(name, stage):
    """An item's files onto a render stage, as the library lays them out. Ron's stage is the library itself."""
    stage = Path(stage)
    if stage.resolve() == LIB.resolve():
        return
    for t in item_files(name):
        src, out = LIB / t, stage / t
        if src.is_file() and not (out.is_file() and out.stat().st_size == src.stat().st_size):
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, out)


def installed(lib=None):
    f = Path(lib or LIB) / "hyperframes.json"
    return {i["name"] for i in json.loads(f.read_text(encoding="utf-8")).get("registryItems", [])} if f.exists() else set()


def init(lib):
    """An empty HyperFrames project whose registry is the tag (hyperframes.json -> registry, read by `add`)."""
    lib = Path(lib)
    if not (lib / "hyperframes.json").exists():
        hf("init", lib, "--example", "blank", "--non-interactive", "--skip-skills")
    cfg = json.loads((lib / "hyperframes.json").read_text(encoding="utf-8"))
    cfg["registry"] = REGISTRY
    (lib / "hyperframes.json").write_text(json.dumps(cfg, indent=2), encoding="utf-8")


def install(lib=None, names=None):
    """Every item not there yet, from the tag (never the online catalog, which reads main). names: the shipped
    catalog's (install/fxlib-catalog.json) by default."""
    lib = Path(lib or LIB)
    init(lib)
    names = names or json.loads(SHIPPED.read_text(encoding="utf-8"))
    todo = sorted(set(names) - installed(lib))
    failed = {}
    for k in range(0, len(todo), BATCH):
        batch = todo[k:k + BATCH]
        try:
            hf("add", *batch, "--dir", lib, "--json", "--no-clipboard")
        except RuntimeError:   # one bad item must not stop the rest: try them one by one
            for n in batch:
                try:
                    hf("add", n, "--dir", lib, "--json", "--no-clipboard")
                except RuntimeError as e:
                    failed[n] = str(e)[-300:]
        print(f"installed {min(k + BATCH, len(todo))}/{len(todo)}", flush=True)
    if failed:
        raise RuntimeError(f"{len(failed)} items did not install: {', '.join(sorted(failed)[:5])}")
    return len(installed(lib))


def shape(item):
    d = item.get("dimensions") or {}
    w, h = d.get("width"), d.get("height")
    return (w, h) if w and h else None


def statuses(item, rendered):
    """Per network: ready (its frame shape fits as it is), adapt (works, other shape or needs a look in Hebrew),
    not-ours (a kind of item our videos have no use for), broken (it did not render)."""
    if not rendered:
        return {n: "broken" for n in NETWORKS}
    if NOT_OURS & set(item.get("tags", [])):
        return {n: "not-ours" for n in NETWORKS}
    s = shape(item)
    out = {}
    for n, spec in NETWORKS.items():
        fits = s and any(abs(s[0] * b - s[1] * a) < 2 * max(a, b) for a, b in spec["ratios"])
        out[n] = "ready" if fits else "adapt"
    return out


HOST = """<!doctype html>
<html lang="he"><head><meta charset="UTF-8" /><meta name="viewport" content="width={w}, height={h}" />
<script src="/vendor/gsap.min.js"></script>
<style>*{{margin:0;padding:0;box-sizing:border-box}}html,body{{width:{w}px;height:{h}px;overflow:hidden;background:#3a3a44}}</style>
</head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{d}" data-width="{w}" data-height="{h}">
{mount}
</div>
<script>const tl = gsap.timeline({{paused: true}}); window.__timelines["main"] = tl; tl.seek(0);</script>
</body></html>
"""


def check(name):
    """Mount one block alone on a grey stage of its own size, take 3 stills (a quarter in, the middle, near the end)
    into fx-library/previews/<name>/, and set its status per network. A block that does not render is "broken"."""
    cat = catalog()
    c = cat[name]
    item = c["registry"]
    w, h = shape(item) or (1080, 1920)
    d = float(item.get("duration") or 5)
    out = STATE / "previews" / name
    shutil.rmtree(out, ignore_errors=True)
    if item["type"] != "block":   # a component is a snippet for a scene, not a scene: its preview needs a host scene
        c.update(rendered=None, status={n: "adapt" for n in NETWORKS} if not NOT_OURS & set(item.get("tags", []))
                 else {n: "not-ours" for n in NETWORKS})
        save(cat)
        return c
    mount = (f'<div data-composition-id="{name}" data-composition-src="compositions/{name}.html" data-start="0" '
             f'data-duration="{d}" data-width="{w}" data-height="{h}"></div>')
    if not (STAGE / "hyperframes.json").exists():
        init(STAGE)
    stage_item(name, STAGE)
    (STAGE / "index.html").write_text(HOST.format(w=w, h=h, d=d, mount=mount), encoding="utf-8")
    vendor.into(STAGE)
    at = ",".join(f"{d * f:.2f}" for f in (0.25, 0.5, 0.85))
    try:
        hf("snapshot", STAGE, "--at", at, "--no-end", "--output", out, "--timeout", "60000", timeout=300)
        for png in out.glob("*.png"):   # small JPEGs for the page: 448 items x 3 stills at full size is far too heavy
            tools._run(tools.FFMPEG, "-y", "-loglevel", "error", "-i", png, "-vf", "scale=480:-2", "-q:v", "4",
                       png.with_suffix(".jpg"))
            png.unlink()
        (out / "contact-sheet.jpg").unlink(missing_ok=True)
        stills = sorted(p.name for p in out.glob("frame-*.jpg"))
    except RuntimeError as e:
        stills, c["error"] = [], str(e)[-400:]
    c.update(rendered=bool(stills), stills=stills, status=statuses(item, bool(stills)))
    if stills:
        c.pop("error", None)
    save(cat)
    return c


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    cmd = sys.argv[1]
    if cmd == "install":   # [folder]: the installer's own (13.6), else this computer's library
        print(install(sys.argv[2] if len(sys.argv) > 2 else None), "items")
    elif cmd == "check":
        names = sys.argv[2:] or sorted(installed())
        for k, n in enumerate(names, 1):
            r = check(n)
            print(f"{k}/{len(names)} {n}: {'ok' if r.get('rendered') else r.get('rendered')} {r.get('status')}", flush=True)
    elif cmd == "list":
        for name, c in sorted(catalog().items()):
            r = c.get("registry", {})
            print(name, r.get("type"), shape(r), c.get("status"))
