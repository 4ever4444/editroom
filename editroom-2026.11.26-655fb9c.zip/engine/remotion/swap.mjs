// node swap.mjs <new> <old>: a whole file takes the old one's place in one step (stage b2). Windows refuses while a page
// is loading the old one: asked again for a few seconds.
import {renameSync} from 'node:fs';
const [from, to] = process.argv.slice(2);
for (let k = 0; ; k++) {
  try { renameSync(from, to); break; } catch (e) {
    if (k === 20) throw e;
    await new Promise((r) => setTimeout(r, 250));
  }
}
