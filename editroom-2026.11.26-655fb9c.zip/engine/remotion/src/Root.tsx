import {Composition, Still} from 'remotion';
import {Overlay, OverlayProps} from './Overlay';
import {Cover, CoverProps} from './Cover';
import {EpisodeTitle, EpisodeTitleProps, Thumb} from './EpisodeTitle';
import {EffectsLayer, EffectsLayerProps} from './effects/EffectsLayer';

export const Root: React.FC = () => (
  <>
    <Composition
      id="Overlay"
      component={Overlay}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={1}
      defaultProps={{fps: 30, durationInFrames: 1, pages: [], title: [''], titleEnd: 0} as OverlayProps}
      calculateMetadata={({props}) => ({fps: props.fps, durationInFrames: props.durationInFrames})}
    />
    <Composition
      id="Effects"
      component={EffectsLayer}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={1}
      defaultProps={{fps: 30, durationInFrames: 1, video: '', effects: [], hidden: []} as EffectsLayerProps}
      // render.py renders this only over the frames where effects act (--frames=a-b), never the whole video
      calculateMetadata={({props}) => ({fps: props.fps ?? 30, durationInFrames: props.durationInFrames ?? 1})}
    />
    <Composition
      id="EpisodeTitle"
      component={EpisodeTitle}
      width={1920}
      height={1080}
      fps={25}
      durationInFrames={1}
      defaultProps={{lines: [''], fps: 25, durationInFrames: 1} as EpisodeTitleProps}
      calculateMetadata={({props}) => ({fps: props.fps, durationInFrames: props.durationInFrames})}
    />
    <Still id="Thumb" component={Thumb} width={1280} height={720} defaultProps={{lines: ['']}} />
    <Still id="Cover" component={Cover} width={1080} height={1920} defaultProps={{lines: ['', ''], variant: 1} as CoverProps} />
  </>
);
