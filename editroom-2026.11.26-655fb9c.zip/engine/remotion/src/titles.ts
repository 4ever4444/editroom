// Stage 11.1 (Ron 19.11: "as many effects and fonts as possible"): what an episode's opening title can look like.
// The one catalog: Remotion renders it, the room's title window shows it live, engine/title.py checks a choice
// against it (by reading this file: keep one entry per line, `  id: {label: '...'`).
import {continueRender, delayRender, staticFile} from 'remotion';

// Hebrew fonts in library/fonts (Google Fonts, OFL; each with its -OFL.txt). heavy/light = the weights used for the
// big lines and for the small last line (a single-weight font uses its own).
export const TITLE_FONTS: Record<string, {label: string; file: string; heavy: number; light: number}> = {
  heebo: {label: 'חיבו · נקי וחזק (ברירת המחדל)', file: 'Heebo-Variable.ttf', heavy: 900, light: 600},
  rubik: {label: 'רוביק · מודרני ועגלגל', file: 'Rubik-Variable.ttf', heavy: 900, light: 500},
  assistant: {label: 'אסיסטנט · עסקי ומאוזן', file: 'Assistant-Variable.ttf', heavy: 800, light: 600},
  secular: {label: 'סקולר · כותרת עבה', file: 'SecularOne-Regular.ttf', heavy: 400, light: 400},
  suez: {label: 'סואץ · סריף דרמטי', file: 'SuezOne-Regular.ttf', heavy: 400, light: 400},
  frank: {label: 'פרנק רוהל · עיתון קלאסי', file: 'FrankRuhlLibre-Variable.ttf', heavy: 900, light: 500},
  notoserif: {label: 'נוטו סריף · ספרותי', file: 'NotoSerifHebrew-Variable.ttf', heavy: 900, light: 500},
  david: {label: 'דוד · מסורתי', file: 'DavidLibre-Bold.ttf', heavy: 700, light: 700},
  bellefair: {label: 'בלפייר · אלגנטי ודק', file: 'Bellefair-Regular.ttf', heavy: 400, light: 400},
  plex: {label: 'IBM פלקס · טכנולוגי', file: 'IBMPlexSansHebrew-Bold.ttf', heavy: 700, light: 700},
  miriam: {label: 'מרים · גיאומטרי', file: 'MiriamLibre-Variable.ttf', heavy: 700, light: 400},
  alef: {label: 'אלף · פשוט וקריא', file: 'Alef-Bold.ttf', heavy: 700, light: 700},
  varela: {label: 'ורלה · רך ועגול', file: 'VarelaRound-Regular.ttf', heavy: 400, light: 400},
  fredoka: {label: 'פרדוקה · שובב', file: 'Fredoka-Variable.ttf', heavy: 700, light: 500},
  playpen: {label: 'פלייפן · כתב יד', file: 'PlaypenSansHebrew-Variable.ttf', heavy: 800, light: 500},
  amatic: {label: 'אמטיק · כתב יד צר', file: 'AmaticSC-Bold.ttf', heavy: 700, light: 700},
  karantina: {label: 'קרנטינה · פוסטר צר', file: 'Karantina-Bold.ttf', heavy: 700, light: 700},
};

// big = the headline lines, small = the last line, glow = the neon effect's light
export const TITLE_COLORS: Record<string, {label: string; big: string; small: string; glow: string}> = {
  gold: {label: 'זהב ולבן (הסגנון שלך)', big: '#FFC83D', small: '#ffffff', glow: '#FFC83D'},
  white: {label: 'לבן נקי', big: '#ffffff', small: '#e8e8e8', glow: '#ffffff'},
  ember: {label: 'כתום ולבן', big: '#ff6b2c', small: '#ffffff', glow: '#ff6b2c'},
  sky: {label: 'תכלת ולבן', big: '#5ec8ff', small: '#ffffff', glow: '#5ec8ff'},
  mint: {label: 'ירוק מנטה ולבן', big: '#5cf2b0', small: '#ffffff', glow: '#5cf2b0'},
  pink: {label: 'ורוד ולבן', big: '#ff5fa2', small: '#ffffff', glow: '#ff5fa2'},
  red: {label: 'אדום ולבן', big: '#ff3b3b', small: '#ffffff', glow: '#ff3b3b'},
  black: {label: 'שחור על תווית (עם רקע "תווית")', big: '#111111', small: '#111111', glow: '#ffffff'},
  custom: {label: 'צבעים משלך', big: '#FFC83D', small: '#ffffff', glow: '#FFC83D'},
};

export const TITLE_EFFECTS: Record<string, {label: string}> = {
  fade: {label: 'הופעה רכה'},
  typewriter: {label: 'מכונת כתיבה'},
  words: {label: 'מילה אחרי מילה'},
  rise: {label: 'מילים עולות מהקו'},
  slide: {label: 'החלקה מהצד'},
  zoom: {label: 'זום חזק'},
  blur: {label: 'מטושטש לחד'},
  tracking: {label: 'קולנועי: אותיות מתקרבות'},
  glitch: {label: 'גליטש'},
  neon: {label: 'ניאון מהבהב'},
  shine: {label: 'ברק אור שעובר'},
  scramble: {label: 'פענוח אותיות'},
  draw: {label: 'קו מתאר ואז מילוי'},
  wipe: {label: 'חשיפה'},
  curtain: {label: 'וילון מהאמצע'},
  bar: {label: 'פס צבע שעובר'},
  bounce: {label: 'אותיות קופצות'},
  wave: {label: 'גל'},
  elastic: {label: 'גומי נמתח'},
  slam: {label: 'מילים נוחתות בחבטה'},
  drop: {label: 'נופל ורועד'},
  swing: {label: 'מתנדנד מלמעלה'},
  longshadow: {label: 'צל ארוך'},
  flip: {label: 'היפוך תלת מימד'},
  extrude3d: {label: 'תלת מימד: אותיות עם עומק'},
  spin3d: {label: 'תלת מימד: סיבוב'},
  cube: {label: 'תלת מימד: קובייה מתגלגלת'},
  depth: {label: 'תלת מימד: מגיע מהעומק'},
  letters3d: {label: 'תלת מימד: אות אחרי אות מסתובבת'},
  tilt: {label: 'תלת מימד: נוטה ומתיישר'},
};

// the headline's fill: its colour (solid), or a gradient through the letters
export const TITLE_FILLS: Record<string, {label: string; css?: string}> = {
  solid: {label: 'צבע אחיד'},
  goldmetal: {label: 'זהב מתכתי', css: 'linear-gradient(180deg, #fff3b0 0%, #ffd54a 35%, #c98a12 60%, #ffe28a 100%)'},
  chrome: {label: 'כרום', css: 'linear-gradient(180deg, #ffffff 0%, #c9d1d9 40%, #5d6670 55%, #e9eef2 100%)'},
  sunset: {label: 'שקיעה', css: 'linear-gradient(90deg, #ff4e50 0%, #ff8a3d 50%, #ffd23f 100%)'},
  ocean: {label: 'אוקיינוס', css: 'linear-gradient(90deg, #00c6ff 0%, #0072ff 100%)'},
  neonfill: {label: 'ניאון ורוד-תכלת', css: 'linear-gradient(90deg, #ff2fd1 0%, #7a5cff 50%, #2af4ff 100%)'},
  fire: {label: 'אש', css: 'linear-gradient(180deg, #fff2a8 0%, #ffb300 40%, #ff3d00 100%)'},
  emerald: {label: 'אמרלד', css: 'linear-gradient(180deg, #b6ffdf 0%, #2ee59d 50%, #0b8f5a 100%)'},
  rose: {label: 'זהב ורוד', css: 'linear-gradient(180deg, #ffe1d6 0%, #f7a8a0 50%, #c96d6a 100%)'},
};

export const TITLE_STROKES: Record<string, {label: string; px?: number}> = {
  none: {label: 'בלי קו מתאר'},
  thin: {label: 'קו מתאר דק', px: 3},
  thick: {label: 'קו מתאר עבה', px: 8},
};

// a darker shade of a colour (the depth of 3D letters, the long shadow)
export const shade = (hex: string, k = 0.45) => {
  const n = parseInt(hex.replace('#', ''), 16);
  const c = [n >> 16, (n >> 8) & 255, n & 255].map((v) => Math.round(v * k));
  return `rgb(${c.join(',')})`;
};

export const TITLE_PLACES: Record<string, {label: string}> = {
  bottom: {label: 'למטה'},
  center: {label: 'באמצע'},
  top: {label: 'למעלה'},
};

export const TITLE_BACKS: Record<string, {label: string}> = {
  band: {label: 'פס כהה רך'},
  box: {label: 'תווית מאחורי כל שורה'},
  none: {label: 'בלי רקע, רק צל'},
};

const loaded = new Set<string>();
// a font is loaded once, before the frame is drawn (the render waits for it)
export const loadFont = (id: string) => {
  const f = TITLE_FONTS[id] ?? TITLE_FONTS.heebo;
  const family = `title-${id}`;
  if (!loaded.has(id)) {
    loaded.add(id);
    const handle = delayRender(`font ${id}`);
    new FontFace(family, `url('${staticFile(`fonts/${f.file}`)}') format('truetype')`, {weight: '100 900'}).load()
      .then((face) => { document.fonts.add(face); continueRender(handle); })
      .catch(() => continueRender(handle));
  }
  return {family, ...f};
};
