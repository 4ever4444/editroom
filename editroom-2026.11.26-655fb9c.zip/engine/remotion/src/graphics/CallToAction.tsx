// "Leave your details" button that pops in, with an arrow bouncing toward the caption area below.
// Stays above y=1580 (Instagram covers the bottom).
import {AbsoluteFill, interpolate} from 'remotion';
import {FONT} from '../style';
import {BLUE, Sfx, useInOut, VIOLET} from './motion';

export type CallToActionProps = {dur: number; text: string; y?: number};

export const CallToAction: React.FC<CallToActionProps> = ({dur, text, y = 1290}) => {
  const {frame, enter, exit} = useInOut(dur);
  const bounce = Math.abs(Math.sin((frame / 30) * Math.PI * 1.6)) * 22;
  const press = interpolate(frame, [18, 21, 25], [1, 0.94, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{opacity: exit}}>
      <div style={{position: 'absolute', top: y, left: 0, right: 0, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
        <div dir="rtl" style={{fontFamily: FONT, fontSize: 62, fontWeight: 900, color: 'white', padding: '18px 56px',
          borderRadius: 999, background: `linear-gradient(135deg, ${VIOLET}, ${BLUE})`,
          boxShadow: `0 0 40px ${VIOLET}aa, 0 12px 30px rgba(0,0,0,0.45)`, transform: `scale(${enter * press})`}}>
          {text}
        </div>
        <svg width={90} height={110} viewBox="0 0 90 110" style={{marginTop: 14, transform: `translateY(${bounce}px)`, opacity: enter}}>
          <path d="M45 8 L45 78 M18 54 L45 84 L72 54" fill="none" stroke="white" strokeWidth={12} strokeLinecap="round"
            strokeLinejoin="round" style={{filter: `drop-shadow(0 0 10px ${BLUE})`}} />
        </svg>
      </div>
      <Sfx name="pop" at={0} volume={0.4} />
      <Sfx name="click" at={20} volume={0.35} />
    </AbsoluteFill>
  );
};
