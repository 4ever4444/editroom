// The graphics library: every kind a video's graphics.json "motion" list may use.
import {Burst} from './Burst';
import {CallToAction} from './CallToAction';
import {Checklist} from './Checklist';
import {CoinStack} from './CoinStack';
import {PaperPlane} from './PaperPlane';
import {TypedText} from './TypedText';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const GRAPHICS: Record<string, React.FC<any>> = {CoinStack, PaperPlane, TypedText, Checklist, CallToAction, Burst};

export type Graphic = {id: string; kind: string; from: number; dur: number; props: Record<string, unknown>; hidden?: boolean};
