// Comic-book explosion: white flash, jagged orange starburst, sparks flying out, smoke that drifts away.
// Clipped below Instagram's top bar so a big burst near the top can never reach the covered area.
import {AbsoluteFill, interpolate, random, spring, useVideoConfig} from 'remotion';
import {Sfx, useInOut} from './motion';

export type BurstProps = {dur: number; x?: number; y?: number; r?: number};

const SAFE_TOP = 252;
const SPIKES = 14;

const star = (r: number, inner: number, seed: string) =>
  Array.from({length: SPIKES * 2}, (_, k) => {
    const a = (k / (SPIKES * 2)) * Math.PI * 2;
    const len = (k % 2 ? inner : r) * (0.85 + 0.3 * random(`${seed}${k}`));
    return `${Math.cos(a) * len},${Math.sin(a) * len}`;
  }).join(' ');

export const Burst: React.FC<BurstProps> = ({dur, x = 540, y = 400, r = 140}) => {
  const {frame, exit} = useInOut(dur, 12);
  const {fps} = useVideoConfig();
  const pop = spring({frame, fps, config: {damping: 8, mass: 0.5}});
  const flash = interpolate(frame, [0, 2, 7], [0, 1, 0], {extrapolateRight: 'clamp'});
  const fly = interpolate(frame, [0, 14], [0, 1], {extrapolateRight: 'clamp'});
  const smoke = interpolate(frame, [6, dur], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{opacity: exit}}>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920">
        <defs>
          <clipPath id="burstSafe"><rect x={0} y={SAFE_TOP} width={1080} height={1920 - SAFE_TOP} /></clipPath>
          <radialGradient id="burstFill">
            <stop offset="0%" stopColor="#FFF8D2" />
            <stop offset="45%" stopColor="#FFC83D" />
            <stop offset="100%" stopColor="#FF5A1F" />
          </radialGradient>
        </defs>
        <g clipPath="url(#burstSafe)">
          <g transform={`translate(${x} ${y})`}>
            {[0, 1, 2, 3, 4].map((k) => {   // smoke puffs drifting outward as the blast fades
              const a = (k / 5) * Math.PI * 2 + 0.6;
              return <circle key={k} cx={Math.cos(a) * r * (0.5 + smoke * 0.5)} cy={Math.sin(a) * r * (0.4 + smoke * 0.4) - smoke * 30}
                r={r * (0.25 + smoke * 0.35)} fill="#9CA3AF" opacity={0.55 * smoke * (1 - smoke * 0.6)} />;
            })}
            <g transform={`scale(${pop * (1 + smoke * 0.15)}) rotate(${frame * 0.6})`} opacity={1 - smoke * 0.7}>
              <polygon points={star(r, r * 0.55, 'outer')} fill="url(#burstFill)" stroke="#B91C1C" strokeWidth={6} strokeLinejoin="round" />
              <polygon points={star(r * 0.55, r * 0.32, 'inner')} fill="#FFF3B0" />
            </g>
            {Array.from({length: 12}, (_, k) => {   // sparks
              const a = (k / 12) * Math.PI * 2 + random(`spark${k}`) * 0.4;
              const r0 = r * (0.6 + fly * 0.7), r1 = r0 + r * 0.25 * (1 - fly);
              return <line key={k} x1={Math.cos(a) * r0} y1={Math.sin(a) * r0} x2={Math.cos(a) * r1} y2={Math.sin(a) * r1}
                stroke="#FFE08A" strokeWidth={7} strokeLinecap="round" opacity={1 - fly} />;
            })}
            <circle r={r * 1.1} fill="white" opacity={flash * 0.9} />
          </g>
        </g>
      </svg>
      <Sfx name="boom" at={0} volume={0.45} />
    </AbsoluteFill>
  );
};
