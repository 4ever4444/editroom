// Phrases typed letter by letter above the speaker, with a few sheets of paper drifting around them.
import {AbsoluteFill, interpolate} from 'remotion';
import {FONT} from '../style';
import {Sfx, SfxName, useInOut, VIOLET} from './motion';

export type TypedTextProps = {dur: number; lines: {text: string; at: number}[]; y?: number};

const PER_CHAR = 2;   // frames per letter
const KEYS: SfxName[] = ['key1', 'key2', 'key3'];

const Sheet: React.FC<{x: number; y: number; r: number; o: number}> = ({x, y, r, o}) => (
  <g transform={`translate(${x} ${y}) rotate(${r})`} opacity={o}>
    <rect x={-46} y={-60} width={92} height={120} rx={6} fill="#F8FAFF" />
    {[0, 1, 2, 3, 4].map((k) => <rect key={k} x={-32} y={-42 + k * 20} width={k === 4 ? 36 : 64} height={6} rx={3} fill="#A9B6D3" />)}
  </g>
);

export const TypedText: React.FC<TypedTextProps> = ({dur, lines, y = 340}) => {
  const {frame, enter, exit} = useInOut(dur);
  const drift = (k: number) => interpolate(frame, [0, dur], [0, 1]) * (k % 2 ? -40 : 40);
  return (
    <AbsoluteFill style={{opacity: exit}}>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute'}}>
        <Sheet x={120} y={y + 60 + drift(1)} r={-14 + frame * 0.2} o={0.85 * enter} />
        <Sheet x={950} y={y + 10 + drift(2)} r={12 - frame * 0.15} o={0.85 * enter} />
        <Sheet x={880} y={y + 200 + drift(3)} r={-6 + frame * 0.1} o={0.6 * enter} />
      </svg>
      <div dir="rtl" style={{position: 'absolute', top: y, left: 160, right: 160, textAlign: 'center', fontFamily: FONT}}>
        {lines.map((l, i) => {
          const shown = Math.max(0, Math.min(l.text.length, Math.floor((frame - l.at) / PER_CHAR)));
          const typing = frame >= l.at && shown < l.text.length;
          const done = i === lines.length - 1 && shown === l.text.length;
          return (
            <div key={i} style={{fontSize: 76, fontWeight: 800, color: 'white', lineHeight: 1.25, minHeight: 95,
              textShadow: `0 0 26px ${VIOLET}, 0 4px 14px rgba(0,0,0,0.7)`}}>
              {l.text.slice(0, shown)}
              {(typing || (done && Math.floor(frame / 8) % 2 === 0)) && <span style={{color: VIOLET}}>|</span>}
            </div>
          );
        })}
      </div>
      {lines.flatMap((l, i) =>
        [...l.text].map((ch, k) => (ch === ' ' ? null : <Sfx key={`${i}-${k}`} name={KEYS[k % 3]} at={l.at + k * PER_CHAR} volume={0.22} />)),
      )}
    </AbsoluteFill>
  );
};
