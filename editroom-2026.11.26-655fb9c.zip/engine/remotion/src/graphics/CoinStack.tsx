// Gold coins drop one by one and stack up beside the speaker ("the biggest asset").
import {AbsoluteFill, interpolate, spring, useVideoConfig} from 'remotion';
import {Sfx, useInOut} from './motion';

const TOP = 330;   // coin centre where the drop starts: clear of the covered top 250px

export type CoinStackProps = {dur: number; x?: number; baseY?: number; count?: number; scale?: number};

const Coin: React.FC<{cx: number; cy: number; scale?: number}> = ({cx, cy, scale = 1}) => (
  <g transform={`translate(${cx} ${cy}) scale(${scale})`}>
    <ellipse cx={0} cy={10} rx={92} ry={30} fill="#9A6B00" />
    <rect x={-92} y={-4} width={184} height={14} fill="#B8860B" />
    <ellipse cx={0} cy={-4} rx={92} ry={30} fill="url(#coinTop)" stroke="#FFE08A" strokeWidth={3} />
    <ellipse cx={0} cy={-4} rx={62} ry={19} fill="none" stroke="#C99A1E" strokeWidth={4} />
    <text x={0} y={7} textAnchor="middle" fontSize={30} fontWeight={900} fill="#9A6B00" fontFamily="Heebo">₪</text>
  </g>
);

export const CoinStack: React.FC<CoinStackProps> = ({dur, x = 200, baseY = 1000, count = 7, scale = 1}) => {
  const {frame, exit} = useInOut(dur);
  const {fps} = useVideoConfig();
  const every = 4;   // frames between coins
  const coins = Array.from({length: count}, (_, i) => {
    const land = spring({frame: frame - i * every, fps, config: {damping: 9, mass: 0.5}});
    const y = interpolate(land, [0, 1], [TOP, baseY - i * 24]);   // drop from just under Instagram's top bar
    return {i, y, o: Math.min(1, land * 3), shown: frame >= i * every};
  });
  const glint = interpolate(frame, [count * every + 6, count * every + 18], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{opacity: exit}}>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920">
        <defs>
          <radialGradient id="coinTop" cx="40%" cy="35%" r="70%">
            <stop offset="0%" stopColor="#FFF4C2" />
            <stop offset="55%" stopColor="#FFC83D" />
            <stop offset="100%" stopColor="#D99A0B" />
          </radialGradient>
          <filter id="coinShadow"><feDropShadow dx={0} dy={10} stdDeviation={12} floodOpacity={0.45} /></filter>
        </defs>
        <g filter="url(#coinShadow)">
          {coins.filter((c) => c.shown).map((c) => <g key={c.i} opacity={c.o}><Coin cx={x} cy={c.y} scale={scale} /></g>)}
        </g>
        <g opacity={glint * (1 - glint * 0.4)} transform={`translate(${x + 40} ${baseY - count * 24 - 30}) scale(${scale})`}>
          <path d="M0 -38 L8 -8 L38 0 L8 8 L0 38 L-8 8 L-38 0 L-8 -8 Z" fill="#FFF8D6" transform={`scale(${0.6 + glint * 0.6})`} />
        </g>
      </svg>
      {coins.map((c) => <Sfx key={c.i} name="click" at={c.i * every + 5} volume={0.18} />)}
      <Sfx name="thump" at={(count - 1) * every + 4} volume={0.4} />
      <Sfx name="sparkle" at={count * every + 6} volume={0.3} />
    </AbsoluteFill>
  );
};
