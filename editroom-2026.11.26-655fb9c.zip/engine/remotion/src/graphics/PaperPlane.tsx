// A paper plane flies over the speaker's head and out of frame ("on autopilot").
import {AbsoluteFill, Easing, interpolate} from 'remotion';
import {Sfx, useInOut} from './motion';

export type PaperPlaneProps = {dur: number; path?: [number, number][]};

// cubic bezier through 4 points
const bez = (p: [number, number][], t: number) => {
  const u = 1 - t;
  const k = [u * u * u, 3 * u * u * t, 3 * u * t * t, t * t * t];
  return [0, 1].map((d) => k.reduce((s, w, i) => s + w * p[i][d], 0)) as [number, number];
};

export const PaperPlane: React.FC<PaperPlaneProps> = ({dur, path = [[-160, 820], [260, 200], [760, 620], [1260, 300]]}) => {
  const {frame} = useInOut(dur, 1);
  const t = interpolate(frame, [0, dur], [0, 1], {easing: Easing.inOut(Easing.cubic), extrapolateRight: 'clamp'});
  const [x, y] = bez(path, t);
  const [nx, ny] = bez(path, Math.min(1, t + 0.01));
  const angle = (Math.atan2(ny - y, nx - x) * 180) / Math.PI;
  const trail = Array.from({length: 28}, (_, i) => bez(path, Math.max(0, t - i * 0.012)));
  return (
    <AbsoluteFill>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920">
        <defs><filter id="planeShadow"><feDropShadow dx={0} dy={14} stdDeviation={10} floodOpacity={0.4} /></filter></defs>
        <polyline points={trail.map((p) => p.join(',')).join(' ')} fill="none" stroke="#ffffff" strokeOpacity={0.55}
          strokeWidth={5} strokeDasharray="14 14" strokeLinecap="round" />
        <g transform={`translate(${x} ${y}) rotate(${angle}) scale(1.6)`} filter="url(#planeShadow)">
          <path d="M60 0 L-50 -34 L-28 0 Z" fill="#FFFFFF" />
          <path d="M60 0 L-28 0 L-50 30 Z" fill="#DCE6F5" />
          <path d="M60 0 L-28 0 L-36 14 Z" fill="#B7C6DE" />
        </g>
      </svg>
      <Sfx name="whoosh" at={Math.round(dur * 0.25)} volume={0.45} />
    </AbsoluteFill>
  );
};
