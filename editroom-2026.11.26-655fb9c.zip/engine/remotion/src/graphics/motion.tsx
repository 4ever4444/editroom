// Shared bits for every graphic: soft enter/exit, and short sound effects from /library/sfx.
import {createContext, useContext} from 'react';
import {Audio, interpolate, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

export const GREEN = '#34D399';
export const VIOLET = '#8B5CF6';
export const BLUE = '#60A5FA';

// 0 -> 1 on the way in (spring), 1 -> 0 over the last `out` frames.
export const useInOut = (dur: number, out = 8) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame, fps, config: {damping: 14, mass: 0.6}});
  const exit = interpolate(frame, [dur - out, dur], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return {enter, exit, frame};
};

// Length of each sound in frames at 30fps (engine/sfx.py): a sound is mounted only while it plays,
// so a burst of typing never stacks up dozens of audio tags.
const SFX_FRAMES = {whoosh: 22, click: 2, sparkle: 25, thump: 13, pop: 3, boom: 30, key1: 2, key2: 2, key3: 2,
  glitch: 11, bass: 18};
export type SfxName = keyof typeof SFX_FRAMES;

// Ron's level for the sounds of one graphic or effect (stage 12.1, review/manual.json): a factor over each sound's own
export const SfxGain = createContext(1);

// A sound at `at` frames into the graphic. Volume stays well under the voice.
export const Sfx: React.FC<{name: SfxName; at?: number; volume?: number}> = ({name, at = 0, volume = 0.35}) => {
  const gain = useContext(SfxGain);
  return (
    <Sequence from={Math.round(at)} durationInFrames={SFX_FRAMES[name] + 1} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={Math.min(1, volume * gain)} />
    </Sequence>
  );
};
