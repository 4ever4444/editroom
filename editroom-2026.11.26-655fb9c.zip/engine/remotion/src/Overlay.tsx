// Transparent layer over the cut video: motion graphics, title at the top, word subtitles at ~60% height.
// The render (Overlay alone) and the editing room (Preview = video + Overlay) use this same component.
import {AbsoluteFill, interpolate, Sequence, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {Graphic, GRAPHICS} from './graphics';
import {Sfx, SfxGain} from './graphics/motion';
import {audibleEffects, type Effect} from './effects/active';
import {EFFECTS} from './effects';
import {ACCENT, fitSize, FONT, SHADOW} from './style';

export type Page = {text: string; s: number; e: number; units: [string, boolean][]};
export type OverlayProps = {
  fps: number;
  durationInFrames: number;
  pages: Page[];
  title: string[]; // all lines but the last: big, gold. Last line: small, white.
  titleEnd: number; // seconds: end of the first sentence
  graphics?: Graphic[]; // frames, already resolved from the video's graphics.json
  hidden?: string[]; // graphic / effect ids (or 'title') switched off in the room
  effects?: Effect[]; // the picture effects; their sounds play here, with all the others
  place?: Place; // a network's safe area (stage 11.4, engine/safe.py); absent = Ron's layout
  sfxGain?: Record<string, number>; // Ron's level for the sounds of a graphic / effect, by id (stage 12.1)
  voiceDb?: number; // Ron's voice level (stage 12.1): the render applies it to the voice, the room's Preview too
  deleted?: string[]; // graphics Ron deleted (also in hidden)
};
// Where the title and subtitles sit for one network, so its buttons and texts do not cover them.
export type Place = {titleTop: number; subY: number; maxW: number};

const Caption: React.FC<{page: Page; place?: Place}> = ({page, place}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const scale = interpolate(spring({frame, fps, durationInFrames: 5}), [0, 1], [0.85, 1]);
  return (
    // centred on y = 1152 (60% of 1920)
    <AbsoluteFill style={{top: (place?.subY ?? 1152) - 60, height: 120, justifyContent: 'center', alignItems: 'center'}}>
      <div
        dir="rtl"
        style={{
          fontFamily: FONT,
          fontWeight: 800,
          fontSize: fitSize(page.text, 84, place?.maxW ?? 980),   // a longer page (a sentence, 11.4) gets smaller
          color: 'white',
          textShadow: SHADOW,
          transform: `scale(${scale})`,
          whiteSpace: 'nowrap',
        }}
      >
        {page.units.map(([w, ltr], i) => (
          <span key={i}>
            {i ? ' ' : ''}
            <span dir={ltr ? 'ltr' : 'rtl'} style={{unicodeBidi: 'isolate'}}>{w}</span>
          </span>
        ))}
      </div>
    </AbsoluteFill>
  );
};

const Title: React.FC<{lines: string[]; end: number; place?: Place}> = ({lines, end, place}) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(frame, [0, 6, end - 6, end], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return (
    <AbsoluteFill style={{top: place?.titleTop ?? 270, height: 300, alignItems: 'center', opacity}}>
      <div dir="rtl" style={{fontFamily: FONT, textAlign: 'center', textShadow: '0 0 28px rgba(0,0,0,0.65), ' + SHADOW}}>
        {lines.slice(0, -1).map((l, i) => (
          <div key={i} style={{fontWeight: 900, fontSize: fitSize(l, 96, Math.min(940, place?.maxW ?? 940)), color: ACCENT, lineHeight: 1.1}}>
            {l}
          </div>
        ))}
        <div style={{fontWeight: 600, fontSize: fitSize(lines.at(-1) ?? '', 54, Math.min(900, place?.maxW ?? 900)), color: 'white', lineHeight: 1.3}}>
          {lines.at(-1)}
        </div>
      </div>
    </AbsoluteFill>
  );
};

export const Overlay: React.FC<OverlayProps> = ({pages, title, titleEnd, graphics = [], hidden = [], effects = [], place, sfxGain = {}}) => {
  const {fps} = useVideoConfig();
  return (
    <AbsoluteFill>
      {audibleEffects(effects, hidden).map((e) => (
        <SfxGain.Provider key={`sfx-${e.id}`} value={sfxGain[e.id] ?? 1}>
          <Sequence from={e.from} durationInFrames={e.dur + 30} layout="none" name={`sfx-${e.id}`}>
            {(EFFECTS[e.kind]?.sfx ?? []).map((s, k) => <Sfx key={k} name={s.name} at={s.at} volume={s.volume} />)}
          </Sequence>
        </SfxGain.Provider>
      ))}
      {graphics.filter((g) => !hidden.includes(g.id) && GRAPHICS[g.kind]).map((g) => {
        const Kind = GRAPHICS[g.kind];
        return (
          <SfxGain.Provider key={g.id} value={sfxGain[g.id] ?? 1}>
            <Sequence from={g.from} durationInFrames={g.dur} name={g.id}>
              <Kind dur={g.dur} {...g.props} />
            </Sequence>
          </SfxGain.Provider>
        );
      })}
      {!hidden.includes('title') && <Title lines={title} end={Math.round(titleEnd * fps)} place={place} />}
      {pages.map((p, i) => {
        const from = Math.round(p.s * fps);
        return (
          <Sequence key={i} from={from} durationInFrames={Math.max(1, Math.round(p.e * fps) - from)}>
            <Caption page={p} place={place} />
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};
