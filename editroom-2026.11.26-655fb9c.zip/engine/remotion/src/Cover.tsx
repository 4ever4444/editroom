// Transparent cover title, laid over the chosen frame by ffmpeg.
// Everything stays inside the 3:4 grid crop (y 240-1680).
import {AbsoluteFill} from 'remotion';
import {ACCENT, fitSize, FONT, SHADOW} from './style';

export type CoverProps = {lines: [string, string]; variant: 1 | 2};

export const Cover: React.FC<CoverProps> = ({lines, variant}) =>
  variant === 1 ? (
    // 1: big gold headline over the blinds, white second line, dark glow
    <AbsoluteFill style={{top: 290, height: 420, alignItems: 'center'}}>
      <div dir="rtl" style={{fontFamily: FONT, fontWeight: 900, textAlign: 'center', lineHeight: 1.05,
        textShadow: '0 0 40px rgba(0,0,0,0.75), ' + SHADOW}}>
        <div style={{fontSize: fitSize(lines[0], 150, 960), color: ACCENT}}>{lines[0]}</div>
        <div style={{fontSize: fitSize(lines[1], 120, 960), color: 'white'}}>{lines[1]}</div>
      </div>
    </AbsoluteFill>
  ) : (
    // 2: white text on solid gold/black labels, lower third
    <AbsoluteFill style={{top: 1180, height: 420, alignItems: 'center', gap: 18}}>
      {lines.map((l, i) => (
        <div key={i} dir="rtl" style={{fontFamily: FONT, fontWeight: 900, fontSize: fitSize(l, 110, 860),
          lineHeight: 1.15, padding: '6px 34px', borderRadius: 18,
          background: i ? 'rgba(0,0,0,0.82)' : ACCENT, color: i ? 'white' : '#111'}}>
          {l}
        </div>
      ))}
    </AbsoluteFill>
  );
