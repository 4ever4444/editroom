// What the editing room plays: the picture layer (cut video + effects) with the render's own Overlay on top.
// The voice plays once, from its own audio element: the picture copies inside effects are silent.
import {AbsoluteFill, Html5Audio, Html5Video, Img, Sequence} from 'remotion';
import {EffectsLayer} from './effects/EffectsLayer';
import {Overlay, OverlayProps} from './Overlay';

// music: the ducked bed engine/music.py made, so the room plays the music exactly as the final video has it
// hf: library blocks (engine/hf_layer.py), see-through webm over the picture and under the subtitles, as in the render
// logo: the client's logo as rendered (engine/logo.py, same see-through webm); logoDraft: the "לוגו" button's choice
// before Claude renders it, drawn straight from the image at the same place (stage 8)
type Block = {id: string; from: number; dur: number; src?: string};
type Draft = {url: string; from: number; dur: number; x: number; y: number; width: number; height: number};
export type PreviewProps = OverlayProps & {video: string; raw?: string; music?: string | null; hf?: Block[];
  logo?: Block | null; logoDraft?: Draft | null};

export const Preview: React.FC<PreviewProps> = ({video, raw, music, hf, logo, logoDraft, ...overlay}) => (
  <AbsoluteFill style={{background: 'black'}}>
    <Html5Audio src={video} volume={Math.min(1, 10 ** ((overlay.voiceDb ?? 0) / 20))} />
    {music ? <Html5Audio src={music} /> : null}
    <EffectsLayer video={video} raw={raw} effects={overlay.effects} hidden={overlay.hidden} />
    {(hf ?? []).filter((h) => h.src && !(overlay.hidden ?? []).includes(h.id)).map((h) => (
      <Sequence key={h.id} from={h.from} durationInFrames={h.dur} layout="none">
        <AbsoluteFill><Html5Video src={h.src!} muted style={{width: '100%', height: '100%'}} /></AbsoluteFill>
      </Sequence>
    ))}
    {logoDraft ? (
      <Sequence from={logoDraft.from} durationInFrames={Math.max(1, logoDraft.dur)} layout="none">
        <Img src={logoDraft.url} style={{position: 'absolute', left: logoDraft.x, top: logoDraft.y, width: logoDraft.width, height: logoDraft.height}} />
      </Sequence>
    ) : logo?.src && !(overlay.hidden ?? []).includes('logo') ? (
      <Sequence from={logo.from} durationInFrames={logo.dur} layout="none">
        <AbsoluteFill><Html5Video src={logo.src} muted style={{width: '100%', height: '100%'}} /></AbsoluteFill>
      </Sequence>
    ) : null}
    <Overlay {...overlay} />
  </AbsoluteFill>
);
