// The one react-dom API the room uses (avoids installing @types/react-dom for a single function).
declare module 'react-dom/client' {
  export function createRoot(el: Element): {render(node: React.ReactNode): void; unmount(): void};
}
