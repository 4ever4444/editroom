// Remotion Player for the editing room's layers stage. Bundled by esbuild into engine/room/layers.js
// (npm run room) and used by engine/room/layers-stage.js through window.RoomLayers.mount().
import {Player, PlayerRef} from '@remotion/player';
import {createRef} from 'react';
import {createRoot} from 'react-dom/client';
import {EFFECTS} from '../effects';
import {Preview, PreviewProps} from '../Preview';
import {AbsoluteFill, Img} from 'remotion';
import {EpisodeTitle, EpisodeTitleProps} from '../EpisodeTitle';

// the effects catalog for the room's catalog page: everything but the component itself
export const catalog = Object.fromEntries(Object.entries(EFFECTS).map(([kind, {component, ...info}]) => [kind, info]));

export function mount(el: HTMLElement, props: PreviewProps, options: {controls?: boolean; loop?: boolean} = {}) {
  const ref = createRef<PlayerRef>();
  const root = createRoot(el);
  const draw = (p: PreviewProps) =>
    root.render(
      <Player
        ref={ref}
        component={Preview}
        inputProps={p}
        durationInFrames={p.durationInFrames}
        fps={p.fps}
        compositionWidth={1080}
        compositionHeight={1920}
        style={{width: '100%', height: '100%'}}
        clickToPlay={false}
        controls={options.controls}
        loop={options.loop}
        moveToBeginningWhenEnded={false}   // stay on the last frame: the logo at the end plays on there (play() starts over)
        numberOfSharedAudioTags={0}   // the room always starts playback from a click, so no pre-mounted tags needed
        acknowledgeRemotionLicense
      />,
    );
  draw(props);
  return new Promise<{player: PlayerRef; update: (p: PreviewProps) => void}>((resolve) => {
    const wait = () => (ref.current ? resolve({player: ref.current, update: draw}) : requestAnimationFrame(wait));
    wait();
  });
}

// stage 11.1: the episode's opening title, live and looping over a frame of the episode, in the title window
type TitlePreviewProps = EpisodeTitleProps & {frame: string};
const TitlePreview: React.FC<TitlePreviewProps> = ({frame, ...title}) => (
  <AbsoluteFill style={{background: '#111'}}>
    {frame && <Img src={frame} style={{width: '100%', height: '100%', objectFit: 'cover'}} />}
    <EpisodeTitle {...title} />
  </AbsoluteFill>
);

export function mountTitle(el: HTMLElement, props: TitlePreviewProps) {
  const root = createRoot(el);
  const draw = (p: TitlePreviewProps) =>
    root.render(
      <Player component={TitlePreview} inputProps={p} durationInFrames={p.durationInFrames} fps={p.fps}
        compositionWidth={1920} compositionHeight={1080} style={{width: '100%', height: '100%'}}
        autoPlay loop controls={false} numberOfSharedAudioTags={0} acknowledgeRemotionLicense />,
    );
  draw(props);
  return draw;
}
