// Stage 11.1: the opening title of a wide episode (Ron, 17.11: "a title in the first seconds, then on with the show"),
// and the YouTube thumbnail's text. Ron's house style by default (Heebo, gold heavy lines, a white last line); the
// font, colours, fill, outline, place, background and the way in and out come from titles.ts and titleFx.tsx
// (Ron 19.11: as many as possible, with real 3D). Transparent: engine/title.py lays the title over the episode's
// first seconds and the thumbnail text over a frame.
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {fitSize, SHADOW} from './style';
import {FX} from './titleFx';
import {loadFont, shade, TITLE_COLORS, TITLE_FILLS, TITLE_STROKES} from './titles';

export type TitleLook = {font?: string; colors?: string; big?: string; small?: string; fill?: string; stroke?: string;
  effect?: string; place?: string; back?: string};
export type EpisodeTitleProps = TitleLook & {lines: string[]; fps: number; durationInFrames: number};

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const BANDS: Record<string, string> = {
  bottom: 'linear-gradient(to top, rgba(0,0,0,0.72) 0%, rgba(0,0,0,0.45) 38%, rgba(0,0,0,0) 62%)',
  top: 'linear-gradient(to bottom, rgba(0,0,0,0.72) 0%, rgba(0,0,0,0.45) 38%, rgba(0,0,0,0) 62%)',
  center: 'radial-gradient(ellipse at center, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0.3) 45%, rgba(0,0,0,0) 75%)',
};
const JUSTIFY = {bottom: 'flex-end', center: 'center', top: 'flex-start'} as const;
const SLOW = ['words', 'bounce', 'typewriter', 'bar', 'scramble', 'draw', 'letters3d', 'slam', 'rise', 'shine', 'extrude3d'];

// the colours in use: a preset, or Ron's own two (custom)
export const palette = (l: TitleLook) => {
  const c = TITLE_COLORS[l.colors ?? 'gold'] ?? TITLE_COLORS.gold;
  return l.colors === 'custom' ? {...c, big: l.big || c.big, small: l.small || c.small, glow: l.big || c.glow} : c;
};

// how the words themselves are painted: colour or gradient, outline, shadow
const paint = (color: string, l: TitleLook, big: boolean, boxed: boolean): React.CSSProperties => {
  const grad = big ? TITLE_FILLS[l.fill ?? 'solid']?.css : undefined;
  const px = TITLE_STROKES[l.stroke ?? 'none']?.px;
  const base: React.CSSProperties = grad
    ? {backgroundImage: grad, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent',
      WebkitTextFillColor: 'transparent', filter: 'drop-shadow(0 4px 14px rgba(0,0,0,0.6))', paddingInline: '0.05em'}
    : {color, textShadow: boxed ? 'none' : '0 0 28px rgba(0,0,0,0.65), ' + SHADOW};
  return px ? {...base, WebkitTextStroke: `${big ? px : Math.ceil(px / 2)}px ${l.colors === 'white' ? '#111' : '#000'}`, paintOrder: 'stroke fill'} : base;
};

// a gradient fill leaves the letters see-through, so a text shadow (3D depth, neon, glitch) would show through them:
// then the same shadows are drawn behind the letters as drop shadows instead
const behind = (text: React.CSSProperties, grad: boolean): React.CSSProperties => {
  if (!grad || !text.textShadow || text.textShadow === 'none') return text;
  // drop shadows stack: each one shadows everything before it, so a run of hard layers (3D depth) is drawn as steps
  // of the difference between neighbours, not at each layer's own offset (that would pile up to ten times the depth)
  // and at most 8 hard steps: each drop shadow redraws all before it, so 30 of them (a long shadow) froze the render
  let px = 0, py = 0;
  const layers = String(text.textShadow).split(/,(?![^(]*\))/);
  const hard = layers.filter((x) => /^\s*-?[\d.]+px -?[\d.]+px 0 /.test(x));
  const keep = new Set(hard.filter((_, i) => i === hard.length - 1 || (i + 1) % Math.ceil(hard.length / 8) === 0));
  const shadows = layers.filter((x) => !hard.includes(x) || keep.has(x)).map((x) => {
    const m = x.trim().match(/^(-?[\d.]+)px (-?[\d.]+)px 0 (.+)$/);
    if (!m) return `drop-shadow(${x.trim()})`;
    const [dx, dy] = [+m[1] - px, +m[2] - py];
    [px, py] = [+m[1], +m[2]];
    return `drop-shadow(${dx}px ${dy}px 0 ${m[3]})`;
  }).join(' ');
  return {...text, textShadow: 'none', filter: shadows};
};

export const EpisodeTitle: React.FC<EpisodeTitleProps> = ({lines, ...look}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const {font = 'heebo', effect = 'fade', place = 'bottom', back = 'band'} = look;
  const f = loadFont(font);
  const c = palette(look);
  const fx = FX[effect] ?? FX.fade;
  const IN = Math.round(fps * (SLOW.includes(effect) ? 1.2 : 0.8));
  const OUT = Math.round(fps * 0.5);
  const box = back === 'box' ? (look.colors === 'black' ? '#FFC83D' : 'rgba(7,7,10,0.82)') : null;
  const p = (place in JUSTIFY ? place : 'bottom') as keyof typeof JUSTIFY;
  return (
    <AbsoluteFill>
      {back === 'band' && <AbsoluteFill style={{background: BANDS[p], opacity: interpolate(frame,
        [0, OUT, durationInFrames - OUT, durationInFrames - 1], [0, 1, 1, 0], clamp)}} />}
      <AbsoluteFill style={{justifyContent: JUSTIFY[p], alignItems: 'center', padding: '90px 0 110px'}}>
        <div dir="rtl" style={{display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center'}}>
          {lines.map((l, i) => {
            const last = i === lines.length - 1 && lines.length > 1;
            const start = i * Math.round(fps * 0.12);
            const color = last ? c.small : c.big;
            const out = fx({text: l, frame, fps, glow: c.glow, depth: shade(color.startsWith('#') ? color : '#888888'),
              pin: interpolate(frame - start, [0, IN], [0, 1], clamp),
              pout: interpolate(frame, [durationInFrames - OUT, durationInFrames - 1], [0, 1], clamp)});
            return (
              <div key={i} style={{position: 'relative', display: 'inline-block', margin: box ? '6px 0' : 0, ...out.outer}}>
                <div style={{fontFamily: f.family, fontWeight: last ? f.light : f.heavy, fontSize: fitSize(l, last ? 60 : 110, last ? 1500 : 1600),
                  lineHeight: 1.12, whiteSpace: 'nowrap', padding: box ? '4px 30px' : 0, borderRadius: 16, background: box ?? undefined,
                  ...paint(color, look, !last, !!box), ...behind(out.text ?? {}, !last && !!TITLE_FILLS[look.fill ?? 'solid']?.css)}}>
                  {out.content ?? l}
                </div>
                {out.over}
              </div>
            );
          })}
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

// the thumbnail's text: big and heavy for a small picture, on the right half (Hebrew reads from there), a dark fade
// behind it; the people stay on the left half of the frame. Same font, colours, fill and outline as the title.
export const Thumb: React.FC<{lines: string[]} & TitleLook> = ({lines, ...look}) => {
  const f = loadFont(look.font ?? 'heebo');
  const c = palette(look);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: 'linear-gradient(to left, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.55) 45%, rgba(0,0,0,0) 70%)'}} />
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'flex-end', paddingRight: 56}}>
        <div dir="rtl" style={{fontFamily: f.family, textAlign: 'right', lineHeight: 1.05, whiteSpace: 'nowrap'}}>
          {lines.map((l, i) => {
            const big = i < lines.length - 1 || lines.length === 1;
            const color = big ? (look.colors === 'black' ? '#ffffff' : c.big) : c.small;
            return <div key={i} style={{fontWeight: big ? f.heavy : f.light, fontSize: fitSize(l, big ? 110 : 76, 560),
              ...paint(color, look, big, false)}}>{l}</div>;
          })}
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
