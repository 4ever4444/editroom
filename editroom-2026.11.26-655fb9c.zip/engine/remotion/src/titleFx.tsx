// The ways an episode title comes in and goes out (stage 11.1; Ron 19.11: "as many as possible, with real 3D").
// Each effect gets one line of the title and how far along it is, and says how to draw it:
//   outer = the line's box (moves, turns, clips), text = the words' own style, content = the words (when they move
//   one by one), over = something drawn on top (a light, a bar). The names and labels live in titles.ts.
import {Easing, interpolate} from 'remotion';

export type FxCtx = {text: string; pin: number; pout: number; frame: number; fps: number; glow: string; depth: string};
export type FxOut = {outer?: React.CSSProperties; text?: React.CSSProperties; content?: React.ReactNode; over?: React.ReactNode};

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ease = Easing.out(Easing.cubic);
const backOut = Easing.out(Easing.back(1.8));
const elastic = Easing.out(Easing.elastic(1.2));
const noise = (f: number, k: number) => {
  const x = Math.sin(f * 12.9898 + k * 78.233) * 43758.5453;
  return x - Math.floor(x);
};
const HEB = 'אבגדהוזחטיכלמנסעפצקרשת';
// a run of spans, one per letter (or per word), each placed by `at(k, n)` = its own 0..1
const pieces = (parts: string[], gap: string, at: (k: number) => React.CSSProperties) =>
  parts.map((c, k) => <span key={k} style={{display: 'inline-block', whiteSpace: 'pre', marginInlineEnd: gap, ...at(k)}}>{c}</span>);
const stagger = (pin: number, k: number, n: number, spread = 0.6) =>
  interpolate(pin, [spread * k / Math.max(1, n), spread * k / Math.max(1, n) + (1 - spread)], [0, 1], clamp);
// the depth of an extruded letter: layers of shadow going down and back
const extrude = (depth: string, n = 14) =>
  Array.from({length: n}, (_, i) => `${i + 1}px ${i + 1}px 0 ${depth}`).join(', ') + ', 0 18px 30px rgba(0,0,0,0.55)';

export const FX: Record<string, (c: FxCtx) => FxOut> = {
  fade: ({pin, pout}) => ({outer: {opacity: ease(pin) * (1 - pout), transform: `translateY(${(1 - ease(pin)) * 30 - pout * 20}px)`}}),
  typewriter: ({text, pin, pout}) => {
    const chars = Array.from(text);
    return {outer: {opacity: pin > 0 ? 1 - pout : 0}, content: chars.slice(0, Math.ceil(chars.length * Math.min(1, pin * 1.15))).join('')};
  },
  words: ({text, pin, pout}) => {
    const w = text.split(' ');
    return {outer: {opacity: 1 - pout}, content: pieces(w, '0.25em', (k) => {
      const p = stagger(pin, k, w.length, 0.7);
      return {opacity: p > 0 ? 1 : 0, transform: `scale(${0.3 + 0.7 * backOut(p)})`};
    })};
  },
  slide: ({pin, pout}) => ({outer: {opacity: ease(pin) * (1 - pout), transform: `translateX(${(1 - ease(pin)) * 420 - pout * 420}px)`}}),
  zoom: ({pin, pout}) => ({outer: {opacity: ease(pin) * (1 - pout), transform: `scale(${2.2 - 1.2 * ease(pin) + pout * 0.4})`,
    filter: `blur(${(1 - ease(pin)) * 12 + pout * 8}px)`}}),
  blur: ({pin, pout}) => ({outer: {opacity: ease(pin) * (1 - pout), filter: `blur(${(1 - ease(pin)) * 26 + pout * 26}px)`}}),
  glitch: ({pin, pout, frame}) => {
    const shaking = (pin > 0 && pin < 0.6) || pout > 0;
    return {outer: {opacity: pin > 0 ? (pout > 0.7 ? 0 : 1) : 0, transform: `translateX(${shaking ? (noise(frame, 1) - 0.5) * 40 : 0}px)`},
      text: shaking ? {textShadow: `${6 + noise(frame, 2) * 6}px 0 0 #ff2a55, ${-6 - noise(frame, 3) * 6}px 0 0 #2af4ff`} : {}};
  },
  neon: ({pin, pout, glow}) => {
    const flick = [1, 0.15, 1, 0.3, 1, 0.55, 1];
    const on = pin >= 1 ? 1 : pin > 0 ? flick[Math.min(flick.length - 1, Math.floor(pin * flick.length))] : 0;
    const off = pout > 0 ? flick[Math.floor(pout * flick.length) % flick.length] * (1 - pout) : 1;
    return {outer: {opacity: on * off}, text: {textShadow: `0 0 6px #fff, 0 0 18px ${glow}, 0 0 42px ${glow}, 0 0 80px ${glow}`}};
  },
  flip: ({pin, pout}) => ({outer: {opacity: ease(pin) * (1 - pout), transform: `perspective(900px) rotateX(${(1 - ease(pin)) * 90 - pout * 90}deg)`}}),
  wipe: ({pin, pout}) => ({outer: {opacity: pin > 0 ? 1 : 0, clipPath: `inset(-20% ${pout * 100}% -20% ${(1 - ease(pin)) * 100}%)`}}),
  bar: ({pin, pout, glow}) => {
    const grow = interpolate(pin, [0, 0.45], [0, 1], clamp), leave = interpolate(pin, [0.5, 1], [0, 1], clamp);
    return {text: {opacity: (pin >= 0.5 ? 1 : 0) * (1 - pout)},
      over: <div style={{position: 'absolute', inset: '-4px -12px', background: glow, transformOrigin: leave > 0 ? 'left' : 'right',
        transform: `scaleX(${leave > 0 ? 1 - ease(leave) : ease(grow)})`, opacity: 1 - pout}} />};
  },
  bounce: ({text, pin, pout}) => {
    const ch = Array.from(text);
    return {outer: {opacity: 1 - pout}, content: pieces(ch, '0', (k) => {
      const p = stagger(pin, k, ch.length);
      return {opacity: p > 0 ? 1 : 0, transform: `translateY(${(1 - backOut(p)) * -120}px)`};
    })};
  },
  // ---- 3D
  extrude3d: ({pin, pout, depth}) => {
    const e = ease(pin);
    return {outer: {opacity: Math.min(1, pin * 3) * (1 - pout), transform: `perspective(1200px) rotateY(${(1 - e) * -70 + pout * 70}deg) rotateX(${(1 - e) * 20}deg)`},
      text: {textShadow: extrude(depth)}};
  },
  spin3d: ({pin, pout}) => ({outer: {opacity: Math.min(1, pin * 2) * (1 - pout),
    transform: `perspective(1200px) rotateY(${(1 - ease(pin)) * 360 + pout * 180}deg)`}}),
  cube: ({pin, pout}) => ({outer: {opacity: Math.min(1, pin * 2) * (1 - pout), transformOrigin: '50% 50% -60px',
    transform: `perspective(1000px) rotateX(${(1 - ease(pin)) * -90 + pout * 90}deg)`}}),
  depth: ({pin, pout}) => ({outer: {opacity: ease(pin) * (1 - pout),
    transform: `perspective(800px) translateZ(${(1 - ease(pin)) * -2400 + pout * 600}px)`}}),
  letters3d: ({text, pin, pout}) => {
    const ch = Array.from(text);
    return {outer: {opacity: 1 - pout, perspective: 900}, content: pieces(ch, '0', (k) => {
      const p = stagger(pin, k, ch.length);
      return {opacity: p > 0 ? 1 : 0, transform: `rotateY(${(1 - ease(p)) * 100}deg)`};
    })};
  },
  tilt: ({pin, pout}) => ({outer: {opacity: ease(pin) * (1 - pout),
    transform: `perspective(700px) rotateX(${(1 - ease(pin)) * 65}deg) translateY(${(1 - ease(pin)) * 120}px) rotateX(${-pout * 60}deg)`}}),
  // ---- light and drawing
  shine: ({pin, pout}) => {
    const run = interpolate(pin, [0.35, 1], [-60, 160], clamp);
    return {outer: {opacity: ease(Math.min(1, pin * 2)) * (1 - pout)},
      over: <div style={{position: 'absolute', inset: 0, mixBlendMode: 'overlay', pointerEvents: 'none',
        background: `linear-gradient(105deg, transparent ${run - 18}%, rgba(255,255,255,0.95) ${run}%, transparent ${run + 18}%)`}} />};
  },
  scramble: ({text, pin, pout, frame}) => {
    const ch = Array.from(text);
    const done = Math.floor(ch.length * Math.min(1, pin * 1.2));
    return {outer: {opacity: pin > 0 ? 1 - pout : 0},
      content: ch.map((c, k) => (k < done || c === ' ' ? c : HEB[Math.floor(noise(frame, k) * HEB.length)])).join('')};
  },
  draw: ({pin, pout, glow}) => ({outer: {opacity: (pin > 0 ? 1 : 0) * (1 - pout)},
    text: {WebkitTextStroke: `${pin < 0.6 ? 3 : 0}px ${glow}`, WebkitTextFillColor: pin < 0.55 ? 'transparent' : undefined,
      clipPath: pin < 0.55 ? `inset(0 0 0 ${(1 - interpolate(pin, [0, 0.55], [0, 1], clamp)) * 100}%)` : undefined,
      opacity: pin < 0.55 ? 1 : interpolate(pin, [0.55, 1], [0.4, 1], clamp)}}),
  wave: ({text, pin, pout, frame, fps}) => {
    const ch = Array.from(text);
    const amp = (1 - ease(pin)) * 40 + 4 * (pin >= 1 ? 0 : 1);
    return {outer: {opacity: ease(Math.min(1, pin * 2)) * (1 - pout)}, content: pieces(ch, '0', (k) =>
      ({transform: `translateY(${Math.sin(frame / fps * 9 - k * 0.6) * amp}px)`}))};
  },
  elastic: ({pin, pout}) => ({outer: {opacity: Math.min(1, pin * 3) * (1 - pout), transform: `scaleX(${0.2 + 0.8 * elastic(pin) + pout * 0.5}) scaleY(${1 - pout * 0.6})`}}),
  slam: ({text, pin, pout, frame}) => {
    const w = text.split(' ');
    const shake = pin > 0.2 && pin < 0.9 ? (noise(frame, 7) - 0.5) * 10 : 0;
    return {outer: {opacity: 1 - pout, transform: `translate(${shake}px, ${shake / 2}px)`}, content: pieces(w, '0.25em', (k) => {
      const p = stagger(pin, k, w.length, 0.75);
      return {opacity: p > 0 ? 1 : 0, transform: `scale(${3 - 2 * ease(p)})`};
    })};
  },
  rise: ({text, pin, pout}) => {   // each word rises out of an invisible line, as if from behind it
    const w = text.split(' ');
    return {outer: {opacity: 1 - pout}, content: w.map((x, k) => (
      <span key={k} style={{display: 'inline-block', overflow: 'hidden', verticalAlign: 'bottom', marginInlineEnd: '0.25em',
        paddingBottom: '0.08em'}}>
        <span style={{display: 'inline-block', transform: `translateY(${(1 - ease(stagger(pin, k, w.length, 0.6))) * 110}%)`}}>{x}</span>
      </span>))};
  },
  tracking: ({pin, pout}) => ({outer: {opacity: ease(pin) * (1 - pout), filter: `blur(${(1 - ease(pin)) * 6}px)`},
    text: {letterSpacing: `${(1 - ease(pin)) * 0.6 + pout * 0.3}em`}}),
  longshadow: ({pin, pout, depth}) => {
    const n = Math.round(ease(pin) * 30);
    return {outer: {opacity: Math.min(1, pin * 2) * (1 - pout), transform: `translateY(${(1 - ease(pin)) * 40}px)`},
      text: {textShadow: Array.from({length: n}, (_, i) => `${i + 1}px ${i + 1}px 0 ${depth}`).join(', ') || 'none'}};
  },
  drop: ({pin, pout, frame}) => {
    const p = interpolate(pin, [0, 0.55], [0, 1], clamp);
    const shake = pin > 0.55 && pin < 0.8 ? (noise(frame, 5) - 0.5) * 16 : 0;
    return {outer: {opacity: (pin > 0 ? 1 : 0) * (1 - pout),
      transform: `translateY(${(1 - Easing.in(Easing.quad)(p)) * -700 + pout * 60}px) translateX(${shake}px)`}};
  },
  curtain: ({pin, pout}) => {
    const c = (1 - ease(pin)) * 50 + pout * 50;
    return {outer: {opacity: pin > 0 ? 1 : 0, clipPath: `inset(${c}% -10% ${c}% -10%)`}};
  },
  swing: ({pin, pout}) => ({outer: {opacity: Math.min(1, pin * 3) * (1 - pout), transformOrigin: '50% 0%',
    transform: `perspective(900px) rotateX(${(1 - elastic(pin)) * -80 + pout * 80}deg)`}}),
};
