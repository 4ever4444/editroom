// Ron's house style. Fonts live in /library (the Remotion public dir).
import {continueRender, delayRender, staticFile} from 'remotion';

export const FONT = 'Heebo';
export const ACCENT = '#FFC83D'; // warm gold, reads on the dark blinds
export const SHADOW = '0 4px 18px rgba(0,0,0,0.55), 0 2px 4px rgba(0,0,0,0.6)';

const handle = delayRender('font');
const face = new FontFace(FONT, `url('${staticFile('fonts/Heebo-Variable.ttf')}') format('truetype')`, {
  weight: '100 900',
});
face.load().then(() => {
  document.fonts.add(face);
  continueRender(handle);
});

// Shrink a single line to fit a width: Heebo heavy averages ~0.55em per character.
export const fitSize = (text: string, max: number, width: number) =>
  Math.min(max, Math.floor(width / (text.length * 0.55)));
