// The effects catalog: every effect the machine can apply to the picture itself (not on top of it).
// A video's graphics.json "effects" list uses these kinds; the room's catalog page shows each one.
// Sounds live here too: Overlay plays them (so they go through the same mix and limiter as all other sounds).
import type {SfxName} from '../graphics/motion';
import {Flash} from './Flash';
import {Glitch} from './Glitch';
import {Look} from './Look';
import {Split} from './Split';
import {Zoom} from './Zoom';
import type {EffectProps} from './types';

export type EffectSpec = {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  component: React.FC<EffectProps & any>;
  family: 'שינוי התמונה' | 'צבע ומראה' | 'ערבוב שכבות ומעברים' | 'הפרדת אדם מרקע ומעקב' | 'זמן' | 'תלת-ממד וחלקיקים';
  title: string;          // Hebrew name
  does: string;           // what Ron sees
  props: Record<string, string>;   // prop -> what it controls
  ask: string;            // what Ron writes in a note to get it
  dur: number;            // typical length, seconds
  sfx: {name: SfxName; at: number; volume: number}[];   // at = frames into the effect
  demo: Record<string, unknown>;   // props for the catalog page's example
};

export const EFFECTS: Record<string, EffectSpec> = {
  Glitch: {
    component: Glitch,
    family: 'צבע ומראה',
    title: 'מכת גליטש / VHS',
    does: 'התמונה נקרעת לפסים, הצבעים נפרדים, יש רעש וקווי סריקה, והמסך קופץ. רבע שנייה, על מילה חדה.',
    props: {strength: 'עוצמה, 1 = רגיל', seed: 'משנה את דפוס הקריעה'},
    ask: 'גליטש על "<המילה>"',
    dur: 0.3,
    sfx: [{name: 'glitch', at: 0, volume: 0.4}, {name: 'bass', at: 0, volume: 0.5}],
    demo: {},
  },
  Zoom: {
    component: Zoom,
    family: 'שינוי התמונה',
    title: 'זום לנקודה',
    does: 'כניסה מהירה לנקודה בפריים, החזקה ויציאה. הנקודה נשארת במקומה. כמה רחוק מותר: לפי הרזולוציה של הגלם.',
    props: {x: 'הנקודה לרוחב, 0 עד 1 (מהציור)', y: 'הנקודה לגובה, 0 עד 1 (מהציור)', scale: 'כמה קרוב, 1.5 = פי 1.5',
      enter: 'פריימים לכניסה, 0 = קפיצה', exit: 'פריימים ליציאה'},
    ask: 'זום על "<המילה>" + ציור עיגול על הנקודה. "גם אם מטושטש" מתיר לעבור את המגבלה',
    dur: 1.2,
    sfx: [{name: 'whoosh', at: 0, volume: 0.3}],
    demo: {x: 0.5, y: 0.3, scale: 1.5},
  },
  Split: {
    component: Split,
    family: 'שינוי התמונה',
    title: 'מסך מפוצל',
    does: 'המסך מתפצל לשניים (למעלה ולמטה, או צד לצד) ומתאחד בסוף. כל חלק: אתה עכשיו, רגע אחר מהגלם, או תמונה מ-library/broll.',
    props: {direction: 'rows = למעלה ולמטה, cols = צד לצד', a: 'החלק הראשון (ברירת מחדל: אתה עכשיו)',
      b: 'החלק השני: {source: "raw", t: שנייה בגלם} או {source: "image", file: "שם.jpg"}', 'fx, fy': 'נקודת המיקוד בכל חלק, כדי שהפנים יישארו בפנים',
      'enter, exit': 'פריימים לפיצול ולאיחוד'},
    ask: 'מסך מפוצל מ-"<מילה>" עד "<מילה>", בחצי השני: <מה>',
    dur: 1.6,
    sfx: [{name: 'whoosh', at: 0, volume: 0.35}],
    demo: {b: {source: 'raw', t: 10}},
  },
  Look: {
    component: Look,
    family: 'צבע ומראה',
    title: 'מראה קולנועי',
    does: 'צבע מוכן (חם, טורקיז-כתום, קר, שחור-לבן, דהוי), גרעיניות של פילם והכהיית שוליים. על קטע או על כל הסרטון.',
    props: {grade: 'warm / tealOrange / cool / bw / faded', grain: 'גרעיניות, 0 עד 1', vignette: 'הכהיית שוליים, 0 עד 1'},
    ask: 'מראה קולנועי <חם / קר / שחור-לבן...> על כל הסרטון (או מ-"<מילה>" עד "<מילה>")',
    dur: 1.2,
    sfx: [],
    demo: {grade: 'tealOrange'},
  },
  Flash: {
    component: Flash,
    family: 'צבע ומראה',
    title: 'פלאש',
    does: 'המסך נצבע ללבן (או לצבע אחר) לכמה פריימים ונעלם. על מילה חדה.',
    props: {color: 'הצבע, ברירת מחדל לבן', strength: 'עוצמה, 0 עד 1'},
    ask: 'פלאש על "<המילה>"',
    dur: 0.2,
    sfx: [{name: 'thump', at: 0, volume: 0.3}],
    demo: {},
  },
};
