// Which effects act on a frame. Pure, so node can test it (active.test.mts) without Remotion.

export type Effect = {id: string; kind: string; from: number; dur: number; label?: string; props: Record<string, unknown>};

// Every effect whose frames [from, from + dur) include `frame`, minus hidden ones, in list order:
// that order is the chain order (the first wraps the footage, the next wraps the first, ...).
export const activeEffects = (effects: Effect[], hidden: string[], frame: number): Effect[] =>
  effects.filter((e) => !hidden.includes(e.id) && frame >= e.from && frame < e.from + e.dur);

// The effects whose sounds play (in Overlay, so in the room and in the final video): a hidden effect is silent.
export const audibleEffects = (effects: Effect[], hidden: string[]): Effect[] => effects.filter((e) => !hidden.includes(e.id));
