// node engine/remotion/src/effects/active.test.mts  (Node 24 runs TypeScript directly)
import assert from 'node:assert/strict';
import {activeEffects, audibleEffects, type Effect} from './active.ts';

const fx = (id: string, from: number, dur: number): Effect => ({id, kind: 'Glitch', from, dur, props: {}});
const list = [fx('a', 10, 5), fx('b', 12, 6)];   // overlap on frames 12..14

assert.deepEqual(activeEffects(list, [], 9).map((e) => e.id), []);
assert.deepEqual(activeEffects(list, [], 10).map((e) => e.id), ['a']);            // first frame is in
assert.deepEqual(activeEffects(list, [], 13).map((e) => e.id), ['a', 'b']);       // both, in list order
assert.deepEqual(activeEffects(list, [], 15).map((e) => e.id), ['b']);            // frame from + dur is out
assert.deepEqual(activeEffects(list, [], 18).map((e) => e.id), []);
assert.deepEqual(activeEffects(list, ['a'], 13).map((e) => e.id), ['b']);         // hidden is never active
assert.deepEqual(audibleEffects(list, []).map((e) => e.id), ['a', 'b']);
assert.deepEqual(audibleEffects(list, ['a']).map((e) => e.id), ['b']);              // hidden effect is silent
console.log('ok');
