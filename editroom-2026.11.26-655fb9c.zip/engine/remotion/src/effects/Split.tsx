// Split screen: the frame divides into two parts (top/bottom or side by side) and joins back at the end.
// Each part shows Ron as he is now, another moment of the raw, or an image from library/broll/, cropped around
// its focus point so the face stays inside its half.
import {AbsoluteFill, Img, Sequence, staticFile, useVideoConfig} from 'remotion';
import {Footage} from './Footage';
import {type Box, cover, H, ramp, splitBoxes, W} from './geometry';
import type {EffectProps} from './types';

export type Part = {source?: 'self' | 'raw' | 'image'; t?: number; file?: string; fx?: number; fy?: number};
export type SplitProps = {direction?: 'rows' | 'cols'; a?: Part; b: Part; enter?: number; exit?: number};

export const Split: React.FC<EffectProps & SplitProps> = ({frame, dur, from, raw, children, direction = 'rows', a = {}, b,
  enter = 8, exit = 8}) => {
  const {fps} = useVideoConfig();
  const p = ramp(frame, dur, enter, exit);
  const show = (part: Part, box: Box) => {
    const c = cover(box, {x: part.fx ?? 0.5, y: part.fy ?? 0.35});
    const picture = part.source === 'raw' ? (raw && (   // plays on from second t of the raw
      <Sequence from={from} layout="none"><Footage src={raw} trimBefore={Math.round((part.t ?? 0) * fps)} /></Sequence>))
      : part.source === 'image' ? <Img src={staticFile(`broll/${part.file}`)} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
      : children;
    return (
      <div style={{position: 'absolute', left: box.x, top: box.y, width: box.w, height: box.h, overflow: 'hidden'}}>
        <div style={{position: 'absolute', left: c.left, top: c.top, width: W, height: H, transform: `scale(${c.scale})`,
          transformOrigin: '0 0'}}>{picture}</div>
      </div>
    );
  };
  const [boxA, boxB] = splitBoxes(direction, p);
  const line = direction === 'rows' ? {left: 0, right: 0, top: boxB.y - 3, height: 6} : {top: 0, bottom: 0, left: boxB.w - 3, width: 6};
  return (
    <AbsoluteFill style={{background: 'black'}}>
      {show(a, boxA)}
      {p > 0 && show(b, boxB)}
      {p > 0 && <div style={{position: 'absolute', ...line, background: 'white', opacity: 0.9 * p, boxShadow: '0 0 18px rgba(0,0,0,0.5)'}} />}
    </AbsoluteFill>
  );
};
