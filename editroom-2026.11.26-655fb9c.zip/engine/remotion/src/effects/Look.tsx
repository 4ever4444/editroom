// Cinematic look: a colour grade (ready-made presets, no LUT files), film grain that changes every frame, and
// darkened edges. Meant for a section or the whole video.
import {AbsoluteFill} from 'remotion';
import type {EffectProps} from './types';

// feColorMatrix rows (r, g, b, a) and a contrast slope around mid grey
const GRADES = {
  warm: {matrix: '1.08 0.04 0 0 0.02  0 1.02 0 0 0.01  0 0 0.86 0 0  0 0 0 1 0', contrast: 1.06},
  tealOrange: {matrix: '1.12 0.06 -0.08 0 0.01  -0.02 1.02 0.02 0 0  -0.08 0.1 1.02 0 0.03  0 0 0 1 0', contrast: 1.12},
  cool: {matrix: '0.9 0 0.02 0 0  0 1 0.02 0 0  0 0.04 1.1 0 0.02  0 0 0 1 0', contrast: 1.05},
  bw: {matrix: '0.3 0.59 0.11 0 0  0.3 0.59 0.11 0 0  0.3 0.59 0.11 0 0  0 0 0 1 0', contrast: 1.18},
  faded: {matrix: '0.9 0.06 0.04 0 0.04  0.05 0.9 0.05 0 0.04  0.04 0.06 0.86 0 0.05  0 0 0 1 0', contrast: 0.86},
};
export type Grade = keyof typeof GRADES;
export type LookProps = {grade?: Grade; grain?: number; vignette?: number};

export const Look: React.FC<EffectProps & LookProps> = ({frame, children, grade = 'tealOrange', grain = 0.3, vignette = 0.4}) => {
  const g = GRADES[grade] ?? GRADES.tealOrange;
  const id = `look-${grade}`;
  return (
    <AbsoluteFill>
      <svg width={0} height={0} style={{position: 'absolute'}}>
        <filter id={id} colorInterpolationFilters="sRGB">
          <feColorMatrix type="matrix" values={g.matrix} />
          <feComponentTransfer>
            <feFuncR type="linear" slope={g.contrast} intercept={(1 - g.contrast) / 2} />
            <feFuncG type="linear" slope={g.contrast} intercept={(1 - g.contrast) / 2} />
            <feFuncB type="linear" slope={g.contrast} intercept={(1 - g.contrast) / 2} />
          </feComponentTransfer>
        </filter>
        <filter id="look-grain"><feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves={2} seed={frame} /></filter>
      </svg>
      <AbsoluteFill style={{filter: `url(#${id})`}}>{children}</AbsoluteFill>
      {grain > 0 && (
        <svg width={1080} height={1920} style={{position: 'absolute', inset: 0, opacity: 0.35 * grain, mixBlendMode: 'overlay'}}>
          <rect width={1080} height={1920} filter="url(#look-grain)" />
        </svg>
      )}
      {vignette > 0 && <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 45%, transparent 50%, rgba(0,0,0,${0.8 * vignette}) 100%)`}} />}
    </AbsoluteFill>
  );
};
