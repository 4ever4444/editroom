// Flash: the frame burns to a colour (white by default) for a few frames and fades back. On a sharp word.
import {AbsoluteFill, interpolate} from 'remotion';
import type {EffectProps} from './types';

export type FlashProps = {color?: string; strength?: number};

export const Flash: React.FC<EffectProps & FlashProps> = ({frame, dur, children, color = 'white', strength = 0.85}) => (
  <AbsoluteFill>
    {children}
    <AbsoluteFill style={{background: color, opacity: strength * interpolate(frame, [0, 1, dur], [0.7, 1, 0], {extrapolateRight: 'clamp'})}} />
  </AbsoluteFill>
);
