// Pure layout math for the picture effects, so node can test it (geometry.test.mts) without Remotion.

export const W = 1080, H = 1920;
export type Box = {x: number; y: number; w: number; h: number};

// 0 -> 1 over the first `enter` frames, holds, 1 -> 0 over the last `exit` frames, eased. 0 frames = a cut.
export const ramp = (frame: number, dur: number, enter: number, exit: number): number => {
  const ease = (t: number) => 1 - (1 - Math.min(1, Math.max(0, t))) ** 3;
  const up = enter > 0 ? ease(frame / enter) : 1;
  const down = exit > 0 ? ease((dur - frame) / exit) : frame < dur ? 1 : 0;
  return Math.min(up, down);
};

// Split screen at progress p: part a shrinks from the full frame, part b grows from the bottom (rows) or the
// left (cols, the side Hebrew reads toward).
export const splitBoxes = (direction: 'rows' | 'cols', p: number): [Box, Box] => {
  if (direction === 'rows') {
    const hb = Math.round((H / 2) * p);
    return [{x: 0, y: 0, w: W, h: H - hb}, {x: 0, y: H - hb, w: W, h: hb}];
  }
  const wb = Math.round((W / 2) * p);
  return [{x: wb, y: 0, w: W - wb, h: H}, {x: 0, y: 0, w: wb, h: H}];
};

// Fill a box with the full frame (scaled to cover it), keeping the focus point (0..1 of the frame) as near the
// box's centre as the frame's edges allow: the face stays in its half.
export const cover = (box: {w: number; h: number}, focus: {x: number; y: number}) => {
  const scale = Math.max(box.w / W, box.h / H);
  const place = (size: number, full: number, f: number) => Math.min(0, Math.max(size - full * scale, size / 2 - f * full * scale));
  return {scale, left: place(box.w, W, focus.x), top: place(box.h, H, focus.y)};
};
