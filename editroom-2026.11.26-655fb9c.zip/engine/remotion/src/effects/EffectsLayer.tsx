// The picture layer: the cut video, changed by every effect active on this frame, chained in list order.
// The room's Preview and the render's "Effects" composition both use it, so what Ron sees is what comes out.
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {activeEffects, type Effect} from './active';
import {Footage} from './Footage';
import {EFFECTS} from './index';

// fps / durationInFrames are only read by the "Effects" composition's metadata (render.py passes them)
export type EffectsLayerProps = {video: string; raw?: string; effects?: Effect[]; hidden?: string[]; fps?: number; durationInFrames?: number};

export const EffectsLayer: React.FC<EffectsLayerProps> = ({video, raw, effects = [], hidden = []}) => {
  const frame = useCurrentFrame();
  let picture: React.ReactNode = <Footage src={video} />;
  for (const e of activeEffects(effects, hidden, frame)) {
    const Kind = EFFECTS[e.kind]?.component;
    if (Kind) picture = <Kind frame={frame - e.from} dur={e.dur} from={e.from} raw={raw} {...e.props}>{picture}</Kind>;
  }
  return <AbsoluteFill style={{background: 'black'}}>{picture}</AbsoluteFill>;
};
