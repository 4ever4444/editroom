// Zoom to a point: a fast push into (x, y), a hold, and a way back out. enter 0 = an instant punch-in.
// The point (0..1 of the frame) comes from Ron's drawing; the point itself stays where it is on screen.
// How far it may go is checked in render.py (the raw's resolution), not here.
import {AbsoluteFill} from 'remotion';
import {ramp} from './geometry';
import type {EffectProps} from './types';

export type ZoomProps = {x?: number; y?: number; scale?: number; enter?: number; exit?: number};

export const Zoom: React.FC<EffectProps & ZoomProps> = ({frame, dur, children, x = 0.5, y = 0.4, scale = 1.5, enter = 5, exit = 6}) => (
  <AbsoluteFill style={{overflow: 'hidden', background: 'black'}}>
    <AbsoluteFill style={{transform: `scale(${1 + (scale - 1) * ramp(frame, dur, enter, exit)})`, transformOrigin: `${x * 100}% ${y * 100}%`}}>
      {children}
    </AbsoluteFill>
  </AbsoluteFill>
);
