// node engine/remotion/src/effects/geometry.test.mts  (Node 24 runs TypeScript directly)
import assert from 'node:assert/strict';
import {cover, ramp, splitBoxes} from './geometry.ts';

// ramp: in, hold, out; 0 frames is a cut
assert.equal(ramp(0, 30, 5, 5), 0);
assert.equal(ramp(5, 30, 5, 5), 1);
assert.equal(ramp(15, 30, 5, 5), 1);
assert.equal(ramp(30, 30, 5, 5), 0);
assert.ok(ramp(2, 30, 5, 5) > 0 && ramp(2, 30, 5, 5) < 1);
assert.equal(ramp(0, 30, 0, 5), 1);

// split: closed = one full frame; open = two halves that tile the frame
assert.deepEqual(splitBoxes('rows', 0)[0], {x: 0, y: 0, w: 1080, h: 1920});
assert.deepEqual(splitBoxes('rows', 1), [{x: 0, y: 0, w: 1080, h: 960}, {x: 0, y: 960, w: 1080, h: 960}]);
assert.deepEqual(splitBoxes('cols', 1), [{x: 540, y: 0, w: 540, h: 1920}, {x: 0, y: 0, w: 540, h: 1920}]);

// cover: the top half shows the face at y = 0.3 of the frame (576px) in its middle (480px)
const top = cover({w: 1080, h: 960}, {x: 0.5, y: 0.3});
assert.equal(top.scale, 1);
assert.equal(top.top + 0.3 * 1920, 480);
// a focus near the edge never pulls the frame past its edge (no black gap)
assert.equal(cover({w: 1080, h: 960}, {x: 0.5, y: 0.02}).top, 0);
assert.equal(cover({w: 1080, h: 960}, {x: 0.5, y: 0.98}).top, 960 - 1920);
// a side half: the frame still fills the full height
const side = cover({w: 540, h: 1920}, {x: 0.6, y: 0.5});
assert.equal(side.scale, 1);
assert.equal(side.left + 0.6 * 1080, 270);
console.log('ok');
