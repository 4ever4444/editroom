// What every effect component receives: the frame inside the effect, its length, where it starts in the video,
// the picture to change, and the raw's picture (for effects that show another moment of the raw).
export type EffectProps = {frame: number; dur: number; from: number; raw?: string; children: React.ReactNode};
