// The cut video's picture, always silent: effects may draw it several times over (colour split, torn bands),
// and each copy must not bring its own voice. The voice comes from edit.mkv (render) or Preview's single audio.
// Rendering: OffthreadVideo (frame-exact). The room's Player: a normal <video>.
import {AbsoluteFill, getRemotionEnvironment, Html5Video, OffthreadVideo, staticFile} from 'remotion';

const fill = {width: '100%', height: '100%'};

// "/media/..." (the room's server) is used as is; a bare name ("edit_video.mp4") lives in the render's public dir
const url = (src: string) => (/^(https?:)?\//.test(src) ? src : staticFile(src));

// trimBefore: frames of the file skipped before this footage's first frame (another moment of the raw)
export const Footage: React.FC<{src: string; trimBefore?: number}> = ({src, trimBefore}) => (
  <AbsoluteFill>
    {getRemotionEnvironment().isRendering
      ? <OffthreadVideo src={url(src)} trimBefore={trimBefore} muted transparent style={fill} />
      : <Html5Video src={url(src)} trimBefore={trimBefore} muted style={fill} />}
  </AbsoluteFill>
);
