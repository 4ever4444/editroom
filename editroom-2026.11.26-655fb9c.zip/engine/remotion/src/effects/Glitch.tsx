// Glitch / VHS hit: the picture splits into its red and blue channels, horizontal bands tear sideways,
// scanlines and noise flash over it, and the whole frame jolts. Strongest at the start, gone by the end.
// Randomness is seeded by frame, so the room and the render show the very same glitch.
import {AbsoluteFill, interpolate, random} from 'remotion';
import type {EffectProps} from './types';

export type GlitchProps = {strength?: number; seed?: string};

const BANDS = 7;

export const Glitch: React.FC<EffectProps & GlitchProps> = ({frame, dur, children, strength = 1, seed = 'glitch'}) => {
  const amt = strength * interpolate(frame, [0, 1, dur - 1], [0.7, 1, 0.15], {extrapolateRight: 'clamp'});
  const r = (k: string) => random(`${seed}-${frame}-${k}`) * 2 - 1;   // -1..1
  const split = 26 * amt;
  const jolt = {x: r('jx') * 18 * amt, y: r('jy') * 8 * amt};
  const channel = (id: string, dx: number) => (
    <AbsoluteFill style={{filter: `url(#${id})`, transform: `translateX(${dx}px)`, mixBlendMode: 'screen'}}>{children}</AbsoluteFill>
  );
  return (
    <AbsoluteFill style={{background: 'black', transform: `translate(${jolt.x}px, ${jolt.y}px)`}}>
      <svg width={0} height={0} style={{position: 'absolute'}}>
        <filter id="gl-r"><feColorMatrix type="matrix" values="1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0" /></filter>
        <filter id="gl-g"><feColorMatrix type="matrix" values="0 0 0 0 0  0 1 0 0 0  0 0 0 0 0  0 0 0 1 0" /></filter>
        <filter id="gl-b"><feColorMatrix type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 1 0 0  0 0 0 1 0" /></filter>
        <filter id="gl-noise"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={1} seed={frame} /></filter>
      </svg>
      {channel('gl-r', -split)}
      {channel('gl-g', 0)}
      {channel('gl-b', split)}
      {Array.from({length: BANDS}, (_, k) => {   // torn bands: a slice of the picture shifted sideways
        if (random(`${seed}-${frame}-band-${k}`) > 0.55 * amt + 0.2) return null;
        const top = random(`${seed}-${frame}-top-${k}`) * 92;
        const h = 2 + random(`${seed}-${frame}-h-${k}`) * 9;
        return (
          <AbsoluteFill key={k} style={{clipPath: `inset(${top}% 0 ${Math.max(0, 100 - top - h)}% 0)`,
            transform: `translateX(${r(`bx-${k}`) * 90 * amt}px)`}}>{children}</AbsoluteFill>
        );
      })}
      <AbsoluteFill style={{opacity: 0.35 * amt,
        background: 'repeating-linear-gradient(0deg, rgba(0,0,0,0.55) 0px, rgba(0,0,0,0.55) 2px, transparent 2px, transparent 5px)'}} />
      <svg width={1080} height={1920} style={{position: 'absolute', inset: 0, opacity: 0.22 * amt, mixBlendMode: 'overlay'}}>
        <rect width={1080} height={1920} filter="url(#gl-noise)" />
      </svg>
    </AbsoluteFill>
  );
};
