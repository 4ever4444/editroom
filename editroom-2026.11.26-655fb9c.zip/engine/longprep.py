"""Once per episode, for the "✎ עריכה ידנית" page (stage 12.3): a light copy of each camera on the preview clock.

usage: python engine/longprep.py "videos/<name>"
takes/cams/cam<k>.mp4: 640x360, no sound, a keyframe every half second, from the moment the preview starts (the
sync offsets of analysis/sync.json). The page plays them together under the preview's sound and shows the camera
Ron chose for each span at once, before any render. A video with one camera needs none: the preview is enough.
"""
import subprocess
import sys
from pathlib import Path

import episode
import tools
from media import read_json

ENGINE = Path(__file__).parent


def step(vdir, text, n, of):
    subprocess.run([sys.executable, str(ENGINE / "progress.py"), str(vdir), text, f"{n}/{of}"], check=True)


def outputs(vdir):
    return [Path(vdir) / "takes" / "cams" / f"cam{k}.mp4" for k in range(len(episode.sources(Path(vdir))[0]))]


def main(vdir):
    vdir = Path(vdir)
    cams, _ = episode.sources(vdir)
    sync = read_json(vdir / "analysis" / "sync.json")
    rows = {r["file"]: r for r in sync["files"]}
    t0, t1 = sync["start"], sync["end"]
    (vdir / "takes" / "cams").mkdir(parents=True, exist_ok=True)
    for k, (cam, out) in enumerate(zip(cams, outputs(vdir))):
        step(vdir, f"מכין את מצלמה {k + 1} לתצוגה", k + 1, len(cams))
        part = out.with_suffix(".part.mp4")
        tools._run(tools.FFMPEG, "-y", "-loglevel", "error", "-ss", f"{t0 - rows[cam.name]['offset']:.3f}",
                   "-t", f"{t1 - t0:.3f}", "-i", cam, "-an",
                   "-vf", "scale=640:360:force_original_aspect_ratio=decrease,pad=640:360:(ow-iw)/2:(oh-ih)/2,setsar=1",
                   "-c:v", "libx264", "-preset", "veryfast", "-crf", "28", "-g", "15", "-movflags", "+faststart", part,
                   timeout=6 * 3600)   # an hour of 4K is decoded once
        part.replace(out)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main(sys.argv[1])
