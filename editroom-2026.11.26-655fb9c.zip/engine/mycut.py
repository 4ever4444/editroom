"""Ron's own cut (stage 12.2): review/manual.json "cut", made in the room's "חיתוך" tab, cut without Claude.

usage: python engine/mycut.py "videos/<name>"   (engine/final.py runs it first; round.md runs it before a round)
The pieces Ron kept become the take table (takes/takes.json, the old one backed up): a piece edge he did not touch
stays exactly where it was, an edge he moved snaps to the nearest quiet (cut.py, s/sh/ts/z kept). The text of the new
cut is the room's words inside the pieces, in their order, with his spelling. Then cut.py cuts and transcribes, and
what was timed on the old cut follows the raw moment it stood on: Ron's moved graphics and subtitle fixes, and
graphics.json moments given in seconds. A graphic anchored to a phrase he cut is left out of the render
(render.build_props "lost") and named in the report.
"""
import shutil
import sys
import time
from pathlib import Path

import cut
import manual
from media import probe, read_json, write_json

sys.path.insert(0, str(Path(__file__).parent / "room"))
import rounds  # noqa: E402


def offsets(segs):
    out, t = [], 0.0
    for s, e in segs:
        out.append(t)
        t += e - s
    return out, t


def remap(t, old, new, near=False):
    """A time on the old cut -> the same moment of the raw on the new cut. None when that moment was cut out, or
    (near) the start of the next kept piece of the raw."""
    offs, _ = offsets(old)
    k = max((i for i, o in enumerate(offs) if o <= t + 1e-9), default=0)
    raw = old[k][0] + t - offs[k]
    noffs, total = offsets(new)
    for (s, e), o in zip(new, noffs):
        if s - 1e-6 <= raw < e:
            return round(o + raw - s, 3)
    if not near:
        return None
    later = sorted((s, o) for (s, e), o in zip(new, noffs) if s > raw)
    return round(later[0][1] if later else total, 3)


def cut_text(words, segs, fixes):
    """The new cut's words: the room's words inside each piece, pieces in play order, Ron's spelling over them."""
    mid = lambda w: (w["s"] + w["e"]) / 2
    return " ".join(fixes.get(str(i), w["w"]) for s, e in segs
                    for i, w in sorted(enumerate(words), key=lambda x: x[1]["s"]) if s <= mid(w) < e)


def follow(m, old, new, old_pages, new_pages):
    """Ron's fixes timed on the old cut, moved onto the new one. A fix whose moment was cut out is dropped."""
    m = {**m}
    items = {}
    for i, v in m.get("items", {}).items():
        if i == "title" or "from" not in v:
            items[i] = v
        elif (f := remap(v["from"], old, new)) is not None:
            items[i] = {**v, "from": f}
    m["items"] = items
    pages = {}
    for i, v in m.get("pages", {}).items():
        was = old_pages[int(i)] if int(i) < len(old_pages) else None
        if not was or (t := remap(was["s"], old, new)) is None:
            continue
        same = [(abs(p["s"] - t), k, p) for k, p in enumerate(new_pages) if p["text"] in (v["was"], v.get("text"))]
        if not same or min(same)[0] > 1.5:
            continue
        _, k, p = min(same)
        shift = p["s"] - was["s"]
        pages[str(k)] = {**v, "was": p["text"] if p["text"] != v.get("text") else v["was"],
                         **{x: round(v[x] + shift, 3) for x in ("s", "e") if x in v}}
    m["pages"] = pages
    return {k: x for k, x in m.items() if x != {}}


def apply(vdir, step=print):
    """Cut the video as Ron cut it in the room, if that is not done yet. True when it was cut now."""
    from render import build_props, frame_count
    vdir = Path(vdir)
    m = manual.load(vdir)
    want = m.get("cut")
    es_f, g_f = vdir / "takes" / "edit_segments.json", vdir / "graphics.json"
    es = read_json(es_f)
    # What was timed on the old cut moves to the new one in two files, and a run may stop between them (24.11). So the old
    # clock is kept in room-cut-pending.json until all is done, and each file says in itself ("cutPending", in the same
    # write) that it has moved and onto which cut: the next run, whatever cut it asks for, moves each exactly once.
    pend_f = vdir / "review" / "room-cut-pending.json"
    pend = read_json(pend_f) if pend_f.exists() else None
    if not pend and (not want or es.get("room") == want):
        return False
    edit = vdir / "takes" / "edit.mkv"
    fps = float(probe(edit)["fps"])
    pages = lambda: build_props(vdir, fps, frame_count(edit), mine=False)["pages"]
    if not pend:
        pend = {"id": time.time_ns(), "segments": es["segments"], "pages": pages()}
        write_json(pend_f, pend)
    if want and es.get("room") != want:
        cut_again(vdir, want, pend["segments"], step)
        es = read_json(es_f)
    new = es["segments"]
    moved = lambda x: x["cutPending"] if x.get("cutPending", {}).get("id") == pend["id"] else pend   # the clock a file is on
    g = read_json(g_f)   # moments given in seconds follow the raw; a moment cut out moves to the next kept piece
    for lst in ("motion", "effects", "hf"):
        for x in g.get(lst, []):
            if isinstance(x.get("from"), (int, float)):
                x["from"] = remap(x["from"], moved(g)["segments"], new, near=True)
    mark = {"id": pend["id"], "segments": new}
    write_json(g_f, {**g, "cutPending": mark})
    manual.barrier(vdir, f"cut-{time.time_ns()}")   # kept states are on the old cut: undo stops here (stage c2)
    fixes, new_pages = manual.load(vdir), pages()
    was = moved(fixes)
    manual.write(vdir, {**follow(fixes, was["segments"], new, was["pages"], new_pages), "cutPending": {**mark, "pages": new_pages}})
    write_json(es_f, {**es, "room": want} if want else es)
    pend_f.unlink()   # done: the marks mean nothing without it (another id next time), clearing them is only tidying
    manual.write(vdir, {k: x for k, x in manual.load(vdir).items() if k != "cutPending"})
    write_json(g_f, {k: x for k, x in g.items() if k != "cutPending"})
    return True


def cut_again(vdir, want, old, step):
    """The take table and text of the user's cut, cut and transcribed. old: the pieces their edges were measured on."""
    takes_f, g_f = vdir / "takes" / "takes.json", vdir / "graphics.json"
    words = rounds.read(vdir / "review" / f"round-{rounds.round_numbers(vdir)[-1]}.json")["words"]
    stamp = time.strftime("%Y%m%d-%H%M%S")
    (vdir / "review" / "backup").mkdir(parents=True, exist_ok=True)
    for f in (takes_f, g_f):
        shutil.copy2(f, vdir / "review" / "backup" / f"{f.stem}-{stamp}-before-room-cut.json")
    edges = {round(x, 3) for seg in old for x in seg}
    t = read_json(takes_f)
    write_json(takes_f, {**t, "takes": [[s, e, "החיתוך של רון"] for s, e in want["segments"]],
                         "exact": [x for seg in want["segments"] for x in seg if round(x, 3) in edges],   # untouched edges
                         "text": cut_text(words, want["segments"], want.get("fixes", {})), "by": "room"})
    step("חותך לפי החיתוך שלך ומתמלל אותו")
    cut.main(vdir)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if len(sys.argv) > 1:
        print("cut" if apply(sys.argv[1]) else "nothing to cut")
        sys.exit()
    old = [[0, 4], [10, 14]]            # the cut: raw 0-4, then raw 10-14
    new = [[10, 14], [1, 4]]            # Ron: raw 10-14 first, and raw 0-1 cut away
    assert remap(5, old, new) == 1.0    # raw 11 -> second 1 of the new cut
    assert remap(2, old, new) == 5.0    # raw 2 -> 4 + (2 - 1)
    assert remap(0.5, old, new) is None and remap(0.5, old, new, near=True) == 4.0   # cut out: the next piece (raw 1)
    w = lambda t, s: {"w": t, "s": s, "e": s + 0.4}
    words = [w("שלום", 0.2), w("לכם", 1.5), w("חברים.", 2.5), w("היום", 10.5), w("נדבר.", 12)]
    assert cut_text(words, new, {"1": "לכן"}) == "היום נדבר. לכן חברים."
    page = lambda t, s: {"text": t, "s": s, "e": s + 0.8}
    m = {"items": {"a": {"from": 5, "dur": 1}, "b": {"from": 0.5, "dur": 1}, "title": {"dur": 3}},
         "pages": {"1": {"was": "חברים", "e": 3.0}, "0": {"was": "שלום"}}, "volume": {"voice": -2}}
    got = follow(m, old, new, [page("שלום", 0.2), page("חברים", 2.5), page("היום", 4.5)],
                 [page("היום", 0.5), page("לכן חברים", 4.5)])
    assert got["items"] == {"a": {"from": 1.0, "dur": 1}, "title": {"dur": 3}}, got   # b's moment was cut out
    assert "pages" not in got, got      # "חברים" became "לכן חברים" (Ron's spelling): not the same subtitle
    got = follow(m, old, new, [page("שלום", 0.2), page("חברים", 2.5)], [page("היום", 0.5), page("חברים", 5.5)])
    assert got["pages"] == {"1": {"was": "חברים", "e": 6.0}} and got["volume"] == {"voice": -2}, got
    print("mycut self-check OK")
