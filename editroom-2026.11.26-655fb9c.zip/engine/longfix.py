"""Ron's own fixes on a long video (stage 12.3): a podcast, a long YouTube video, a talk. Same review/manual.json as a
reel (engine/manual.py), locked the same way, made in the "✎ עריכה ידנית" page and rendered by "רנדור מחדש" without
Claude (engine/recut.py). Every time is a second on the preview, the whole recording (takes/episode_preview.mp4).

manual.json, for a long video:
  "trim":   {"from", "to"}                     where the episode starts and ends, over analysis/trim.json
  "cuts":   {"<cut id>": {"s", "e", "apply"}}  over analysis/cuts.json: moved, switched on or off; a new id = his own
  "shots":  [{"s", "e", "cam"}]                the camera over those seconds (0, 1, ... or 99 = everyone side by side)
  "slides": [{"at", "slide"?}]                 a talk's slide changes, instead of analysis/slides.json
  "subs":   {"<cue start>": {"was", "text"?, "s"?, "e"?}}  a subtitle line of episode.srt; its key is the preview second
            its first word starts on (2 decimals), "was" its words as made; a line with neither those words nor his
            (a new transcript) is left alone
"""
import manual

SPLIT = 99


def load(vdir):
    return manual.load(vdir)


def trim(vdir, base):
    """(from, to): Ron's over Claude's."""
    t = load(vdir).get("trim")
    return (t["from"], t["to"]) if t else base


def cuts(base, m):
    """analysis/cuts.json rows with Ron's changes over them, and his own cuts added."""
    mine = m.get("cuts", {})
    out = [{**c, **{k: mine[c["id"]][k] for k in ("s", "e", "apply") if k in mine.get(c["id"], {})}} for c in base]
    known = {c["id"] for c in base}
    out += [{"id": i, "kind": "manual", "why": "חיתוך שלך", "recommended": True, **v} for i, v in mine.items() if i not in known]
    return out


def shots(planned, m):
    """The camera plan with Ron's choices laid over it: each of his spans replaces what was planned there."""
    out = [dict(x) for x in planned]
    for o in sorted(m.get("shots", []), key=lambda x: x["s"]):
        nxt = []
        for x in out:
            if x["e"] <= o["s"] or x["s"] >= o["e"]:
                nxt.append(x)
                continue
            if x["s"] < o["s"]:
                nxt.append({**x, "e": o["s"]})
            if x["e"] > o["e"]:
                nxt.append({**x, "s": o["e"]})
        nxt.append({"cam": o["cam"], "s": o["s"], "e": o["e"]})
        out = sorted(nxt, key=lambda x: x["s"])
    merged = []   # neighbours on the same camera become one shot
    for x in out:
        if merged and merged[-1]["cam"] == x["cam"] and abs(merged[-1]["e"] - x["s"]) < 1e-6:
            merged[-1]["e"] = x["e"]
        elif x["e"] - x["s"] > 1e-6:
            merged.append(x)
    return merged


def slides(base, m):
    return m.get("slides", base)


def cue_fix(cue_words, m):
    """A subtitle line (its words, preview seconds in "ps"/"pe") -> (text, s_preview, e_preview) after Ron's fix."""
    text = " ".join(w["w"] for w in cue_words)
    s, e = cue_words[0]["ps"], cue_words[-1]["pe"]
    v = m.get("subs", {}).get(f"{s:.2f}")
    if not v or text not in (v["was"], v.get("text")):
        return text, s, e
    return v.get("text", text), v.get("s", s), v.get("e", e)


def check(m):
    """The long-video parts of manual.json (manual.check calls it)."""
    num = lambda x: isinstance(x, (int, float)) and not isinstance(x, bool) and x >= 0
    if "trim" in m and not (num(m["trim"].get("from")) and num(m["trim"].get("to")) and m["trim"]["to"] > m["trim"]["from"]):
        raise ValueError("manual: bad trim")
    for i, c in m.get("cuts", {}).items():
        if ("s" in c or "e" in c) and not (num(c.get("s")) and num(c.get("e")) and c["e"] > c["s"]):
            raise ValueError(f"manual: bad cut {i}")
    for x in m.get("shots", []):
        if not (num(x.get("s")) and num(x.get("e")) and x["e"] > x["s"] and (x.get("cam") in range(4) or x.get("cam") == SPLIT)):
            raise ValueError("manual: bad shot")
    if any(not num(x.get("at")) for x in m.get("slides", [])):
        raise ValueError("manual: bad slide time")
    for k, v in m.get("subs", {}).items():
        if "was" not in v or ("text" in v and not str(v["text"]).strip()) or ("s" in v and "e" in v and v["e"] <= v["s"]):
            raise ValueError(f"manual: bad subtitle {k}")


if __name__ == "__main__":
    planned = [{"cam": 0, "s": 0, "e": 10}, {"cam": 1, "s": 10, "e": 20}, {"cam": 99, "s": 20, "e": 25}]
    got = shots(planned, {"shots": [{"s": 8, "e": 12, "cam": 0}, {"s": 21, "e": 25, "cam": 1}]})
    assert got == [{"cam": 0, "s": 0, "e": 12}, {"cam": 1, "s": 12, "e": 20}, {"cam": 99, "s": 20, "e": 21},
                   {"cam": 1, "s": 21, "e": 25}], got
    base = [{"id": "c1", "s": 5, "e": 6, "apply": True, "kind": "repeat"}, {"id": "c2", "s": 9, "e": 10, "apply": False}]
    got = cuts(base, {"cuts": {"c1": {"apply": False}, "c2": {"s": 8.5, "apply": True}, "m1": {"s": 30, "e": 31, "apply": True}}})
    assert [(c["id"], c["s"], c["e"], c["apply"]) for c in got] == [("c1", 5, 6, False), ("c2", 8.5, 10, True), ("m1", 30, 31, True)]
    assert got[2]["kind"] == "manual" and base[0]["apply"] is True
    w = lambda t, s: {"w": t, "ps": s, "pe": s + 0.4}
    m = {"subs": {"3.00": {"was": "שלום לכם", "text": "שלום לכולם", "e": 4.2}}}
    assert cue_fix([w("שלום", 3.0), w("לכם", 3.4)], m) == ("שלום לכולם", 3.0, 4.2)
    assert cue_fix([w("שלום", 3.0), w("לכולם", 3.4)], m) == ("שלום לכולם", 3.0, 4.2)   # the transcript fixed already
    assert cue_fix([w("משהו", 3.0)], m) == ("משהו", 3.0, 3.4)                          # another line now: left alone
    for bad in ({"trim": {"from": 5, "to": 2}}, {"shots": [{"s": 1, "e": 2, "cam": 7}]}, {"cuts": {"x": {"s": 3, "e": 1}}},
                {"slides": [{"at": -1}]}, {"subs": {"1.00": {"text": "x"}}}):
        try:
            check(bad)
            raise AssertionError(bad)
        except ValueError:
            pass
    print("longfix self-check OK")
