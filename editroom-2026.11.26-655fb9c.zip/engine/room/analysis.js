// Analysis: what the pipeline found in one video, from the files it already writes (areas.video_analysis).
const $ = (s) => document.querySelector(s);
const el = (tag, cls, text) => Object.assign(document.createElement(tag), {className: cls || '', textContent: text ?? ''});

function stat(label, value) {
  const d = el('div', 'stat');
  d.append(el('span', '', label), el('b', '', value));
  return d;
}

const clock = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

// The moment becomes a new reel or story video (vertical, cut by speaker); it then waits on the home page like any raw.
const KIND = {reel: ['ליצור ריל מהרגע הזה', 'שם לריל החדש', 'הריל'], story: ["ליצור סטורי (6-15 שנ')", 'שם לסטורי החדש', 'הסטורי']};
async function makeReel(video, h, btn, kind) {
  const name = prompt(KIND[kind][1],`${video} · ${h.title}`.replace(/[\\/:*?"<>|.]/g, ' ').slice(0, 60).trim());
  if (!name) return;
  btn.disabled = true;
  const r = await fetch(`/api/reel?video=${encodeURIComponent(video)}&from=${h.start}&to=${h.end}&type=${kind}`
    + `&name=${encodeURIComponent(name)}&note=${encodeURIComponent(`רגע מהפרק "${video}": ${h.title}. למה הוא נבחר: ${h.why}`)}`, {method: 'POST'});
  const res = await r.json();
  btn.textContent = r.ok ? `נשלח: ${KIND[kind][2]} נחתך ועובר לקלוד. בדף הבית תראה את ההתקדמות, ובסוף "מחכה לך"` : res.error;
  if (!r.ok) btn.disabled = false;
}

function show(a) {
  const facts = $('#facts');
  facts.replaceChildren(el('h2', '', 'מה נמדד'));
  if (a.progress) facts.append(stat('השלב האחרון', `${a.progress.step}${a.progress.n ? ` (${a.progress.n})` : ''}`));
  if (a.words != null) facts.append(stat('מילים בתמלול', a.words.toLocaleString('he')));
  if (a.segments != null) facts.append(stat('קטעים שנשארו בעריכה', a.segments));
  if (a.kept_seconds != null) facts.append(stat('אורך אחרי חיתוך', `${a.kept_seconds} שנ'`));
  // a version the room made from another reel (short, business, ad) carries instructions for Claude, not the user's words
  if (a.brief?.note && !a.brief.cutdown_of && !a.brief.ad && !a.brief.style) facts.append(stat('מה ביקשת', a.brief.note));
  if (facts.children.length === 1) facts.append(el('p', 'hint', 'קלוד עוד לא התחיל לעבוד על הסרטון הזה.'));

  const long = window.LONG_TYPES.includes(a.brief?.type);   // who speaks and the moments for reels: long material only
  $('#speakers').hidden = !long && !a.speakers?.length;
  $('#highlights').hidden = !long && !a.highlights?.length;
  const sp = $('#speakers');
  sp.replaceChildren(el('h2', '', 'מי מדבר מתי'));
  if (a.speakers?.length) {
    for (const s of a.speakers) sp.append(stat(s.name, `${s.share}% מהזמן · ${s.camera}`));
  } else {
    sp.append(el('p', 'soon-note', 'יופיע אחרי שקלוד יערוך את הסרטון: מי מדבר בכל רגע, ולאיזו מצלמה עוברים.'));
  }

  const hl = $('#highlights');
  hl.replaceChildren(el('h2', '', 'רגעים חזקים לרילסים'));
  if (a.highlights?.length) {
    for (const h of [...a.highlights].sort((x, y) => y.score - x.score)) {
      const d = el('div', 'lesson');
      d.append(el('b', '', `${h.score} · ${h.title}`),
        el('p', '', `${clock(h.start)}–${clock(h.end)} · ${h.why} · ביטחון ${h.confidence}`));
      if (h.hook) d.append(el('p', 'hint', `פותח ב: "${h.hook}"`));
      for (const kind of a.brief?.outputs || ['reel', 'story']) {   // what Ron asked for when he opened the episode
        const make = el('button', '', KIND[kind][0]);
        make.onclick = () => makeReel(a.name, h, make, kind);
        d.append(make);
      }
      hl.append(d);
    }
  } else {
    hl.append(el('p', 'soon-note', 'יופיעו אחרי שקלוד יערוך את הסרטון: רגעים לרילסים, עם ציון, נימוק ורמת ביטחון, ואתה תבחר.'));
  }

  const rep = $('#report');
  rep.replaceChildren(el('h2', '', 'הדוח של קלוד'));
  if (!a.report) return rep.append(el('p', 'hint', 'אין עדיין דוח לסרטון הזה.'));
  rep.append(el('p', '', a.report.summary));
  for (const sec of a.report.sections || []) {
    const det = document.createElement('details');
    det.append(el('summary', '', sec.title));
    const ul = document.createElement('ul');
    for (const it of sec.items || []) ul.append(el('li', '', typeof it === 'string' ? it : JSON.stringify(it)));
    det.append(ul);
    rep.append(det);
  }
}

async function load(name) {
  history.replaceState(null, '', `?video=${encodeURIComponent(name)}`);
  const r = await fetch(`/api/analysis?video=${encodeURIComponent(name)}`);
  if (r.ok) show(await r.json());
}

const {videos} = await (await fetch('/api/videos')).json();
const want = new URLSearchParams(location.search).get('video');
for (const v of videos) $('#video').append(Object.assign(document.createElement('option'), {value: v.name, textContent: v.name, selected: v.name === want}));
$('#video').onchange = () => load($('#video').value);
if (videos.length) load($('#video').value);
else $('#facts').replaceChildren(el('p', 'hint', 'עוד אין סרטונים.'));
