// Effects and animations: the room's own effects (engine/remotion/src/effects/index.ts), each playing on Ron's
// newest cut, and the studio's effects (engine/studio), each playing its own live demo.
const $ = (s) => document.querySelector(s);
const FPS = 30, AT = 0.8, TAIL = 0.8;   // a room loop: 0.8s before the effect, the effect, 0.8s after
const FAMILY = {transition: 'מעברים', type: 'טקסט וכותרות', shape: 'צורות', light: 'אור', data: 'נתונים'};
const FILTERS = [['all', 'הכול'], ['room', 'על התמונה'], ...Object.entries(FAMILY)];
const LOOP_GAP = 450;

function card(group, family, title, does) {
  const c = document.createElement('article');
  c.className = 'fxcard';
  c.dataset.group = group;
  c.innerHTML = '<div class="stage"></div><div class="fxmeta"><span class="fam"></span><h3></h3><p></p></div>';
  c.querySelector('.fam').textContent = family;
  c.querySelector('h3').textContent = title;
  c.querySelector('p').textContent = does;
  $('#cards').append(c);
  return c;
}

function roomCards(sample) {
  for (const [kind, fx] of Object.entries(window.RoomLayers.catalog)) {
    const c = card('room', `${fx.family} · של החדר`, fx.title, fx.does);
    const stage = c.querySelector('.stage');
    stage.className = 'fxplayer';
    stage.dir = 'ltr';   // a Remotion player in an RTL page is pushed out of its frame (CLAUDE.md, 19.10)
    const meta = c.querySelector('.fxmeta');
    meta.append(Object.assign(document.createElement('code'), {textContent: `בהערה: ${fx.ask}`}));
    const more = document.createElement('details');
    more.innerHTML = '<summary>אפשר לכוון</summary><ul></ul>';
    for (const [prop, what] of Object.entries(fx.props)) {
      more.querySelector('ul').append(Object.assign(document.createElement('li'), {textContent: `${prop}: ${what}`}));
    }
    meta.append(more);
    if (!sample) continue;
    window.RoomLayers.mount(stage, {
      video: sample.video, raw: sample.raw, fps: FPS, durationInFrames: Math.round((AT + fx.dur + TAIL) * FPS), pages: [], title: [''],
      titleEnd: 0, hidden: ['title'], graphics: [],
      effects: [{id: `demo-${kind}`, kind, from: Math.round(AT * FPS), dur: Math.round(fx.dur * FPS), props: fx.demo}],
    }, {controls: true, loop: true});
  }
}

async function studioCards() {
  let data;
  try { data = await (await fetch('/api/studio-effects')).json(); } catch { return; }
  if (!data.effects) return;
  window.I18N = {t: (k) => data.strings[k] ?? ''};   // fx-demos.js reads its sample words through I18N
  await new Promise((ok) => document.head.append(Object.assign(document.createElement('script'), {src: '/studio/fx-demos.js', onload: ok, onerror: ok})));
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const seen = new IntersectionObserver((rows) => rows.forEach((r) => r.target.classList.toggle('visible', r.isIntersecting)));
  for (const fx of data.effects) {
    const c = card(fx.category, `${FAMILY[fx.category] || fx.category} · מהסטודיו`, fx.name, fx.desc);
    c.querySelector('.fxmeta').append(Object.assign(document.createElement('p'), {textContent: `בהערה: \"אפקט סטודיו: ${fx.demo}\" + על איזו מילה. קלוד בונה אותו לסרטון.`}));
    const stage = c.querySelector('.stage');
    stage.className = 'fx-stage';
    const play = window.FxDemos?.[fx.demo];
    if (!play) continue;
    seen.observe(c);
    (async () => {   // loop the demo while the card is on screen; one still frame when motion is reduced
      while (true) {
        if (!reduced && !c.classList.contains('visible')) { await new Promise((ok) => setTimeout(ok, 500)); continue; }
        stage.textContent = '';
        try { await play(stage, window.FxDemos.context({still: reduced})); } catch { return; }
        if (reduced) return;
        await new Promise((ok) => setTimeout(ok, LOOP_GAP));
      }
    })();
  }
}

for (const [id, label] of FILTERS) {
  const b = Object.assign(document.createElement('button'), {className: 'chip-filter', textContent: label});
  b.setAttribute('aria-pressed', id === 'all');
  b.onclick = () => {
    document.querySelectorAll('.chip-filter').forEach((x) => x.setAttribute('aria-pressed', x === b));
    document.querySelectorAll('.fxcard').forEach((c) => { c.hidden = id !== 'all' && c.dataset.group !== id; });
  };
  $('#filters').append(b);
}

const r = await fetch('/api/catalog-sample');
const sample = r.ok ? await r.json() : null;
$('#sample').textContent = sample ? `האפקטים של החדר מתנגנים על "${sample.name}". כל אפקט אומר מה לכתוב בהערה כדי לקבל אותו.`
  : 'עוד אין סרטון ערוך להראות עליו את האפקטים של החדר.';
roomCards(sample);
studioCards();
