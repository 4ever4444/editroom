"""How a video was before a job (stage b2, docs/stop-spec*.md): kept while the job runs, so that stopping it brings the
video back to exactly that.

<data>/before/<entry id>/: files/<path in the video>, shared/<n>, and manifest.json, written last (without it there is no
snapshot). Only graphics.json and the six work folders are ever kept, brought back or deleted from; the raw footage, the
cameras, the sound and the presentations are never touched, wherever they are.
"""
import filecmp
import hashlib
import json
import logging
import os
import shutil
import time
from pathlib import Path

import jobs
import paths
import update
from media import part_of, swap_in
from rounds import now, read, write_atomic

FULL = ("first", "round", "final", "recut", "long_first")   # these write all over the video's work folders
ONE_FILE = {"post": "final/posts.json", "learn": "style-card.md"}
NOTHING = ("pieces", "prep")   # written aside and swapped in whole: ending them leaves only the half file, deleted
BUILDS = ("first", "round", "long_first")   # they may build shared graphics, effects and sounds, and write what was learned
DIRS = ("takes", "final", "hf", "analysis", "transcript", "review")
LINKED = ("takes/source.mkv", "final/episode.mp4", "takes/episode_preview.mp4", "final/qa.mp4", "final/best_of.mp4")
LINKED_DIR = "final/lessons/"   # big, and only ever swapped in whole: a link costs nothing, and the swap does not touch it
NOT_OURS = ("final/exports/", "final/nle/", "review/jobs/", "review/backup/", "transcript/parts/", "review/thumb.jpg",
            "review/brief.json", "review/job.json", "review/progress.json", "review/queued.json", "review/queued.bad.json",
            "review/queue-note.json", "review/lessons-due")
SPARE = 2 * 2**30   # free space left over the copies, or the job runs without a snapshot
WAIT_S = 10   # a file a page plays is asked for again this long


class Busy(Exception):
    """Some file could not be brought back yet (a page plays it)."""


def root():
    return paths.DATA / "before"


def folder(entry_id):
    return root() / entry_id


def ours(rel, kind):
    """Is this path of a video part of what a job of this kind changes? (The same for keeping and for deleting.)"""
    if rel.startswith(NOT_OURS):
        return False
    return not (rel == "final/posts.json" and kind in ("final", "recut"))   # they never write it, and the user may


def stays(rel, kind):
    """What is left as the job made it: a transcript costs up to an hour, and the next try goes on from it (decision 10)."""
    return kind in ("first", "long_first") and rel.startswith("transcript/")


def walk(vdir, kind):
    """{path in the video: file}, without following links out of it."""
    if kind in ONE_FILE:
        f = vdir / ONE_FILE[kind]
        return {ONE_FILE[kind]: f} if f.is_file() else {}
    if kind not in FULL:
        return {}
    found = {}
    if (vdir / "graphics.json").is_file():
        found["graphics.json"] = vdir / "graphics.json"
    for d in DIRS:
        for base, dirs, files in os.walk(vdir / d):
            dirs[:] = [x for x in dirs if not (Path(base) / x).is_symlink() and not os.path.isjunction(Path(base) / x)]
            for name in files:
                f = Path(base) / name
                rel = f.relative_to(vdir).as_posix()
                if ours(rel, kind) and not f.is_symlink():
                    found[rel] = f
    return found


def shared_data():
    return [paths.LESSONS, paths.GRAPHICS_LOG, paths.WISHLIST]


def shared_code():
    """The code a job may build in. On an installed computer it is brought back; in Ron's git folder it never is (others
    work there at the same time): what changed is only named."""
    e = paths.APP / "engine"
    files = [*e.glob("*.py"), *(f for f in (e / "room").iterdir() if f.suffix in (".py", ".js", ".css", ".html")),
             *(f for f in (e / "remotion" / "src").rglob("*") if f.is_file()), *(paths.LIBRARY / "sfx").glob("*.wav"), paths.APP / "CLAUDE.md"]
    return [f for f in files if f.is_file()]


def digest(f):
    return hashlib.sha1(f.read_bytes()).hexdigest()


def take(entry_id, name, kind):
    """Keep how it is now. Raises (OSError, ...) when it cannot: the job then runs without a way to stop it."""
    d, vdir = folder(entry_id), jobs.files(name)[0].parent.parent
    (d / "manifest.json").unlink(missing_ok=True)   # first: what is left of an earlier try of this entry counts for nothing
    if d.exists():
        shutil.rmtree(d)
    files = walk(vdir, kind)
    link = {r for r in files if r in LINKED or r.startswith(LINKED_DIR)}
    need = sum(f.stat().st_size for r, f in files.items() if r not in link)
    if shutil.disk_usage(paths.DATA).free < 2 * need + SPARE:
        raise OSError("אין מספיק מקום פנוי בדיסק לשמור את המצב שלפני העבודה")
    d.mkdir(parents=True)
    kept = {}
    for rel, f in files.items():
        out = d / "files" / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        how = "copy"
        if rel in link:
            try:
                os.link(f, out)
                how = "link"
            except OSError:   # a disk without hard links
                if shutil.disk_usage(paths.DATA).free < f.stat().st_size + SPARE:
                    raise
        if how == "copy":
            shutil.copy2(f, out)
        st = out.stat()
        kept[rel] = {"how": how, "size": st.st_size, "mtime": st.st_mtime_ns}
    data, code = {}, {}
    if kind in BUILDS:
        (d / "shared").mkdir()
        back = [*shared_data(), *([f for f in shared_code() if f.name != "CLAUDE.md"] if paths.HOME else [])]
        for k, f in enumerate(back):
            if f.exists():
                shutil.copy2(f, d / "shared" / str(k))
            data[str(f)] = str(k) if f.exists() else None
        code = {str(f): digest(f) for f in shared_code() if str(f) not in data}
    write_atomic(d / "manifest.json", {"entryId": entry_id, "name": name, "kind": kind, "at": now(), "files": kept,
                                       "shared": data, "code": code, "version": update.current().get("version", "local")})


def manifest(entry_id):
    f = folder(entry_id) / "manifest.json"
    return read(f) if f.exists() else None


def put(src, dst, how):
    """One file back where it was, with its time; whole, or written into when a page plays the one there now."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = part_of(dst)
    tmp.unlink(missing_ok=True)
    if how == "link":
        os.link(src, tmp)
    else:
        shutil.copy2(src, tmp)
    swap_in(tmp, dst, tries=4)
    st = src.stat()
    os.utime(dst, ns=(st.st_atime_ns, st.st_mtime_ns))


def same(src, dst, how):
    if not dst.exists():
        return False
    if how == "link":
        return os.path.samefile(src, dst)
    return filecmp.cmp(src, dst, shallow=False) and src.stat().st_mtime_ns == dst.stat().st_mtime_ns


def restore(entry_id):
    """The video as the manifest has it. Returns what was not brought back, in words. Running it again does no harm.
    Raises Busy when some file is still held by something; the rest is already back."""
    m = manifest(entry_id)
    d, vdir, kind = folder(entry_id), jobs.files(m["name"])[0].parent.parent, m["kind"]
    left, held = [], []
    for rel, k in m["files"].items():
        src, dst = d / "files" / rel, vdir / rel
        if stays(rel, kind) and dst.exists():
            continue
        st = src.stat()
        if k["how"] == "link" and (st.st_size, st.st_mtime_ns) != (k["size"], k["mtime"]):   # written in place: the link changed too
            left.append(rel)
            continue
        try:
            if not same(src, dst, k["how"]):
                put(src, dst, k["how"])
        except OSError as e:
            held.append(f"{rel}: {e}")
    for rel, f in walk(vdir, kind).items():
        if rel not in m["files"] and not stays(rel, kind):
            try:
                f.unlink()
            except OSError as e:
                held.append(f"{rel}: {e}")
    if kind in NOTHING:   # what it was writing aside
        for f in [*(vdir / "final").rglob("*.part.*"), *(vdir / "takes" / "cams").glob("*.part.*")]:
            try:
                f.unlink()
            except OSError as e:
                held.append(f"{f.name}: {e}")
    here = update.current().get("version", "local") == m.get("version")
    own = {str(p) for p in shared_data()}
    for path, n in m["shared"].items():
        f = Path(path)
        if path not in own and not here:
            continue   # another version of the code since: it is not this job's any more
        try:
            if n is None:
                f.unlink(missing_ok=True)
            elif not same(d / "shared" / n, f, "copy"):
                put(d / "shared" / n, f, "copy")
        except OSError as e:
            held.append(f"{f.name}: {e}")
    left += [Path(p).name for p, was in m["code"].items() if Path(p).is_file() and digest(Path(p)) != was]
    if held:
        raise Busy("; ".join(held[:3]))
    return left


def restore_patiently(entry_id):
    end = time.monotonic() + WAIT_S
    while True:
        try:
            return restore(entry_id)
        except Busy:
            if time.monotonic() > end:
                raise
            time.sleep(0.5)


def drop(entry_id):
    """The job is over: how it was before is not needed. Never a reason for anything else to fail."""
    if not entry_id or not folder(entry_id).exists():
        return
    d = folder(entry_id)
    try:
        (d / "manifest.json").unlink(missing_ok=True)
        shutil.rmtree(d)
    except OSError:
        logging.warning("a snapshot was not deleted, it goes at the next start: %s", d)


if __name__ == "__main__":
    print(json.dumps([p.name for p in root().iterdir()] if root().is_dir() else []))
