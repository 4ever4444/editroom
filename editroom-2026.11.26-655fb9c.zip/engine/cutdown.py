"""Short versions of a reel (stage 5.4): 30, 15 and 6 seconds, each a new video that Claude edits from the same raw.

usage: python engine/cutdown.py "videos/<name>" 30 15 6 | business
Each version is videos/<name> · <n> שנ'/ with the raw (a hard link: no copy on disk) and the transcript (so it is not
transcribed again), and a brief that tells the edit its length and what to keep. The reel machine (first.md) does
the rest; verify.py checks the brief's length instead of 30-60 s.
"""
import os
import shutil
import sys
from pathlib import Path

from media import read_json, write_json

KEEP = {30: "הפתיחה החזקה, המסר המרכזי והקריאה לפעולה; לוותר על דוגמאות והסברים משניים",
        15: "הפתיחה והמסר המרכזי במשפט אחד, וקריאה לפעולה קצרה אם נכנסת",
        6: "רק הפתיחה החזקה ביותר (משפט אחד), עם הכותרת: סרטון 'פרסומת' שגורם לרצות לראות את המלא"}


def bounds(seconds):
    """The length a short version must land in: a little room under the target, never over it."""
    return [max(3, round(seconds * 0.8)), seconds]


def new_from(vdir, suffix):
    """A new video beside the reel, sharing its raw (hard links) and its transcript."""
    new = vdir.parent / f"{vdir.name} · {suffix}"
    if new.exists():
        raise FileExistsError(new.name)
    for sub in ("raw", "transcript", "takes", "final", "review"):
        (new / sub).mkdir(parents=True)
    for f in (vdir / "raw").iterdir():   # the raw is never copied: a hard link is the same file on disk
        if f.is_file():
            try:
                os.link(f, new / "raw" / f.name)
            except OSError:
                shutil.copy2(f, new / "raw" / f.name)
    for f in (vdir / "transcript").glob("*"):
        if f.is_file():
            shutil.copy2(f, new / "transcript" / f.name)
    return new


def make(vdir, seconds):
    vdir = Path(vdir)
    new = new_from(vdir, f"{seconds} שנ'")
    lo, hi = bounds(seconds)
    parent = read_json(vdir / "review" / "brief.json") if (vdir / "review" / "brief.json").exists() else {}
    write_json(new / "review" / "brief.json", {
        "type": "reel", "cutdown_of": vdir.name, "length": [lo, hi],
        "note": f"גרסה קצרה של {seconds} שניות מתוך הריל \"{vdir.name}\" ({lo}-{hi} שנ'). להשאיר: {KEEP.get(seconds, KEEP[15])}. "
                f"אותו סגנון, אותה כותרת אם היא נכנסת. התמלול כבר קיים ב-transcript, אין צורך לתמלל שוב."
                + (f" מהבריף המקורי: {parent['note']}" if parent.get("note") else "")})
    return new


def business(vdir):
    """Stage 11.4 (Ron 20.11: LinkedIn is the business network): the same reel edited again in a calm, professional
    style (first.md, "A business version"), as its own video "<name> · לינקדאין"."""
    vdir = Path(vdir)
    new = new_from(vdir, "לינקדאין")
    parent = read_json(vdir / "review" / "brief.json") if (vdir / "review" / "brief.json").exists() else {}
    write_json(new / "review" / "brief.json", {
        "type": "reel", "cutdown_of": vdir.name, "style": "business",
        "note": f"גרסה עסקית ללינקדאין מתוך הריל \"{vdir.name}\": אותו תוכן, בסגנון רגוע ומקצועי (first.md, A business version). "
                "התמלול כבר קיים ב-transcript, אין צורך לתמלל שוב." + (f" מהבריף המקורי: {parent['note']}" if parent.get("note") else "")})
    return new


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for s in sys.argv[2:]:
        print(business(sys.argv[1]) if s == "business" else make(sys.argv[1], int(s)))
