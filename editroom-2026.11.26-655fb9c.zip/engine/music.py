"""Music under a reel (stage 4.2): a catalog of the songs Ron is allowed to use, and a ducked music bed.

usage: python engine/music.py catalog           (re-measure library/music, keep Ron's notes and licences)
       python engine/music.py bed "videos/<name>"   (graphics.json "music" -> takes/music_bed.wav)

library/music/<song>.<mp3|wav|m4a|ogg|flac>; a licence note beside it as <song>.txt goes into the catalog.
graphics.json "music": {"file": "<song file>", "start": <seconds into the song>, "level_db": <0 = default>}.
The bed is the song alone, looped if short, faded in and out, under the speech by BED_LUFS, and pushed down
further whenever someone speaks (sidechain from the cut's own voice). render.py mixes it in; the room plays it.
"""
import json
import re
import sys
from pathlib import Path

import av
import numpy as np

import manual
import paths
from media import SR, ffmpeg, load_audio, probe, read_json, write_json

LIBRARY = paths.MUSIC
AUDIO = {".mp3", ".wav", ".m4a", ".ogg", ".flac"}
BED_LUFS = -20.0      # the song's loudness before ducking: 6 dB under -14 LUFS speech; ~12-14 dB under while someone speaks
FADE_IN, FADE_OUT = 1.0, 2.0
# sidechain: speech above ~-30 dBFS pulls the music down by ~6-8 dB, back within 0.4 s of a pause
DUCK = "sidechaincompress=threshold=0.03:ratio=4:attack=15:release=400"


def loudness(path):
    log = ffmpeg("-i", path, "-vn", "-af", "loudnorm=print_format=json", "-f", "null", "-", capture=True)
    return float(json.loads(re.findall(r"\{[^{}]*\}", log)[-1])["input_i"])


def bpm(path):
    """Tempo from the beat of the low end: autocorrelation of the onset strength, 70-180 BPM."""
    a = load_audio(path)[: SR * 90]
    n = SR // 100
    frames = a[: len(a) // n * n].reshape(-1, n)
    env = np.log1p(np.abs(np.fft.rfft(frames, axis=1))[:, :40].sum(1))   # up to ~4 kHz, per 10 ms
    onset = np.maximum(np.diff(env), 0)
    onset -= onset.mean()
    ac = np.correlate(onset, onset, "full")[len(onset) - 1:]
    lags = np.arange(int(6000 / 180), int(6000 / 70) + 1)   # 100 frames/s: lag = 6000 / bpm
    return round(6000 / lags[int(np.argmax(ac[lags]))])


def catalog(lib=LIBRARY):
    """library/music/catalog.json: one row per song, measured; Ron's own fields (licence, mood, notes) kept."""
    lib.mkdir(parents=True, exist_ok=True)
    out = lib / "catalog.json"
    old = {r["file"]: r for r in (read_json(out) if out.exists() else [])}
    rows = []
    for f in sorted(p for p in lib.iterdir() if p.suffix.lower() in AUDIO):
        r = dict(old.get(f.name, {}))
        with av.open(str(f)) as c:
            r["duration"] = round(c.duration / av.time_base, 1)
        r.update(file=f.name, lufs=round(loudness(f), 1), bpm=bpm(f))
        note = f.with_suffix(".txt")
        if note.exists():
            r["license"] = note.read_text(encoding="utf-8").strip()
        r.setdefault("license", "")
        rows.append(r)
    write_json(out, rows)
    return rows


def bed(vdir, lib=LIBRARY):
    """takes/music_bed.wav for graphics.json "music"; removes a stale bed when the music was taken off."""
    vdir = Path(vdir)
    out = vdir / "takes" / "music_bed.wav"
    g = read_json(vdir / "graphics.json") if (vdir / "graphics.json").exists() else {}
    m = manual.music(g, manual.load(vdir))   # Ron's song and level (stage 12.1) over Claude's
    if not m:
        out.unlink(missing_ok=True)
        return None
    song = lib / m["file"]
    rows = {r["file"]: r for r in (read_json(lib / "catalog.json") if (lib / "catalog.json").exists() else [])}
    if song.name not in rows or not song.exists():
        raise SystemExit(f"השיר {m['file']} לא נמצא בקטלוג המוזיקה (library/music). אחרי שמוסיפים שיר: music.py catalog")
    edit = vdir / "takes" / "edit.mkv"
    dur = probe(edit)["duration"]
    gain = BED_LUFS - rows[song.name]["lufs"] + float(m.get("level_db", 0))
    ffmpeg("-i", edit, "-stream_loop", "-1", "-ss", f"{float(m.get('start', 0)):.3f}", "-i", song,
           "-filter_complex",
           f"[1:a]aresample=48000,aformat=channel_layouts=stereo,volume={gain:.2f}dB,atrim=0:{dur:.3f},"
           f"afade=t=in:d={FADE_IN},afade=t=out:st={max(0.0, dur - FADE_OUT):.3f}:d={FADE_OUT}[m];"
           f"[0:a]aresample=48000,aformat=channel_layouts=stereo,apad[v];[m][v]{DUCK},apad[bed]",   # apad: a short voice track never ends the bed early
           # the ducker drops its last frames now and then when one input ends first (under load, up to a second,
           # 18.11): apad fills with silence, which is what the fade-out ends on anyway, and -t cuts it exact
           "-map", "[bed]", "-t", f"{dur:.3f}", "-c:a", "pcm_s16le", out)
    return out


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if sys.argv[1] == "catalog":
        for r in catalog():
            print(f"{r['file']}: {r['duration']}s, {r['bpm']} BPM, {r['lufs']} LUFS, licence: {r['license'] or 'חסר'}")
    else:
        print(bed(sys.argv[2]) or "no music in graphics.json")
