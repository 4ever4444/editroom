"""What differs between Windows and Mac, in one place (stage 13.2, docs/install-spec.md 3.3)."""
import ctypes
import os
import re
import subprocess
import sys
import time

WINDOWS = os.name == "nt"
NPX = "npx.cmd" if WINDOWS else "npx"


def open_path(p):
    """Show a folder (or open a file) in Explorer / Finder."""
    if WINDOWS:
        os.startfile(p)
    else:
        subprocess.Popen(["open", str(p)])


def signer(p):
    """Who signed a downloaded program (Windows: Authenticode; a Mac: codesign), or None when it is not validly
    signed. Before the room opens an installer it downloaded (Google Drive, 23.11)."""
    try:
        if WINDOWS:
            r = subprocess.run(["powershell", "-NoProfile", "-Command",
                                f"$s = Get-AuthenticodeSignature -LiteralPath '{p}'; if ($s.Status -eq 'Valid') {{ $s.SignerCertificate.Subject }}"],
                               capture_output=True, text=True, timeout=60, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            return r.stdout.strip() or None
        r = subprocess.run(["codesign", "-dv", "--verbose=2", str(p)], capture_output=True, text=True, timeout=60)
        auth = [line.split("=", 1)[1] for line in r.stderr.splitlines() if line.startswith("Authority=")]
        return auth[0] if r.returncode == 0 and auth else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def pid_alive(pid):
    """Is this process still running? (On Windows os.kill would end it.)"""
    if not pid:
        return False
    if not WINDOWS:
        try:
            os.kill(int(pid), 0)
            return True
        except (ProcessLookupError, PermissionError, ValueError):
            return False
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(0x1000, False, int(pid))   # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return False
    code = ctypes.c_ulong()
    k32.GetExitCodeProcess(h, ctypes.byref(code))
    k32.CloseHandle(h)
    return code.value == 259   # STILL_ACTIVE


def pid_start(pid):
    """When this process was created, as a mark that a later process reusing its number will not have; None = unknown."""
    if not pid or not pid_alive(pid):
        return None
    if not WINDOWS:
        try:
            r = subprocess.run(["ps", "-o", "lstart=", "-p", str(int(pid))], capture_output=True, text=True, timeout=10)
        except (OSError, ValueError, subprocess.TimeoutExpired):
            return None
        return r.stdout.strip() or None
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(0x1000, False, int(pid))
    if not h:
        return None
    t = [ctypes.c_ulonglong() for _ in range(4)]   # created, exited, kernel, user
    ok = k32.GetProcessTimes(h, *(ctypes.byref(x) for x in t))
    k32.CloseHandle(h)
    return str(t[0].value) if ok and t[0].value else None


def boot_time():
    """When the computer was started, in seconds since 1970 (what ran before that is gone), or 0 when unknown."""
    if WINDOWS:
        tick = ctypes.windll.kernel32.GetTickCount64
        tick.restype = ctypes.c_ulonglong
        return time.time() - tick() / 1000
    try:
        r = subprocess.run(["sysctl", "-n", "kern.boottime"], capture_output=True, text=True, timeout=10)
        return float(re.search(r"sec = (\d+)", r.stdout).group(1))
    except (OSError, AttributeError, subprocess.TimeoutExpired):
        return 0.0


def lock_file(p):
    """Hold p for as long as this process lives (two rooms on one data folder): the open file, or None when another
    process has it. The caller keeps what it gets; the system lets go of it when the process ends, however it ends."""
    f = open(p, "a+b")
    try:
        if WINDOWS:
            import msvcrt
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return f
    except OSError:
        f.close()
        return None


# ---- a job and everything it starts, as one thing that can be ended (stage b2; Windows only)
class _Accounting(ctypes.Structure):
    _fields_ = [("times", ctypes.c_longlong * 4), ("faults", ctypes.c_uint32), ("total", ctypes.c_uint32),
                ("active", ctypes.c_uint32), ("terminated", ctypes.c_uint32)]


class _Limits(ctypes.Structure):
    _fields_ = [("process_time", ctypes.c_longlong), ("job_time", ctypes.c_longlong), ("flags", ctypes.c_uint32),
                ("min_set", ctypes.c_size_t), ("max_set", ctypes.c_size_t), ("processes", ctypes.c_uint32),
                ("affinity", ctypes.c_size_t), ("priority", ctypes.c_uint32), ("scheduling", ctypes.c_uint32),
                ("io", ctypes.c_ulonglong * 6), ("memory", ctypes.c_size_t * 4)]


def _kernel():
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    H, D = ctypes.c_void_p, ctypes.c_uint32
    for f, res, args in (("CreateJobObjectW", H, [H, ctypes.c_wchar_p]), ("OpenJobObjectW", H, [D, ctypes.c_int, ctypes.c_wchar_p]),
                         ("AssignProcessToJobObject", ctypes.c_int, [H, H]), ("TerminateJobObject", ctypes.c_int, [H, D]),
                         ("SetInformationJobObject", ctypes.c_int, [H, ctypes.c_int, H, D]),
                         ("QueryInformationJobObject", ctypes.c_int, [H, ctypes.c_int, H, D, H]),
                         ("DuplicateHandle", ctypes.c_int, [H, H, H, ctypes.POINTER(H), D, ctypes.c_int, D]),
                         ("GetCurrentProcess", H, []), ("CloseHandle", ctypes.c_int, [H])):
        fn = getattr(k, f)
        fn.restype, fn.argtypes = res, args
    return k


def group_name(job_id):
    return f"Local\\editroom-{job_id}"


def spawn(cmd, job_id, **kw):
    """Start a job's process, not running yet. Returns (Popen, group, resume): group = the name its whole tree can be
    ended by (end_group), or None when it cannot (a Mac, a computer that refuses); the job runs either way. resume()
    lets it begin, and raises OSError, with the process gone, when it cannot.

    The group's only handle is inside the process itself: its name lives as long as the process does, also when this room
    is closed, and when the process ends the system ends whatever it left behind."""
    if not WINDOWS:
        return subprocess.Popen(cmd, start_new_session=True, **kw), None, lambda: None
    k, name = _kernel(), group_name(job_id)
    h = k.CreateJobObjectW(None, name)
    p = subprocess.Popen(cmd, **{**kw, "creationflags": kw.get("creationflags", 0) | 0x4})   # CREATE_SUSPENDED
    inside, limits = ctypes.c_void_p(), _Limits(flags=0x2000)   # KILL_ON_JOB_CLOSE, only once its handle is safely inside
    grouped = bool(h and k.AssignProcessToJobObject(h, int(p._handle))
                   and k.DuplicateHandle(k.GetCurrentProcess(), h, int(p._handle), ctypes.byref(inside), 0, 0, 2)
                   and k.SetInformationJobObject(h, 9, ctypes.byref(limits), ctypes.sizeof(limits)))
    if h:
        k.CloseHandle(h)

    def resume():
        if ctypes.WinDLL("ntdll").NtResumeProcess(ctypes.c_void_p(int(p._handle))):
            p.kill()
            raise OSError("the process could not be started")
    return p, name if grouped else None, resume


class Group:
    """An open group: how many of its processes run, and ending them all."""

    def __init__(self, k, h):
        self.k, self.h = k, h

    def count(self):
        a = _Accounting()
        if not self.k.QueryInformationJobObject(self.h, 1, ctypes.byref(a), ctypes.sizeof(a), None):
            return None
        return a.active

    def end(self):
        return bool(self.k.TerminateJobObject(self.h, 1))

    def wait_empty(self, seconds):
        end = time.monotonic() + seconds
        while self.count() != 0:
            if time.monotonic() > end:
                return False
            time.sleep(0.02)
        return True

    def close(self):
        self.k.CloseHandle(self.h)


def open_group(name):
    """The group by its name, or None. (Never act on an empty handle: the system would take it for the caller's own.)"""
    if not WINDOWS or not name:
        return None
    k = _kernel()
    h = k.OpenJobObjectW(0x1F001F, 0, name)
    return Group(k, h) if h else None


def alert(title, text):
    """A message box when there is no window to write to (the desktop icon)."""
    if WINDOWS:
        ctypes.windll.user32.MessageBoxW(None, text, title, 0x10)
    else:
        subprocess.run(["osascript", "-e", f"display alert {quote_as(title)} message {quote_as(text)}"])


def quote_as(s):
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


if __name__ == "__main__":   # self-check
    assert pid_alive(os.getpid()) and not pid_alive(0)
    assert pid_start(os.getpid()) and pid_start(os.getpid()) == pid_start(os.getpid()) and pid_start(0) is None
    if WINDOWS:   # a job with a child, ended whole by its name
        job, group, go = spawn([sys.executable, "-c", "import subprocess, sys, time; "
                                "subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)']); time.sleep(60)"], f"check-{os.getpid()}")
        go()
        g = open_group(group)
        while g.count() < 2:
            time.sleep(0.05)
        assert g.end() and g.wait_empty(10) and job.wait(10) == 1
        g.close()
        assert open_group(group) is None and open_group("Local\\editroom-no-such") is None
    assert 0 < boot_time() < time.time()
    assert quote_as('a "b"') == '"a \\"b\\""'
    print("platform_util self-check OK", sys.platform)
