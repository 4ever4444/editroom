"""Export for the networks (stage 5.2): one finished video -> a file per network, shape, size and quality.

usage: python engine/export.py "videos/<name>" <network>:<shape>:<res>:<quality> [...]
  e.g. instagram:4:5:1080:max  tiktok:9:16:1080:small  youtube:16:9:2160:max
shape 9:16 | 16:9 | 4:5 | 1:1, res 720 | 1080 | 2160 (the short side), quality max (crf 18) | small (a set bitrate).
The source is final/final.mp4 (a reel) or final/episode.mp4 (an episode). Writes final/exports/<...>.mp4 and
final/exports/index.json: one row per file with its checks against engine/platforms.json (length, file size).
"""
import json
import sys
from pathlib import Path

import safe
from media import ffmpeg, probe, write_json

SPECS = json.loads((Path(__file__).parent / "platforms.json").read_text(encoding="utf-8"))
TITLE_TOP = 210 / 1920   # just above a reel's title (y=270): a shorter frame cut from a reel keeps it, with a margin, and the subtitles


class Refuse(Exception):
    pass


def ratio(shape):
    a, b = map(int, shape.split(":"))
    return a / b


def iso(text):
    """Numbers like 16:9 or 1080x1920 kept in their own direction inside a Hebrew sentence."""
    return f"⁨{text}⁩"


def res_label(res):
    return "4K" if res == "2160" else f"{res}p"


def frame(src_w, src_h, shape, res):
    """(crop filter or None, scale w, scale h) to turn the source frame into this shape and size."""
    if res not in SPECS["sizes"][shape]:
        raise Refuse(f"אין גודל {iso(res_label(res))} לצורה {iso(shape)}.")
    w, h = SPECS["sizes"][shape][res]
    if min(w, h) > min(src_w, src_h):
        raise Refuse(f"הסרטון המקורי בגודל {iso(f'{src_w}x{src_h}')}, קטן מ-{iso(res_label(res))}. הגדלה לא מוסיפה חדות, "
                     f"רק מגדילה את הקובץ. בחר גודל קטן יותר.")
    src, want = src_w / src_h, ratio(shape)
    if abs(src - want) < 0.01:
        return None, w, h
    if src < want <= 1:   # a less tall frame from a vertical reel (9:16 -> 4:5 or 1:1): full width, from the title down
        ch = round(src_w / want / 2) * 2
        y = min(round(src_h * TITLE_TOP), src_h - ch)
        return f"crop={src_w}:{ch}:0:{y}", w, h
    # ponytail: a vertical frame from a wide episode needs the face-following crop of stage 5.5; until then, reels
    # from an episode (reel_from_episode.py) already cut vertically by speaker
    if want > 1 >= src:   # a wide frame from a vertical reel would be a thin strip of it
        raise Refuse(f"הסרטון צולם לאורך. כדי למלא מסך רחב ({iso(shape)}) היה צריך לחתוך ממנו פס דק, והתוצאה "
                     "הייתה נראית רע. לסרטון רחב צריך לצלם לרוחב.")
    raise Refuse(f"הפרק צולם לרוחב. לסרטון אנכי ({iso(shape)}) משתמשים בכפתור 'ליצור ריל' בדף הניתוח, שחותך "
                 "סביב הדובר.")


def export(vdir, network, shape, res, quality):
    vdir = Path(vdir)
    src = next(p for p in (vdir / "final" / "final.mp4", vdir / "final" / "episode.mp4") if p.exists())
    spec = SPECS["networks"][network]
    if shape not in spec["formats"]:
        raise Refuse(f"{spec['label']} לא מציגה סרטונים בצורה {iso(shape)}.")
    info = probe(src)
    crop, w, h = frame(info["w"], info["h"], shape, res)
    note = ""
    if src.name == "final.mp4" and shape == "9:16":   # stage 11.4: out from under the network's buttons and texts
        try:
            src, note = safe.prepare(vdir, network)
        except FileNotFoundError as e:   # after the final approval: the reel as it is, and why
            note = str(e)
    out = vdir / "final" / "exports" / f"{network}-{shape.replace(':', 'x')}-{res}-{quality}.mp4"
    out.parent.mkdir(parents=True, exist_ok=True)
    vf = ",".join(filter(None, [crop, f"scale={w}:{h}:flags=lanczos", "format=yuv420p"]))
    if quality == "max":
        enc = ["-c:v", "libx264", "-crf", "18", "-preset", "slow"]
    else:
        k = SPECS["small_kbps"][res]
        enc = ["-c:v", "libx264", "-b:v", f"{k}k", "-maxrate", f"{int(k * 1.5)}k", "-bufsize", f"{k * 2}k", "-preset", "slow"]
    ffmpeg("-i", src, "-vf", vf, *enc, "-c:a", "copy", "-movflags", "+faststart", out)   # sound as it was mastered
    got = probe(out)
    mb = out.stat().st_size / 2**20
    warn = []
    if spec["max_seconds"] and got["duration"] > spec["max_seconds"]:
        warn.append(f"ארוך מ-{spec['max_seconds']} שנ' שהרשת מקבלת")
    if spec["max_mb"] and mb > spec["max_mb"]:
        warn.append(f"גדול מ-{spec['max_mb']}MB שהרשת מקבלת מהטלפון; לבחור 'קובץ קטן' או להעלות מהמחשב")
    return {"file": out.name, "network": network, "shape": shape, "res": res, "quality": quality,
            "size": f"{got['w']}x{got['h']}", "mb": round(mb, 1), "seconds": round(got["duration"], 1), "warnings": warn,
            "note": note}


def main(vdir, wanted):
    vdir = Path(vdir)
    index = vdir / "final" / "exports" / "index.json"
    # files made before stay; refusals are only those of this export (old ones would pile up on the page)
    rows = {r["file"]: r for r in (json.loads(index.read_text(encoding="utf-8")) if index.exists() else []) if r.get("file")}
    for spec in wanted:
        network, a, b, res, quality = spec.split(":")
        try:
            r = export(vdir, network, f"{a}:{b}", res, quality)
            rows[r["file"]] = r
            print(f"{r['file']}: {r['size']}, {r['mb']}MB {'; '.join(r['warnings']) or 'OK'}")
        except Refuse as e:
            print(f"{spec}: {e}")
            rows[spec] = {"file": None, "spec": spec, "error": str(e)}
    index.parent.mkdir(parents=True, exist_ok=True)
    write_json(index, list(rows.values()))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main(sys.argv[1], sys.argv[2:])
