"""Re-compose final.mp4 from edit.mkv + overlay.mov using system ffmpeg.

usage: python engine/recompose.py "videos/<name>"
"""
import sys
import subprocess
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from tools import FFMPEG
from media import probe


def main(video_dir):
    video_dir = Path(video_dir)
    edit = video_dir / "takes" / "edit.mkv"
    layer = video_dir / "final" / "overlay.mov"
    out = video_dir / "final" / "final.mp4"
    info = probe(edit)
    fps = str(info["fps"])

    tmp = video_dir / "final" / "final_new.mp4"
    tmp.unlink(missing_ok=True)
    r = subprocess.run([
        FFMPEG, "-hide_banner", "-y",
        "-i", str(edit), "-i", str(layer),
        "-filter_complex",
        "[0:v][1:v]overlay=format=auto:shortest=1,format=yuv420p[v];"
        "[0:a][1:a]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.84:level=false[a]",
        "-map", "[v]", "-map", "[a]",
        "-c:v", "libx264", "-crf", "18", "-preset", "slow", "-r", fps,
        "-c:a", "aac", "-b:a", "256k", "-movflags", "+faststart",
        str(tmp)
    ], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode:
        print("STDERR:", r.stderr[-2000:])
        sys.exit(1)
    try:
        out.unlink(missing_ok=True)
    except PermissionError:
        pass
    if tmp.exists():
        try:
            tmp.rename(out)
        except (PermissionError, OSError):
            out = tmp  # use the temp path if rename fails
    info2 = probe(out)
    print(f"final: {out} ({out.stat().st_size // 1024}KB, {info2['duration']:.1f}s, {info2['channels']}ch)")


if __name__ == "__main__":
    main(sys.argv[1])
