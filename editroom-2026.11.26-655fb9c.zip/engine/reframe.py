"""Where the person is in a wide camera frame (stage 5.5), so a vertical crop keeps them in it instead of the centre.

A person-segmentation model (u2net_human_seg, models/u2net_human_seg.onnx; came with the studio) marks the
person; the crop centres on the middle of their head and shoulders. One position per camera for a whole clip:
podcast guests sit, and a crop that drifts with every gesture looks nervous.
usage: python engine/reframe.py <video> <from_s> <to_s>   (prints the person's centre, 0..1 of the width)
"""
import sys
from functools import lru_cache

import av
import numpy as np
import onnxruntime as ort

import tools

SIDE = 320
MEAN, STD = np.array([0.485, 0.456, 0.406]), np.array([0.229, 0.224, 0.225])
SAMPLES = 6


@lru_cache(maxsize=1)
def model():
    m = tools.BG_MODEL
    return ort.InferenceSession(str(m), providers=["CPUExecutionProvider"]) if m.is_file() else None


def mask(rgb):
    """Person mask 0..1 at SIDE x SIDE for one RGB frame already SIDE x SIDE."""
    img = rgb.astype(np.float32) / 255.0
    x = ((img - MEAN) / STD).transpose(2, 0, 1)[None].astype(np.float32)
    m = model().run(None, {model().get_inputs()[0].name: x})[0][0, 0]
    return (m - m.min()) / (m.max() - m.min() + 1e-6)


def centre(m):
    """The middle of the person's upper part (head and shoulders), 0..1 across the frame; None if nobody is there."""
    rows = np.flatnonzero(m.max(1) > 0.5)
    if not len(rows):
        return None
    top = m[rows[0]:rows[0] + max(8, (rows[-1] - rows[0]) // 2)]   # the upper half of the person
    w = top.sum(0)
    return float((w * np.arange(SIDE)).sum() / w.sum() / SIDE) if w.sum() else None


def focus(video, a, b):
    """The person's centre in `video` between a and b seconds (median of a few frames); 0.5 when unsure."""
    if model() is None:
        return 0.5
    found = []
    with av.open(str(video)) as c:
        s = c.streams.video[0]
        for t in np.linspace(a, b, SAMPLES + 2)[1:-1]:
            c.seek(int(t / s.time_base), stream=s)
            frame = next(c.decode(s), None)
            if frame is not None and (x := centre(mask(frame.reformat(width=SIDE, height=SIDE, format="rgb24").to_ndarray()))) is not None:
                found.append(x)
    return round(float(np.median(found)), 3) if found else 0.5


if __name__ == "__main__":
    print(focus(sys.argv[1], float(sys.argv[2]), float(sys.argv[3])))
