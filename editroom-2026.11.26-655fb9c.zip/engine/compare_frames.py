"""Compare two renders frame by frame.

usage: python engine/compare_frames.py ref.mp4 new.mp4 [first last]
  without a range: every frame must be the same (a video without effects renders exactly as before)
  with a range:    frames first..last must change (the effect is there); every other frame may differ only by
                   compression noise. x264 re-encodes around a changed stretch (it may even add a keyframe there
                   and carry its rate decisions into the next group), so untouched frames are not bit-identical.
Exit code 1 when that does not hold.
"""
import sys

import av
import numpy as np

SAME = 0.5          # mean abs difference (0-255): the same frame
CODEC_NOISE = 2.0   # re-encoding noise around an effect (measured up to ~1.1 at crf 18; invisible)
CHANGED = 2.5       # an effect frame must differ at least this much (a glitch's last frame is faint on purpose)


def frames(path):
    with av.open(str(path)) as c:
        for f in c.decode(video=0):
            yield f.to_ndarray(format="gray")[::2, ::2].astype(np.int16)


def compare(ref, new, first=None, last=None):
    diffs = [float(np.abs(a - b).mean()) for a, b in zip(frames(ref), frames(new))]
    n_ref, n_new = sum(1 for _ in frames(ref)), sum(1 for _ in frames(new))
    in_fx = (lambda i: first <= i <= last) if first is not None else (lambda i: False)
    outside = max(((i, d) for i, d in enumerate(diffs) if not in_fx(i)), key=lambda x: x[1], default=(None, 0.0))
    allowed = SAME if first is None else CODEC_NOISE
    print(f"frames: ref {n_ref}, new {n_new}")
    print(f"outside the effect: worst frame {outside[0]} differs by {outside[1]:.3f} (allowed {allowed})")
    ok = n_ref == n_new and outside[1] <= allowed
    if first is not None:
        inside = [d for i, d in enumerate(diffs) if in_fx(i)]
        print(f"inside the effect ({first}-{last}): smallest change {min(inside):.2f} (needed {CHANGED})")
        ok &= min(inside) >= CHANGED
    print("OK" if ok else "FAIL")
    return ok


if __name__ == "__main__":
    a = sys.argv[1:]
    sys.exit(0 if compare(a[0], a[1], *map(int, a[2:4])) else 1)
