"""Client logos (stage 8, Ron 19.11): each client's logos in one place, and a simple way to put one on a video.

Logos live with the client: clients/<client id>/logos/<file> (the user's own data, not in git). A video's logo is
graphics.json "logo": {file: "<client id>/<file>", corner, size, when}. It is rendered like a library block: a
see-through mov laid into the final video (render.compose) and a webm the room plays (Preview), so the room shows
exactly what the video gets. Corners keep to the safe area: never the top 250 px (the network's bar), never the
bottom right (the network's buttons), bottom edge above y=1580.
usage: python engine/logo.py <video>        (renders the logo layer, prints where it went)
       python engine/logo.py list <video>   (the video's client and its logos)
"""
import hashlib
import json
import re
import shutil
import sys
from pathlib import Path

import av

import paths
import tools
from media import probe, read_json

CLIENTS = paths.CLIENTS
TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}
CORNERS = {"tl": "למעלה משמאל", "tr": "למעלה מימין", "bl": "למטה משמאל"}   # bottom right: the network's buttons
WHEN = {"all": "כל הסרטון", "open": "רק בפתיחה", "end": "רק בסוף", "none": "בלי, רק לוגו בסיום"}   # none: stage 11.6
# a plate behind the logo, so a dark logo shows on a dark picture (Ron 19.11). Rounded, sized to the logo: padding
# PLATE_PAD of the logo's height on every side, corner radius PLATE_RADIUS of the plate's height. room/logo-fx.js
# draws the same plate for the room's previews (LOGO_FX.plate).
BGS = {"none": "בלי רקע", "white": "רקע לבן", "dark": "רקע כהה"}
PLATE = {"white": (255, 255, 255, 0.92), "dark": (7, 7, 10, 0.75)}
PLATE_PAD, PLATE_RADIUS = 0.18, 0.22
# the two frames a logo goes on: a vertical reel (its safe area: the network's bar on top, buttons bottom right) and a
# wide YouTube episode (bottom right: YouTube's channel watermark). Sizes are the logo's width in px.
FRAMES = {"reel": {"w": 1080, "h": 1920, "margin": 40, "top": 260, "bottom": 1570, "cap": 400,
                   "sizes": {"s": 150, "m": 220, "l": 300}},
          "episode": {"w": 1920, "h": 1080, "margin": 48, "top": 48, "bottom": 1032, "cap": 220,
                      "sizes": {"s": 180, "m": 260, "l": 360}}}
SIZES = FRAMES["reel"]["sizes"]
W, H = FRAMES["reel"]["w"], FRAMES["reel"]["h"]
OPEN_S, END_S, FADE = 3.0, 4.0, 0.3
FX_JS = Path(__file__).parent / "room" / "logo-fx.js"   # the effects, shared with the room's preview
GSAP = "/vendor/gsap.min.js"   # what HyperFrames renders with (hf_layer too)


def effects():
    """{id: label} of the logo effects, read from the one file both the room and the render use."""
    return dict(re.findall(r"^    (\w+): \{label: '([^']+)'", FX_JS.read_text(encoding="utf-8"), re.M))


def fx_timing():
    t = FX_JS.read_text(encoding="utf-8")
    return float(re.search(r"INTRO: ([\d.]+)", t).group(1)), float(re.search(r"OUTRO: ([\d.]+)", t).group(1))


def logo_dir(client_id):
    d = (CLIENTS / client_id / "logos").resolve()
    if d.parent.parent != CLIENTS.resolve() or "/" in client_id or "\\" in client_id:
        raise FileNotFoundError(client_id)
    return d


def logos(client_id):
    d = logo_dir(client_id)
    return sorted(p.name for p in d.iterdir() if p.suffix.lower() in TYPES) if d.is_dir() else []


def add(client_id, filename, data):
    """Save an uploaded logo under the client. A name already there gets a number, nothing is overwritten."""
    suffix = Path(filename).suffix.lower()
    if suffix not in TYPES:
        raise ValueError("אפשר להעלות לוגו בפורמט PNG (מומלץ, עם רקע שקוף), JPG או WEBP")
    stem = "".join(c for c in Path(filename).stem if c not in '\\/:*?"<>|').strip()[:50] or "logo"
    d = logo_dir(client_id)
    d.mkdir(parents=True, exist_ok=True)
    out, n = d / f"{stem}{suffix}", 2
    while out.exists():
        out, n = d / f"{stem} ({n}){suffix}", n + 1
    out.write_bytes(data)
    try:
        size(out)   # a file that isn't really an image goes away again
    except Exception:
        out.unlink()
        raise ValueError("הקובץ הזה לא נפתח כתמונה")
    return out.name


def remove(client_id, name):
    p = path(f"{client_id}/{name}")
    p.unlink()


def path(ref):
    """'<client id>/<file>' -> the logo file, only inside that client's logos."""
    client_id, _, name = ref.partition("/")
    p = (logo_dir(client_id) / name).resolve()
    if p.parent != logo_dir(client_id) or not p.is_file():
        raise FileNotFoundError(ref)
    return p


def size(p):
    """(width, height) of the image; decodes it, so a file that only has an image's name is refused."""
    with av.open(str(p)) as c:
        f = next(c.decode(video=0))
        if not (f.width and f.height):
            raise ValueError(p)
        return f.width, f.height


def place(img_w, img_h, corner, size_key, frame="reel", bg="none"):
    """Where the logo goes on the frame: (x, y, width, height) of what is drawn (the logo, or its plate with the
    logo inside), inside the frame's safe area."""
    f = FRAMES[frame]
    w = f["sizes"][size_key]
    h = round(img_h * w / img_w)
    h = min(h, f["cap"])   # a very tall logo is capped; width follows
    w = round(img_w * h / img_h)
    if bg != "none":
        pad = plate_pad(h)
        w, h = w + 2 * pad, h + 2 * pad
    x = f["margin"] if corner in ("tl", "bl") else f["w"] - f["margin"] - w
    y = f["top"] if corner in ("tl", "tr") else f["bottom"] - h
    return x, y, w, h


def plate_pad(logo_h):
    return max(6, round(logo_h * PLATE_PAD))


def plated(src, w, h, pad, bg, out):
    """The logo on its rounded plate, as one PNG of w x h (the plate's size, `pad` around the logo): what every
    render then uses as the logo, so the plate moves with every effect."""
    r = round(h * PLATE_RADIUS)
    cr, cg, cb, ca = PLATE[bg]
    alpha = f"{round(255 * ca)}*lte(hypot(max(0,abs(X-W/2)-(W/2-{r})),max(0,abs(Y-H/2)-(H/2-{r}))),{r})"   # rounded corners
    tools._run(tools.FFMPEG, "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"color=c=black:s={w}x{h}", "-i", src,
               "-filter_complex",
               f"[0:v]format=rgba,geq=r={cr}:g={cg}:b={cb}:a='{alpha}'[p];"
               f"[1:v]scale={w - 2 * pad}:{h - 2 * pad}:flags=lanczos,format=rgba[l];[p][l]overlay={pad}:{pad}:format=auto",
               "-frames:v", "1", "-update", "1", out)
    return out



def span(when, total_s, corner="bl", title_end=0.0):
    """Seconds (from, to) the logo shows. In a top corner it waits for the title to go (the title fills the top of
    the frame in the opening seconds), so "open" then means the 3 seconds after the title."""
    start = title_end if corner in ("tl", "tr") else 0.0
    return {"all": (start, total_s), "open": (start, min(start + OPEN_S, total_s)),
            "end": (max(start, total_s - END_S), total_s)}[when]


def resolve(g, fps, frames, title_end=0.0, frame="reel"):
    """graphics.json "logo" (a reel) or analysis/logo.json (an episode) -> the item the render and the room use."""
    lg = g.get("logo")
    if not lg:
        return None
    corner, size_key, when = lg.get("corner", "bl"), lg.get("size", "m"), lg.get("when", "all")
    fx, bg = lg.get("fx", "fade"), lg.get("bg", "none")
    if corner not in CORNERS or size_key not in SIZES or when not in WHEN or fx not in effects() or bg not in BGS:
        raise ValueError(f"graphics.json logo: corner {list(CORNERS)}, size {list(SIZES)}, when {list(WHEN)}, "
                         f"fx {list(effects())}, bg {list(BGS)}")
    try:
        src = path(lg["file"])
    except FileNotFoundError:   # removed from the client's logos after it was chosen
        raise FileNotFoundError(f"הלוגו {lg['file'].partition('/')[2]} כבר לא נמצא אצל הלקוח. בוחרים לוגו אחר בכפתור ◆ לוגו, "
                                f"או 'בלי לוגו'.")
    if when == "none":   # only the logo at the end of the video (engine/endcard.py), none in a corner
        return None
    x, y, w, h = place(*size(src), corner, size_key, frame, bg)
    pad = plate_pad(place(*size(src), corner, size_key, frame)[3]) if bg != "none" else 0   # around the logo
    a, b = span(when, frames / fps, corner, title_end)
    first = round(a * fps)
    return {"id": "logo", "kind": "logo", "label": "לוגו", "file": lg["file"], "corner": corner, "size": size_key,
            "when": when, "fx": fx, "bg": bg, "pad": pad, "frame": frame, "from": first,
            "dur": min(round(b * fps), frames) - first, "x": x, "y": y, "width": w, "height": h}


def parts(vdir, item, fps):
    """The logo as pieces on the full frame: {"intro": mov | None, "rest": png, "outro": mov | None, "fade": seconds}.
    An effect animates only its way in and out (HyperFrames, room/logo-fx.js); in between it rests as a still, so a
    logo on an hour-long episode costs the same as on a reel. "fade" has no movie parts: the still fades in and out.
    Made again only when the logo, its place, its effect or the frame rate changed."""
    out = Path(vdir) / "takes" / "logo"
    out.mkdir(parents=True, exist_ok=True)
    src = path(item["file"])
    f = FRAMES[item.get("frame", "reel")]
    intro, outro = fx_timing()
    dur = item["dur"] / fps
    animated = item.get("fx", "fade") != "fade" and dur >= intro + outro + 0.2
    look = {k: item.get(k) for k in ("file", "fx", "bg", "x", "y", "width", "height", "corner")}
    key = hashlib.sha1(json.dumps([look, f["w"], src.stat().st_mtime_ns, fps, animated]).encode()).hexdigest()
    got = {"intro": out / "intro.mov" if animated else None, "rest": out / "rest.png",
           "outro": out / "outro.mov" if animated else None, "fade": 0 if animated else min(FADE, dur / 3),
           "intro_s": intro if animated else 0, "outro_s": outro if animated else 0}
    stamp = out / "parts.key"
    if stamp.exists() and stamp.read_text() == key and all(p.exists() for p in (got["intro"], got["rest"], got["outro"]) if p):
        return got
    stamp.unlink(missing_ok=True)   # half of it must never be taken for ready (stage b2)
    if item.get("bg", "none") != "none":   # the plate becomes part of the logo itself
        src = plated(src, item["width"], item["height"], item["pad"], item["bg"], out / "plated.png")
    if animated:
        fx_parts(out, src, item, fps, intro, outro, f)
    else:
        tools._run(tools.FFMPEG, "-y", "-loglevel", "error", "-i", src, "-vf",
                   f"scale={item['width']}:{item['height']}:flags=lanczos,format=rgba,"
                   f"pad={f['w']}:{f['h']}:{item['x']}:{item['y']}:color=black@0", "-frames:v", "1", "-update", "1",
                   got["rest"])
    stamp.write_text(key)
    return got


def render(vdir, item, fps):
    """A reel's logo: takes/logo/logo.mov (ProRes 4444 with alpha, render.compose lays it in) and logo.webm (VP9
    with alpha, the room plays it): the pieces joined over the logo's whole time."""
    out = Path(vdir) / "takes" / "logo"
    pc = parts(vdir, item, fps)
    dur = item["dur"] / fps
    key = hashlib.sha1(json.dumps([(out / "parts.key").read_text(), item["dur"]]).encode()).hexdigest()
    mov, webm, stamp = out / "logo.mov", out / "logo.webm", out / "logo.key"
    if mov.exists() and webm.exists() and stamp.exists() and stamp.read_text() == key:
        return mov, webm
    stamp.unlink(missing_ok=True)
    middle = dur - pc["intro_s"] - pc["outro_s"]
    still = ["-loop", "1", "-framerate", f"{fps}", "-t", f"{middle:.3f}", "-i", pc["rest"]]
    if pc["intro"]:
        ins = ["-i", pc["intro"], *still, "-i", pc["outro"]]
        graph = "".join(f"[{i}:v]fps={fps},format=yuva444p10le,setsar=1[v{i}];" for i in range(3)) + "[v0][v1][v2]concat=n=3:v=1:a=0[v]"
    else:
        fade = pc["fade"]
        ins = still
        graph = (f"[0:v]format=rgba,fade=t=in:st=0:d={fade:.2f}:alpha=1,"
                 f"fade=t=out:st={dur - fade:.3f}:d={fade:.2f}:alpha=1,format=yuva444p10le[v]")
    tools._run(tools.FFMPEG, "-y", "-loglevel", "error", *ins, "-filter_complex", graph, "-map", "[v]",
               "-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le", mov)
    tools._run(tools.FFMPEG, "-y", "-loglevel", "error", "-i", mov, "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p",
               "-b:v", "1M", "-an", webm)
    stamp.write_text(key)
    return mov, webm


def overlay(item, fps, first_input, base):
    """For a render that lays the logo in itself (an episode): the extra ffmpeg inputs and the filter that puts the
    pieces over `base` at the logo's time. Returns (inputs, filter, out label). Times are on that render's clock."""
    pc = item["parts"]
    a, dur = item["from"] / fps, item["dur"] / fps
    middle = dur - pc["intro_s"] - pc["outro_s"]
    inputs = ["-loop", "1", "-framerate", f"{fps}", "-t", f"{middle:.3f}", "-i", pc["rest"]]
    n = first_input
    rest = f"[{n}:v]format=rgba" + (f",fade=t=in:st=0:d={pc['fade']:.2f}:alpha=1,fade=t=out:st={middle - pc['fade']:.3f}:"
                                    f"d={pc['fade']:.2f}:alpha=1" if pc["fade"] else "")
    pieces = [(f"{rest},setpts=PTS-STARTPTS+{a + pc['intro_s']:.3f}/TB[lg_r]", "lg_r")]
    if pc["intro"]:
        inputs += ["-i", pc["intro"], "-i", pc["outro"]]
        pieces = [(f"[{n + 1}:v]setpts=PTS-STARTPTS+{a:.3f}/TB[lg_i]", "lg_i"), pieces[0],
                  (f"[{n + 2}:v]setpts=PTS-STARTPTS+{a + dur - pc['outro_s']:.3f}/TB[lg_o]", "lg_o")]
    graph, cur = [], base
    for k, (f, label) in enumerate(pieces):
        graph.append(f)
        graph.append(f"[{cur}][{label}]overlay=eof_action=pass:format=auto[lg{k}]")
        cur = f"lg{k}"
    return inputs, ";".join(graph), cur


PAGE = """<!doctype html>
<html><head><meta charset="UTF-8"><script src="{gsap}"></script>
<style>html,body{{margin:0;width:{w}px;height:{h}px;overflow:hidden;background:transparent}}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{d}" data-width="{w}" data-height="{h}">{box}</div>
<script>{fx_js}</script>
<script>
const el = document.querySelector('.lgbox');
el.style.left = '{x}px'; el.style.top = '{y}px';
const fx = LOGO_FX.fx['{fx}'];
const tl = gsap.timeline({{paused: true}});
if ('{phase}' === 'outro') {{ const rest = gsap.timeline({{paused: true}}); fx.intro(rest, el, {side}); rest.progress(1); }}
fx['{phase}'](tl, el, {side});
tl.set({{}}, {{}}, {d});   // the timeline lasts the whole part
window.__timelines["main"] = tl; tl.seek(0);
</script></body></html>
"""


def fx_parts(out, src, item, fps, intro, outro, f):
    """An effect (room/logo-fx.js) rendered with HyperFrames: its way in, its way out, and the resting look between
    (the way in's last frame, as a still)."""
    assets = paths.HF_STAGE / "assets" / "_logo"   # ponytail: one shared render stage, renders run one at a time
    assets.mkdir(parents=True, exist_ok=True)
    img = assets / f"{hashlib.sha1(src.read_bytes()).hexdigest()[:12]}{src.suffix.lower()}"
    shutil.copy2(src, img)
    box = re.search(r"box\(src, w, h\) \{\s*return `(.*?)`;", FX_JS.read_text(encoding="utf-8"), re.S).group(1)
    box = box.replace("${src}", f"assets/_logo/{img.name}").replace("${w}", str(item["width"])).replace("${h}", str(item["height"]))
    side = -1 if item["corner"] in ("tl", "bl") else 1   # "slide" comes in from the logo's own edge of the frame
    for phase, d in (("intro", intro), ("outro", outro)):
        (paths.HF_STAGE / "index.html").write_text(PAGE.format(gsap=GSAP, d=d, box=box, fx_js=FX_JS.read_text(encoding="utf-8"),
                                                          x=item["x"], y=item["y"], fx=item["fx"], phase=phase, side=side,
                                                          w=f["w"], h=f["h"]), encoding="utf-8")
        tools.hf_render(paths.HF_STAGE, out / f"{phase}.mov", fps=round(fps))
    tools._run(tools.FFMPEG, "-y", "-loglevel", "error", "-sseof", "-0.1", "-i", out / "intro.mov", "-update", "1",
               "-pix_fmt", "rgba", out / "rest.png")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if sys.argv[1] == "list":   # the video's client and its logos, for Claude's first edit
        sys.path.insert(0, str(Path(__file__).parent / "room"))
        import clients
        cid = clients.client_of(Path(sys.argv[2]))
        print(json.dumps({"client": cid, "logos": [f"{cid}/{n}" for n in logos(cid)] if cid else []}, ensure_ascii=False))
        sys.exit()
    vdir = Path(sys.argv[1])
    edit = vdir / "takes" / "edit.mkv"
    info = probe(edit)
    fps = float(info["fps"])
    item = resolve(read_json(vdir / "graphics.json"), fps, round(info["duration"] * fps))
    print(render(vdir, item, fps) if item else "no logo in graphics.json")
