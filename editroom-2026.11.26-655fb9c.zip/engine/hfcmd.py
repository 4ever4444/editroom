"""The way a Claude job runs HyperFrames (stage 13.6, docs/hyperframes-spec.md + v2-v7, build rules 1, 7).

usage: python engine/hfcmd.py [--in <folder>] <command> [args...]

Only a closed list of the CLI's commands, always the system's own pinned CLI (never npx or @latest), always with
tools.hf_env (no telemetry, publish sent nowhere, no service keys). For media-use: a file from this computer never
goes to HeyGen (generate/voices/avatars refuse any argument that is a file; resolve gets --local-only when its
input is one). The Pro skills (reverse, templates) run only in a normal Claude Code chat, never in a room job.
A guide on the usual path, not a lock: a job that may run python could reach the CLI another way (v3).
"""
import os
import subprocess
import sys
from pathlib import Path

import tools

ALLOWED = {"check", "snapshot", "render", "compositions", "timeline", "keyframes", "media-use", "auth"}
PRO = {"reverse", "templates"}
UPLOADING = {"generate", "voices", "avatars"}   # media-use verbs that send what they are given to HeyGen
RESOLVE = {"resolve", "doctor", "stats", "adopt", "candidates", "reuse", "from", "params", "analyze"}
INPUTS = {"--from", "--for"}   # the resolve verbs' input files (--project / --out are where results land)
PRO_CARD = ("שחזור סרטון ותבניות סגנון (HyperFrames Pro) רצים בשיחה רגילה עם Claude Code, לא בחדר. "
            "כתבו כרטיס החלטה לפי הנוסח ב-CLAUDE.md והמשיכו בשאר.")


class Refused(Exception):
    pass


def values(args):
    """Every value an argument list carries: plain tokens, what follows '=', and each part of a comma list.
    --out's value is left out (the output file, it is never sent)."""
    out, skip = [], False
    for a in args:
        if skip:
            skip = False
            continue
        if a in ("--out", "-o"):
            skip = True
            continue
        if a.startswith("--out="):
            continue
        out += [p for p in (a.split("=", 1)[1] if a.startswith("-") and "=" in a else a).split(",") if p]
    return out


def is_file(v, cwd):
    try:
        p = Path(v)
        return (p if p.is_absolute() else Path(cwd) / p).resolve().is_file()
    except (OSError, ValueError):
        return False


def input_files(args, cwd):
    """The resolve verbs' input values (--from x, --from=x) that are files on this computer."""
    found = []
    for k, a in enumerate(args):
        name, _, val = a.partition("=")
        if name in INPUTS:
            val = val or (args[k + 1] if k + 1 < len(args) else "")
            found += [v for v in val.split(",") if v and is_file(v, cwd)]
    return found


def command(argv, cwd):
    """The CLI arguments to run, or Refused with the reason in Hebrew."""
    if not argv:
        raise Refused("חסרה פקודה")
    cmd, rest = argv[0], list(argv[1:])
    if cmd in PRO:
        raise Refused(PRO_CARD)
    if cmd not in ALLOWED:
        raise Refused(f"הפקודה {cmd} לא פתוחה לעבודות החדר (רק: {', '.join(sorted(ALLOWED))})")
    if cmd == "auth" and rest[:1] != ["status"]:
        raise Refused("התחברות רק מהדף 'ברוכים הבאים'. בלי התחברות, משתמשים בכלים המקומיים")
    if cmd == "media-use" and rest:
        verb = rest[0]
        if verb in UPLOADING:
            sent = [v for v in values(rest[1:]) if is_file(v, cwd)]
            if sent:
                raise Refused(f"קובץ מהמחשב לא עולה ל-HeyGen ({sent[0]}). לקובץ הזה רק כלי מקומי")
        elif verb in RESOLVE and input_files(rest[1:], cwd) and "--local-only" not in rest:
            rest.append("--local-only")
    return [cmd, *rest]


def main(argv):
    cwd = os.getcwd()
    if argv[:1] == ["--in"]:
        cwd, argv = argv[1], argv[2:]
    try:
        args = command(argv, cwd)
    except Refused as e:
        print(f"✗ {e}", file=sys.stderr)
        return 2
    return subprocess.run([str(tools.NODE), str(tools.HF_CLI), *args], cwd=cwd, env=tools.hf_env()).returncode


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
    sys.exit(main(sys.argv[1:]))
