"""Two-camera podcast: sync the cameras by sound, find who speaks when, plan the camera switches.

Pure functions on loudness envelopes (media.envelope_db, one value per HOP); the file I/O is in the
command at the bottom. Each speaker has their own mic, so "who speaks" = whose mic is clearly louder.
"""
import numpy as np

from media import HOP

SPEECH_DB = 15      # above the mic's own noise floor = talking
LEAD_DB = 6         # one mic this much louder than the other = that one speaks; closer = both
MERGE_S = 0.3       # runs shorter than this are absorbed by their neighbours
PAUSE_S = 0.8       # a pause this short between two bits of the same speaker is still their turn
TURN_S = 1.0        # a speaker must talk this long to earn the camera (a short "yes" does not)
BOTH_S = 1.5        # both talking this long = split screen
MIN_SHOT_S = 2.5
LEAD_IN_S = 0.15    # cut to the speaker slightly before they start


def offset(ref, other, max_s=600.0):
    """Seconds to add to `other`'s time to land on `ref`'s clock (other starts later -> positive).

    Cross-correlation of the two envelopes, each normalised; max_s bounds the search."""
    a = (ref - ref.mean()) / (ref.std() + 1e-9)
    b = (other - other.mean()) / (other.std() + 1e-9)
    n = 1 << int(np.ceil(np.log2(len(a) + len(b))))
    corr = np.fft.irfft(np.fft.rfft(a, n) * np.conj(np.fft.rfft(b, n)), n)
    lag_max = min(int(max_s / HOP), len(a) - 1, len(b) - 1)
    lags = np.r_[0:lag_max + 1, -lag_max:0]  # positive lags at the start, negative wrap at the end
    idx = np.r_[0:lag_max + 1, n - lag_max:n]
    best = int(np.argmax(corr[idx]))
    peak = corr[idx][best] / min(len(a), len(b))
    return lags[best] * HOP, float(peak)


def drift(ref, other, off, window_s=120.0):
    """Offset measured in a window at the start and at the end: equal = no drift between devices."""
    shift = int(round(off / HOP))
    end = min(len(ref), len(other) + shift)
    start_ref = max(0, shift)
    w = min(int(window_s / HOP), (end - start_ref) // 3)  # short recordings: a third of the overlap
    out = []
    for a0, a1 in [(start_ref, start_ref + w), (end - w, end)]:
        b0, b1 = a0 - shift, a1 - shift
        if w < int(5 / HOP):
            out.append(None)
            continue
        pad = int(2.0 / HOP)  # look for up to 2 s of extra slip inside each window
        seg = other[max(0, b0 - pad):b1 + pad]
        d, _ = offset(ref[a0:a1], seg, max_s=2.0 + pad * HOP)
        out.append(round(off + d + (b0 - max(0, b0 - pad)) * HOP, 3))
    return out


def labels(envs):
    """Per HOP: -1 silence, i = mic i speaks, 99 = both. envs = list of aligned envelopes, one per mic."""
    n = min(len(e) for e in envs)
    lev = np.stack([e[:n] - np.percentile(e, 3) for e in envs])  # 3rd pct: a host may talk 90% of the time
    talking = lev > SPEECH_DB
    top = lev.argmax(0)
    srt = np.sort(lev, 0)
    clear = (srt[-1] - srt[-2]) >= LEAD_DB
    out = np.full(n, -1)
    any_talk = talking.any(0)
    out[any_talk & clear] = top[any_talk & clear]
    out[any_talk & ~clear & (talking.sum(0) >= 2)] = 99
    lone = any_talk & ~clear & (talking.sum(0) < 2)
    out[lone] = top[lone]
    return out


def runs(lab):
    """[(label, start_s, end_s)]. First, pauses shorter than MERGE_S between syllables are filled with
    the speech before them; then any run still shorter than MERGE_S is absorbed into the one before."""
    def split(lab):
        edges = np.flatnonzero(np.diff(lab)) + 1
        return [(int(lab[s]), s, e) for s, e in zip(np.r_[0, edges], np.r_[edges, len(lab)])]

    lab = lab.copy()
    gap, pause = int(MERGE_S / HOP), int(PAUSE_S / HOP)
    for lb, s, e in split(lab):  # edge flicker (a window that straddles a syllable edge)
        if s and e - s <= 5:
            lab[s:e] = lab[s - 1]
    rs = split(lab)
    for i, (lb, s, e) in enumerate(rs):
        if lb == -1 and 0 < i and (e - s < gap or (e - s < pause and i + 1 < len(rs) and rs[i + 1][0] == rs[i - 1][0])):
            lab[s:e] = lab[s - 1]
    out = []
    for lb, s, e in split(lab):
        if out and e - s < gap and out[-1][0] != -1:  # a blip inside someone else's speech
            out[-1] = (out[-1][0], out[-1][1], e)
        elif out and out[-1][0] == lb:
            out[-1] = (lb, out[-1][1], e)
        else:
            out.append((lb, s, e))
    return [(lb, round(s * HOP, 2), round(e * HOP, 2)) for lb, s, e in out]


def plan(rs, total_s, first_cam=0):
    """Camera shots [{cam, s, e}] (cam 99 = split screen) from speaker runs. Silence keeps the camera."""
    shots = [{"cam": first_cam, "s": 0.0}]
    for lb, s, e in rs:
        cur = shots[-1]
        if lb == -1 or lb == cur["cam"]:
            continue
        if (lb == 99 and e - s < BOTH_S) or (lb != 99 and e - s < TURN_S):
            continue
        at = max(s - LEAD_IN_S, cur["s"] + MIN_SHOT_S)
        if at >= e - 0.5:  # the turn is over before the current shot may end
            continue
        if not shots[-1]["s"] and len(shots) == 1 and s < MIN_SHOT_S:  # speaker at the very start
            cur["cam"] = lb
            continue
        cur["e"] = round(at, 2)
        shots.append({"cam": lb, "s": round(at, 2)})
    shots[-1]["e"] = round(total_s, 2)
    return shots


def speakers(rs):
    """analysis/speakers.json rows: who speaks when, silence left out."""
    return [{"who": "both" if lb == 99 else lb, "s": round(s, 2), "e": round(e, 2)} for lb, s, e in rs if lb != -1]


if __name__ == "__main__":
    # self-check on synthetic envelopes: two mics with bleed, a short "yes", a stretch of both
    rng = np.random.default_rng(0)
    T = int(60 / HOP)
    quiet = -60 + rng.normal(0, 1, T)
    m0, m1 = quiet.copy(), quiet.copy()

    def talk(m, other, a, b, db=-20):
        m[int(a / HOP):int(b / HOP)] = db + rng.normal(0, 1, int(b / HOP) - int(a / HOP))
        other[int(a / HOP):int(b / HOP)] = np.maximum(other[int(a / HOP):int(b / HOP)], db - 14)  # bleed

    talk(m0, m1, 1, 12)
    talk(m1, m0, 12.4, 13.0)     # "yes" from mic 1: no switch
    talk(m0, m1, 13.2, 20)
    talk(m1, m0, 21, 35)
    m0[int(35 / HOP):int(38 / HOP)] = -20  # both together
    m1[int(35 / HOP):int(38 / HOP)] = -20
    talk(m0, m1, 38.5, 60)

    rs = runs(labels([m0, m1]))
    shots = plan(rs, 60)
    cams = [s["cam"] for s in shots]
    assert cams == [0, 1, 99, 0], shots
    assert abs(shots[1]["s"] - (21 - LEAD_IN_S)) < 0.05, shots
    assert all(s["e"] - s["s"] >= MIN_SHOT_S for s in shots), shots

    # sync: camera 2 started 7.3 s late, so its clock is 7.3 s behind
    ref = np.convolve(rng.normal(-40, 10, int(300 / HOP)), np.ones(20) / 20, "same")
    shift = int(7.3 / HOP)
    other = ref[shift:] + rng.normal(0, 2, len(ref) - shift)
    off, peak = offset(ref, other)
    assert abs(off - 7.3) < 0.02 and peak > 0.5, (off, peak)
    d = drift(ref, other, off, window_s=60)
    assert all(x is not None and abs(x - 7.3) < 0.02 for x in d), d
    print("podcast self-check OK", cams, round(off, 2), d)
